package com.rostik.touchbot

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.text.*
import android.text.InputType
import android.view.*
import android.widget.*
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Rostik Touch Bot overlay UI.
 *
 * Layout is deliberately close to the supplied reference image:
 * header -> search -> 6-column brawler grid + two vertical size sliders ->
 * queue/cups -> START/PAUSE/STOP.
 *
 * All 108 catalog entries are rendered from assets/brawler_icons and the
 * brawler area is independently scrollable. Queue is independently scrollable.
 */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: View? = null
    private var expanded = false

    private var bubbleX = 24
    private var bubbleY = 220

    // Reference proportions. User can change them with the vertical sliders.
    private var widthPct = 54
    private var heightPct = 90

    private var brawlerSearch = ""
    private var brawlerScrollY = 0
    private var queueScrollY = 0
    private var selectedId: String? = null

    private val selected = linkedSetOf<String>()
    private val draft = linkedMapOf<String, Pair<Int, Int>>()

    override fun onCreate() {
        super.onCreate()
        StatsStore.init(this)
        BotRuntime.init(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        loadDraft()
        loadSize()
        startForegroundCompat()
        showBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        try { bubble?.let(wm::removeView) } catch (_: Throwable) {}
        try { panel?.let(wm::removeView) } catch (_: Throwable) {}
        bubble = null
        panel = null
        super.onDestroy()
    }

    private fun startForegroundCompat() {
        val channelId = "overlay_v30"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(channelId, "Rostik AI overlay", NotificationManager.IMPORTANCE_LOW))
        }
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("Rostik Touch Bot v30.14")
            .setContentText("AI overlay active")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(31, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else startForeground(31, notification)
    }

    private fun overlayType() = if (Build.VERSION.SDK_INT >= 26)
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

    private fun bubbleParams() = WindowManager.LayoutParams(
        dp(58), dp(58), overlayType(),
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        android.graphics.PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = bubbleX
        y = bubbleY
    }

    private fun showBubble() {
        if (bubble != null) return
        bubble = TextView(this).apply {
            text = "AI"
            textSize = 15f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            background = circle(Color.rgb(0, 188, 245), dp(30f))
            elevation = dp(8f).toFloat()
            setOnClickListener { if (!dragging) togglePanel() }
        }
        bubble!!.setOnTouchListener(DragTouchListener { x, y ->
            bubbleX = x
            bubbleY = y
            try { wm.updateViewLayout(bubble, bubbleParams()) } catch (_: Throwable) {}
        })
        try { wm.addView(bubble, bubbleParams()) } catch (_: Throwable) { bubble = null }
    }

    private fun togglePanel() { if (expanded) collapse() else expand() }

    private fun expand() {
        if (expanded) return
        expanded = true
        try { bubble?.let(wm::removeView) } catch (_: Throwable) {}
        bubble = null
        val root = buildPanel()
        panel = root
        try { wm.addView(root, panelParams()) } catch (_: Throwable) {
            expanded = false
            panel = null
            showBubble()
        }
    }

    private fun collapse() {
        if (!expanded) return
        expanded = false
        try { panel?.let(wm::removeView) } catch (_: Throwable) {}
        panel = null
        showBubble()
    }

    private fun panelParams() = WindowManager.LayoutParams(
        panelWidthPx(), panelHeightPx(), overlayType(),
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        android.graphics.PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.CENTER }

    private fun panelWidthPx(): Int {
        val w = resources.displayMetrics.widthPixels
        return (w * widthPct / 100f).roundToInt().coerceIn(dp(520).coerceAtMost(w - dp(12)), w - dp(8))
    }

    private fun panelHeightPx(): Int {
        val h = resources.displayMetrics.heightPixels
        return (h * heightPct / 100f).roundToInt().coerceIn(dp(540).coerceAtMost(h - dp(12)), h - dp(8))
    }

    private fun buildPanel(): View {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(Color.rgb(7, 27, 57), dp(22f))
            elevation = dp(12f).toFloat()
        }

        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "AI"
            textSize = 19f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            background = circle(Color.rgb(0, 181, 239), dp(21f))
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
        })
        header.addView(TextView(this).apply {
            text = "  ROSTIK TOUCH BOT 30.14"
            textSize = 17f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
        })
        header.addView(Button(this).apply {
            text = "−"
            textSize = 22f
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(19, 54, 96), dp(10f))
            layoutParams = LinearLayout.LayoutParams(dp(50), dp(44))
            setOnClickListener { collapse() }
        })
        outer.addView(header)

        outer.addView(TextView(this).apply {
            text = "БОЙЦЫ  •  ВЫБОР + ОЧЕРЕДЬ + КУБКИ + РАЗМЕР"
            textSize = 13f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(0, 199, 247))
            setPadding(dp(5), dp(7), dp(5), dp(5))
        })

        outer.addView(buildReferenceBody(), LinearLayout.LayoutParams(-1, 0, 1f))
        return outer
    }

    private fun buildReferenceBody(): View {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // Search is always visible and does not scroll away.
        val search = EditText(this).apply {
            hint = "🔍  Поиск..."
            textSize = 15f
            setSingleLine(true)
            setText(brawlerSearch)
            setSelection(text.length)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(137, 175, 208))
            background = rounded(Color.rgb(12, 53, 91), dp(11f))
            setPadding(dp(16), 0, dp(16), 0)
            inputType = InputType.TYPE_CLASS_TEXT
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(50)).apply { setMargins(0, dp(2), 0, dp(8)) })

        // Upper reference area: brawlers left, vertical resize sliders right.
        val upper = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        upper.addView(buildBrawlerGrid(), LinearLayout.LayoutParams(0, 0, 1f))
        upper.addView(buildSizeSliders(), LinearLayout.LayoutParams(dp(150), -1).apply { setMargins(dp(8), 0, 0, 0) })
        root.addView(upper, LinearLayout.LayoutParams(-1, 0, 1.05f))

        // Lower reference area: queue + cups editor.
        val lower = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        lower.addView(buildQueueCard(), LinearLayout.LayoutParams(0, -1, 0.62f))
        lower.addView(buildCupsCard(), LinearLayout.LayoutParams(0, -1, 0.38f).apply { setMargins(dp(8), 0, 0, 0) })
        root.addView(lower, LinearLayout.LayoutParams(-1, dp(245)).apply { setMargins(0, dp(7), 0, dp(7)) })

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        actions.addView(actionButton("START", Color.rgb(0, 196, 106), dp(54)) { startBot() }, LinearLayout.LayoutParams(0, dp(54), 1f))
        actions.addView(actionButton("ПАУЗА", Color.rgb(239, 163, 19), dp(54)) {
            if (BotRuntime.supervisor.status().contains("PAUSED")) { BotRuntime.supervisor.resume(); toast("Продолжено") }
            else { BotRuntime.supervisor.pause(); toast("Пауза") }
        }, LinearLayout.LayoutParams(0, dp(54), 1f).apply { setMargins(dp(8), 0, dp(8), 0) })
        actions.addView(actionButton("STOP", Color.rgb(232, 52, 72), dp(54)) {
            BotRuntime.supervisor.stop()
            toast("STOP")
        }, LinearLayout.LayoutParams(0, dp(54), 1f))
        root.addView(actions, LinearLayout.LayoutParams(-1, dp(54)))

        search.addTextChangedListener(simpleWatcher { text ->
            brawlerSearch = text
            brawlerScrollY = 0
            rebuildPanel()
        })
        return root
    }

    private fun buildBrawlerGrid(): View {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.rgb(6, 36, 72), dp(12f))
            setPadding(dp(6), dp(6), dp(6), dp(5))
        }

        val title = TextView(this).apply {
            text = "ВЫБЕРИТЕ БОЙЦА · ${BrawlerCatalog.all.size}/108"
            textSize = 13f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding(dp(3), dp(1), dp(3), dp(5))
            gravity = Gravity.CENTER_VERTICAL
        }
        outer.addView(title, LinearLayout.LayoutParams(-1, dp(28)))

        val filter = brawlerSearch.trim().lowercase()
        val entries = if (filter.isBlank()) BrawlerCatalog.all else BrawlerCatalog.all.filter {
            it.name.lowercase().contains(filter) || it.id.lowercase().contains(filter) || it.aliases.any { a -> a.lowercase().contains(filter) }
        }

        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val columns = 6
        entries.chunked(columns).forEach { chunk ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            repeat(columns) { index ->
                val entry = chunk.getOrNull(index)
                if (entry == null) {
                    row.addView(Space(this), LinearLayout.LayoutParams(0, dp(78), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
                } else {
                    row.addView(brawlerCell(entry), LinearLayout.LayoutParams(0, dp(78), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
                }
            }
            grid.addView(row)
        }

        val scroll = ScrollView(this).apply {
            isFillViewport = false
            isVerticalScrollBarEnabled = true
            scrollBarStyle = View.SCROLLBARS_INSIDE_INSET
            addView(grid)
            setOnScrollChangeListener { _, _, y, _, _ -> brawlerScrollY = y }
            post { scrollTo(0, brawlerScrollY.coerceAtLeast(0)) }
        }
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        return outer
    }

    private fun buildSizeSliders(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(2), 0, dp(2), 0)
        }
        box.addView(verticalSlider("Высота\nпанели", heightPct, 45, 94) { value ->
            heightPct = value
            saveSize()
            updatePanelSizeLive()
        }, LinearLayout.LayoutParams(dp(67), -1))
        box.addView(verticalSlider("Ширина\nпанели", widthPct, 45, 96) { value ->
            widthPct = value
            saveSize()
            updatePanelSizeLive()
        }, LinearLayout.LayoutParams(dp(67), -1))
        return box
    }

    private fun verticalSlider(label: String, initial: Int, min: Int, max: Int, onChange: (Int) -> Unit): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        box.addView(TextView(this).apply {
            text = label
            textSize = 10f
            setTextColor(Color.rgb(192, 220, 242))
            gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD)
            maxLines = 2
        }, LinearLayout.LayoutParams(-1, dp(42)))

        val valueText = TextView(this).apply {
            text = "$initial%"
            textSize = 12f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        box.addView(valueText, LinearLayout.LayoutParams(-1, dp(26)))

        val slider = VerticalSlider(this).apply {
            value = initial
            minValue = min
            maxValue = max
            onValueChanged = { v -> valueText.text = "$v%"; onChange(v) }
        }
        box.addView(slider, LinearLayout.LayoutParams(dp(42), 0, 1f))
        return box
    }

    private fun buildQueueCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(7), dp(8), dp(7))
            background = rounded(Color.rgb(5, 39, 77), dp(12f))
        }
        card.addView(TextView(this).apply {
            text = "ОЧЕРЕДЬ"
            textSize = 13f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding(dp(2), 0, 0, dp(5))
        }, LinearLayout.LayoutParams(-1, dp(28)))

        val queueBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (selected.isEmpty()) {
            queueBox.addView(TextView(this).apply {
                text = "Нажми на аватар бойца — он добавится в очередь"
                textSize = 11f
                setTextColor(Color.rgb(145, 178, 207))
                setPadding(dp(4), dp(8), dp(4), 0)
            })
        } else {
            selected.forEachIndexed { index, id -> queueBox.addView(queueRow(id, index + 1)) }
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = false
            addView(queueBox)
            setOnScrollChangeListener { _, _, y, _, _ -> queueScrollY = y }
            post { scrollTo(0, queueScrollY.coerceAtLeast(0)) }
        }
        card.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        return card
    }

    private fun buildCupsCard(): View {
        val id = selectedId ?: selected.firstOrNull()
        val values = id?.let { draft[it] } ?: (0 to 0)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(7), dp(10), dp(7))
            background = rounded(Color.rgb(5, 39, 77), dp(12f))
        }
        card.addView(TextView(this).apply {
            text = "🏆  КУБКИ"
            textSize = 13f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(-1, dp(27)))

        val fields = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        fields.addView(TextView(this).apply {
            text = "Текущие:"
            textSize = 10f
            setTextColor(Color.rgb(0, 211, 211))
        }, LinearLayout.LayoutParams(0, dp(42), 1f))
        val current = numberInput(values.first)
        current.setTextColor(Color.WHITE)
        fields.addView(current, LinearLayout.LayoutParams(dp(72), dp(42)))
        fields.addView(TextView(this).apply {
            text = "Цель:"
            textSize = 10f
            setTextColor(Color.rgb(0, 211, 211))
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(dp(45), dp(42)).apply { setMargins(dp(5), 0, 0, 0) })
        val target = numberInput(values.second)
        fields.addView(target, LinearLayout.LayoutParams(dp(72), dp(42)))
        card.addView(fields)

        val keypad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, 0)
        }
        val active = arrayOfNulls<EditText>(1)
        current.setOnFocusChangeListener { _, has -> if (has) active[0] = current }
        target.setOnFocusChangeListener { _, has -> if (has) active[0] = target }
        if (active[0] == null) active[0] = target

        val digits = listOf("1","2","3","4","5","6","7","8","9","0","⌫")
        digits.chunked(3).forEach { rowDigits ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            rowDigits.forEach { d ->
                row.addView(Button(this).apply {
                    text = d
                    textSize = 12f
                    setTextColor(Color.WHITE)
                    background = rounded(Color.rgb(16, 65, 110), dp(7f))
                    minWidth = 0
                    minimumWidth = 0
                    setPadding(0, 0, 0, 0)
                    layoutParams = LinearLayout.LayoutParams(0, dp(36), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
                    setOnClickListener {
                        val edit = active[0] ?: target
                        val s = edit.text.toString()
                        edit.setText(if (d == "⌫") s.dropLast(1) else if (s == "0") d else s + d)
                        edit.setSelection(edit.length())
                        commitCupValue(id, current, target)
                    }
                })
            }
            keypad.addView(row, LinearLayout.LayoutParams(-1, dp(40)))
        }
        card.addView(keypad, LinearLayout.LayoutParams(-1, 0, 1f))

        val selectHint = TextView(this).apply {
            text = id?.let { "Выбран: ${BrawlerCatalog.name(it)}" } ?: "Выбери бойца"
            textSize = 9f
            setTextColor(Color.rgb(150, 188, 218))
            gravity = Gravity.CENTER
        }
        card.addView(selectHint, LinearLayout.LayoutParams(-1, dp(22)))

        val currentWatcher = simpleWatcher { text ->
            if (id != null) {
                val old = draft[id] ?: (0 to 0)
                draft[id] = (text.toIntOrNull() ?: old.first) to old.second
                saveDraft()
            }
        }
        val targetWatcher = simpleWatcher { text ->
            if (id != null) {
                val old = draft[id] ?: (0 to 0)
                draft[id] = old.first to (text.toIntOrNull() ?: old.second)
                saveDraft()
            }
        }
        current.addTextChangedListener(currentWatcher)
        target.addTextChangedListener(targetWatcher)
        return card
    }

    private fun commitCupValue(id: String?, current: EditText, target: EditText) {
        if (id == null) return
        val old = draft[id] ?: (0 to 0)
        draft[id] = (current.text.toString().toIntOrNull() ?: old.first) to (target.text.toString().toIntOrNull() ?: old.second)
        saveDraft()
    }

    private fun brawlerCell(entry: BrawlerCatalog.Entry): View {
        val isSelected = selected.contains(entry.id)
        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(2), dp(2), dp(2), dp(1))
            background = rounded(if (isSelected) Color.rgb(24, 104, 151) else Color.rgb(10, 48, 84), dp(8f))
            contentDescription = "${entry.name}, ${if (isSelected) "выбран" else "добавить в очередь"}"
        }
        val frame = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(dp(56), dp(56)) }
        val bmp = loadAvatar(entry.id)
        if (bmp != null) {
            frame.addView(ImageView(this).apply {
                setImageBitmap(bmp)
                scaleType = ImageView.ScaleType.CENTER_CROP
                layoutParams = FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER)
            })
        } else {
            frame.addView(TextView(this).apply {
                text = initials(entry.name)
                textSize = 10f
                setTypeface(null, Typeface.BOLD)
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                background = circle(avatarColor(entry.id), dp(24f))
                layoutParams = FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER)
            })
        }
        if (isSelected) {
            frame.foreground = ringedAvatar(Color.TRANSPARENT)
        }
        cell.addView(frame)
        cell.addView(TextView(this).apply {
            text = entry.name
            textSize = 8f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(-1, dp(17)))
        cell.setOnClickListener {
            selectedId = entry.id
            if (!selected.contains(entry.id)) {
                selected.add(entry.id)
                draft.putIfAbsent(entry.id, 0 to 0)
                saveDraft()
                toast("Добавлен: ${entry.name}")
            }
            rebuildPanel()
        }
        return cell
    }

    private fun queueRow(id: String, number: Int): View {
        val v = draft[id] ?: (0 to 0)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(5), dp(5), dp(5))
            background = rounded(Color.rgb(10, 53, 96), dp(9f))
            layoutParams = LinearLayout.LayoutParams(-1, dp(62)).apply { setMargins(0, dp(3), 0, dp(3)) }
            setOnClickListener { selectedId = id; rebuildPanel() }
        }
        loadAvatar(id)?.let { bmp -> row.addView(ImageView(this).apply {
            setImageBitmap(bmp); scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42)).apply { setMargins(0, 0, dp(8), 0) }
        }) }
        row.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@OverlayService).apply { text = "$number. ${BrawlerCatalog.name(id)}"; textSize = 11f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE) })
            addView(TextView(this@OverlayService).apply { text = "Текущие: ${v.first}        Цель: ${v.second}"; textSize = 9f; setTextColor(Color.rgb(185, 214, 239)); setPadding(0, dp(4), 0, 0) })
            layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
        })
        row.addView(Button(this).apply {
            text = "×"; textSize = 16f; setTextColor(Color.WHITE); background = rounded(Color.rgb(12, 69, 116), dp(8f))
            minWidth = 0; minimumWidth = 0
            layoutParams = LinearLayout.LayoutParams(dp(38), dp(38))
            setOnClickListener { selected.remove(id); if (selectedId == id) selectedId = selected.firstOrNull(); draft.remove(id); saveDraft(); rebuildPanel() }
        })
        return row
    }

    private fun updatePanelSizeLive() {
        if (!expanded || panel == null) return
        try { wm.updateViewLayout(panel, panelParams()) } catch (_: Throwable) {}
    }

    private fun rebuildPanel() {
        if (!expanded) return
        val old = panel
        try { old?.let(wm::removeView) } catch (_: Throwable) {}
        panel = buildPanel()
        try { wm.addView(panel, panelParams()) } catch (_: Throwable) {
            panel = null
            expanded = false
            showBubble()
        }
    }

    private fun startBot() {
        if (BotAccessibilityService.instance == null) {
            toast("Включи Accessibility перед START")
            return
        }
        if (!BotRuntime.captureActive) {
            toast("Сначала включи захват экрана в разделе РАЗРЕШЕНИЯ")
            return
        }
        val items = selected.map { id ->
            val v = draft[id] ?: (0 to 0)
            QueueItem(id, v.first, v.second)
        }.filter { it.currentCups < it.targetCups }
        if (items.isEmpty()) {
            toast("Выбери бойцов и поставь цель выше текущих кубков")
            return
        }
        BotRuntime.queue.replace(items)
        saveDraft()
        BotRuntime.supervisor.start()
        toast("START — очередь запущена")
        collapse()
    }

    private fun loadDraft() {
        val sp = getSharedPreferences("v30", MODE_PRIVATE)
        sp.getString("queue", "")?.takeIf { it.isNotBlank() }?.split(';')?.forEach { item ->
            val p = item.split(':')
            if (p.size == 3) {
                val c = p[1].toIntOrNull()
                val t = p[2].toIntOrNull()
                if (c != null && t != null && BrawlerCatalog.all.any { it.id == p[0] }) {
                    selected.add(p[0])
                    draft[p[0]] = c to t
                }
            }
        }
        selectedId = selected.firstOrNull()
    }

    private fun saveDraft() {
        getSharedPreferences("v30", MODE_PRIVATE).edit()
            .putString("queue", selected.joinToString(";") { id ->
                val v = draft[id] ?: (0 to 0)
                "$id:${v.first}:${v.second}"
            }).apply()
    }

    private fun loadSize() {
        val sp = getSharedPreferences("v30", MODE_PRIVATE)
        widthPct = sp.getInt("width_pct", 54).coerceIn(45, 96)
        heightPct = sp.getInt("height_pct", 90).coerceIn(45, 94)
    }

    private fun saveSize() {
        getSharedPreferences("v30", MODE_PRIVATE).edit()
            .putInt("width_pct", widthPct)
            .putInt("height_pct", heightPct)
            .apply()
    }

    private fun loadAvatar(id: String): Bitmap? = try {
        assets.open("brawler_icons/$id.png").use { BitmapFactory.decodeStream(it) }
    } catch (_: Throwable) { null }

    private fun numberInput(value: Int) = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER
        setText(value.toString())
        setTextColor(Color.WHITE)
        textSize = 12f
        gravity = Gravity.CENTER
        setSingleLine(true)
        background = rounded(Color.rgb(22, 67, 111), dp(8f))
        setSelectAllOnFocus(true)
    }

    private fun simpleWatcher(after: (String) -> Unit) = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, afterCount: Int) = Unit
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { after(s?.toString() ?: "") }
        override fun afterTextChanged(s: Editable?) = Unit
    }

    private fun actionButton(text: String, color: Int, height: Int, click: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(Color.WHITE)
        setTypeface(null, Typeface.BOLD)
        background = rounded(color, dp(10f))
        minHeight = height
        setOnClickListener { click() }
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun dp(v: Float): Int = (v * resources.displayMetrics.density).roundToInt()
    private fun circle(color: Int, radius: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }
    private fun ringedAvatar(color: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color); setStroke(dp(3), Color.rgb(36, 193, 255)) }
    private fun avatarColor(id: String): Int { var h = id.hashCode(); h = h xor (h ushr 16); return Color.rgb(45 + (h and 0x7F), 65 + ((h ushr 8) and 0x7F), 90 + ((h ushr 16) and 0x7F)) }
    private fun initials(name: String): String = name.replace("-", " ").split(' ').filter { it.isNotBlank() }.take(2).joinToString("") { it.first().toString() }

    override fun onBind(intent: Intent?): IBinder? = null

    private var dragging = false
    private inner class DragTouchListener(private val moved: (Int, Int) -> Unit) : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dragging = false; downX = e.rawX; downY = e.rawY; startX = bubbleX; startY = bubbleY; return true }
                MotionEvent.ACTION_MOVE -> {
                    val nx = startX + (e.rawX - downX).roundToInt()
                    val ny = startY + (e.rawY - downY).roundToInt()
                    if (abs(e.rawX - downX) > 8 || abs(e.rawY - downY) > 8) dragging = true
                    if (dragging) moved(nx.coerceAtLeast(0), ny.coerceAtLeast(0))
                    return true
                }
                MotionEvent.ACTION_UP -> { if (!dragging) v.performClick(); return true }
            }
            return false
        }
    }

    /** A native-free vertical slider that works reliably inside an overlay. */
    private class VerticalSlider(context: Context) : View(context) {
        var minValue = 0
        var maxValue = 100
        var value = 50
            set(v) { field = v.coerceIn(minValue, maxValue); invalidate() }
        var onValueChanged: ((Int) -> Unit)? = null
        private val track = Paint(Paint.ANTI_ALIAS_FLAG)
        private var dragging = false

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val top = dp(16).toFloat()
            val bottom = height - dp(16).toFloat()
            track.color = Color.rgb(20, 70, 113)
            track.strokeWidth = dp(10).toFloat()
            track.strokeCap = Paint.Cap.ROUND
            canvas.drawLine(cx, top, cx, bottom, track)

            val frac = (value - minValue).toFloat() / (maxValue - minValue).coerceAtLeast(1)
            val y = bottom - frac * (bottom - top)
            track.color = Color.rgb(0, 185, 240)
            canvas.drawLine(cx, bottom, cx, y, track)

            track.color = Color.WHITE
            canvas.drawCircle(cx, y, dp(13).toFloat(), track)
            track.color = Color.rgb(10, 44, 76)
            canvas.drawCircle(cx, y, dp(6).toFloat(), track)

            track.color = Color.WHITE
            track.textSize = dp(18).toFloat()
            track.textAlign = Paint.Align.CENTER
            canvas.drawText("↑", cx, dp(12).toFloat(), track)
            canvas.drawText("↓", cx, height - dp(1).toFloat(), track)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            val top = dp(16).toFloat()
            val bottom = height - dp(16).toFloat()
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    dragging = true
                    val frac = ((bottom - event.y) / (bottom - top)).coerceIn(0f, 1f)
                    value = (minValue + frac * (maxValue - minValue)).roundToInt()
                    onValueChanged?.invoke(value)
                    return true
                }
                MotionEvent.ACTION_UP -> { dragging = false; performClick(); return true }
            }
            return true
        }

        override fun performClick(): Boolean { super.performClick(); return true }
        private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()
    }
}
