#!/usr/bin/env python3
from pathlib import Path
import re, sys
root = Path('.')
java = root/'app/src/main/java'
kt = sorted(java.rglob('*.kt'))
assert len(kt) == 39, f'expected 39 Kotlin files, got {len(kt)}'
errors=[]
seen_classes={}
for f in kt:
    s=f.read_text(encoding='utf-8')
    if not re.search(r'^package\s+com\.rostik\.touchbot\s*$', s, re.M):
        errors.append(f'{f}: missing/wrong package')
    if '\x00' in s: errors.append(f'{f}: NUL byte')
    if '!!' in s: errors.append(f'{f}: non-null assertion (!!)')
    if re.search(r'NotImplementedException|UnsupportedOperationException|TODO|FIXME|IMPLEMENT_ME|PLACEHOLDER', s):
        errors.append(f'{f}: placeholder marker')
    for m in re.finditer(r'(?m)^(class|object|interface|enum\s+class)\s+([A-Za-z_][A-Za-z0-9_]*)', s):
        key=m.group(2)
        if key in seen_classes: errors.append(f'duplicate top-level type {key}: {f} and {seen_classes[key]}')
        else: seen_classes[key]=str(f)
    # Catch the common broken assignment pattern from the old OverlayService fix.
    if re.search(r'(?m)^\s*text\s*=\s*text\s*$', s) and f.name == 'OverlayService.kt':
        errors.append(f'{f}: ambiguous self-assignment')
# Required production entry points.
overlay_text = (root/'app/src/main/java/com/rostik/touchbot/OverlayService.kt').read_text(encoding='utf-8')
for marker, msg in [
    ('sizeSlider("ШИРИНА"', 'width slider missing'),
    ('sizeSlider("ВЫСОТА"', 'height slider missing'),
    ('TYPE_CLASS_NUMBER', 'numeric trophy input missing'),
    ('take(5)', 'multi-digit trophy guard missing'),
    ('coerceIn(0, 10000)', 'trophy range guard missing'),
    ('wm.updateViewLayout', 'live resize missing'),
    ('QueueItem(id, v.first, v.second)', 'queue does not receive trophy values'),
]:
    if marker not in overlay_text: errors.append('OverlayService.kt: '+msg)
required = [
 'MainActivity.kt','OverlayService.kt','BotRuntime.kt','MatchSupervisor.kt',
 'ScreenCaptureService.kt','BotAccessibilityService.kt','MatchVision.kt',
 'NavigationVision.kt','QueueEngine.kt','BrawlerCatalog.kt','TrophyReader.kt'
]
for name in required:
    if not any(f.name == name for f in kt): errors.append(f'missing {name}')
if errors:
    print('CI_SOURCE_AUDIT_FAIL')
    print('\n'.join(errors))
    sys.exit(1)
print('CI_SOURCE_AUDIT_PASS')
print(f'kotlin_files={len(kt)} top_level_types={len(seen_classes)}')
