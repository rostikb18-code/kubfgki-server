# RostikAI v31.1.3 V12 — GitHub upload package

## Upload exactly like this

1. Upload the five ZIP parts to the repository **root**:
   - `RostikAI-v31.1.3-MERGED-ANDROID-PROJECT-PART-01.zip`
   - `RostikAI-v31.1.3-MERGED-ANDROID-PROJECT-PART-02.zip`
   - `RostikAI-v31.1.3-MERGED-ANDROID-PROJECT-PART-03.zip`
   - `RostikAI-v31.1.3-MERGED-ANDROID-PROJECT-PART-04.zip`
   - `RostikAI-v31.1.3-MERGED-ANDROID-PROJECT-PART-05.zip`
2. Upload `SHA256.txt` to the repository **root**.
3. Upload `build.yml` specifically as **`.github/workflows/build.yml`**. Do not leave it only in the repository root.

Each ZIP is below GitHub's browser-upload limit. The workflow verifies every SHA-256, tests every ZIP, rejects duplicate paths, reconstructs the Android project, runs the source audits, then compiles and packages the APKs.

## Successful result

Open GitHub **Actions** → `RostikAI v31.1.3 - Android Build + Full Verify`. After the run is green, download the artifact named `RostikAI-v31.1.3-APKs`.

## UI contracts verified

- Width slider: 55–96%, live resize, persisted.
- Height slider: 55–96%, live resize, persisted.
- Current trophies: numeric multi-digit input, 0–10000.
- Target trophies: numeric multi-digit input, 0–10000.
- Both trophy values are propagated into `QueueItem` and persisted.
- 108 brawler icons and 108 catalog entries are retained.

## Honest limitation

This package has been statically audited and reassembled here. This environment does not have the Android SDK/Gradle installation needed for a local APK compilation, so the authoritative compilation test is the GitHub Actions runner.
