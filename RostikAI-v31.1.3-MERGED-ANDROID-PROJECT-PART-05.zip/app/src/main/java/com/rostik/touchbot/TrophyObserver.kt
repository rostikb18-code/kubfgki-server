package com.rostik.touchbot

import android.content.Context
import java.io.File
import java.security.MessageDigest
import java.time.Instant

/** Kotlin port of the supplied Python TrophyObserver: trophy arithmetic, streaks and CSV history. */
class TrophyObserver(private val context: Context) {
    data class Record(
        val dateTime: String,
        val brawler: String,
        val result: String,
        val startedTrophies: Int,
        val trophyDelta: Int,
        val trophies: Int,
        val winStreak: Int,
        val currentWins: Int,
        val sessionWins: Int,
        val sessionLosses: Int,
        val sessionDraws: Int,
        val expectedDelta: Int,
        val expectedMatches: Boolean,
        val playstyleHash: String,
        val playstyleName: String,
        val playstyleGamemodes: String,
        val playstyleBrawlers: String,
        val powerLevel: Int
    )

    private val prefs = context.getSharedPreferences("trophy_observer", Context.MODE_PRIVATE)
    private val history = File(context.filesDir, "match_history.csv")
    private var currentTrophies: Int? = null
    var currentWins: Int = prefs.getInt("wins", 0)
        private set
    var winStreak: Int = prefs.getInt("streak", 0)
        private set
    private var sessionWins = 0
    private var sessionLosses = 0
    private var sessionDraws = 0

    @Synchronized
    fun initialize(trophies: Int, wins: Int = currentWins, streak: Int = winStreak) {
        currentTrophies = trophies.coerceIn(0, 10000)
        currentWins = wins.coerceAtLeast(0)
        winStreak = streak.coerceAtLeast(0)
    }

    @Synchronized
    fun setTrophies(value: Int) { currentTrophies = value.coerceIn(0, 10000) }

    fun sessionStats(): Map<String, Int> = mapOf(
        "session_wins" to sessionWins,
        "session_losses" to sessionLosses,
        "session_draws" to sessionDraws
    )

    @Synchronized
    fun record(
        gameResult: String,
        brawler: String,
        playstyleName: String = "Brawl Ball",
        playstyleGamemodes: List<String> = listOf("brawl_ball"),
        playstyleBrawlers: List<String> = listOf(brawler),
        powerLevel: Int = -1,
        multiplier: Int = 1,
        observedDelta: Int? = null
    ): Record {
        val old = currentTrophies ?: 0
        val raw = gameResult.trim().lowercase()
        val canonical = when {
            raw == "victory" -> "victory"
            raw == "defeat" -> "defeat"
            raw == "draw" -> "draw"
            raw.startsWith("trio_showdown_") || raw.startsWith("showdown_") -> raw
            else -> throw IllegalArgumentException("Unknown match result: $gameResult")
        }
        val (ruleDelta, newStreak) = TrophyRules.delta(old, winStreak, canonical, multiplier)
        // Prefer a confirmed on-screen trophy delta when it is plausible.
        // Rules remain the fallback and still validate the expected result.
        val delta = observedDelta?.takeIf { it in -120..120 } ?: ruleDelta
        winStreak = newStreak
        val normalized = when {
            canonical.startsWith("trio_showdown_") || canonical.startsWith("showdown_") -> {
                val place = canonical.substringAfterLast('_').toIntOrNull() ?: 3
                when {
                    place < 2 -> "victory"
                    place == 2 -> "draw"
                    else -> "defeat"
                }
            }
            else -> canonical
        }
        when (normalized) {
            "victory" -> { currentWins++; sessionWins++ }
            "defeat" -> sessionLosses++
            "draw" -> sessionDraws++
        }
        val newTrophies = (old + delta).coerceIn(0, 10000)
        currentTrophies = newTrophies
        prefs.edit().putInt("wins", currentWins).putInt("streak", winStreak).apply()

        val record = Record(
            dateTime = Instant.now().toString(),
            brawler = brawler,
            result = displayResult(canonical),
            startedTrophies = old,
            trophyDelta = newTrophies - old,
            trophies = newTrophies,
            winStreak = winStreak,
            currentWins = currentWins,
            sessionWins = sessionWins,
            sessionLosses = sessionLosses,
            sessionDraws = sessionDraws,
            expectedDelta = ruleDelta,
            expectedMatches = ruleDelta == newTrophies - old,
            playstyleHash = hashPlaystyle(playstyleName, playstyleGamemodes, playstyleBrawlers),
            playstyleName = playstyleName,
            playstyleGamemodes = playstyleGamemodes.joinToString("|"),
            playstyleBrawlers = playstyleBrawlers.joinToString("|"),
            powerLevel = powerLevel
        )
        append(record)
        return record
    }

    private fun displayResult(value: String): String {
        if (value.contains("showdown")) {
            return when (value.substringAfterLast('_').toIntOrNull()) {
                0 -> "1st"
                1 -> "2nd"
                2 -> "3rd"
                3 -> "4th"
                else -> value
            }
        }
        return value
    }

    private fun hashPlaystyle(name: String, modes: List<String>, brawlers: List<String>): String {
        val input = "$name|${modes.joinToString("|")}|${brawlers.joinToString("|")}"
        return MessageDigest.getInstance("SHA-256")
            .digest(input.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    private fun append(record: Record) {
        history.parentFile?.mkdirs()
        if (!history.exists()) {
            history.writeText("date_time,brawler_name,result,current_trophies,trophy_delta,new_winstreak,trophies,current_wins,session_wins,session_losses,session_draws,expected_delta,expected_delta_match,playstyle_hash,playstyle_name,playstyle_gamemodes,playstyle_brawlers,power_level\n")
        }
        val values = listOf(
            record.dateTime, record.brawler, record.result, record.startedTrophies,
            record.trophyDelta, record.winStreak, record.trophies, record.currentWins,
            record.sessionWins, record.sessionLosses, record.sessionDraws,
            record.expectedDelta, record.expectedMatches, record.playstyleHash,
            record.playstyleName, record.playstyleGamemodes, record.playstyleBrawlers,
            record.powerLevel
        )
        history.appendText(values.joinToString(",") { csv(it.toString()) } + "\n")
    }

    private fun csv(value: String): String = "\"${value.replace("\"", "\"\"")}\""
}
