# RostikAI v31.1

Обновлённая стабильная база RostikTouchBot с усиленной инфраструктурой, перенесёнными визуальными ресурсами из предоставленного APK и исправлениями длительных матчей.

## Что сохранено
- QueueEngine: несколько бойцов, current/target trophies.
- MatchSupervisor: SELECT_BRAWLER → Brawl Ball → PLAY → MATCH → RESULT → REWARD → PLAY AGAIN → следующий боец.
- OCR/ML Kit.
- MediaProjection screen capture.
- Accessibility gestures.
- Overlay AI button + панель выбора бойцов.
- 108 бrawler entries и исходные иконки.

## Что добавлено/усилено
- Второй набор визуальных brawler assets из предоставленного APK в `assets/apk_port/brawler_icons`.
- 88 Brawl Ball maps из APK в `assets/apk_port/maps/brawl_ball_maps.json` и `BrawlBallMapCatalog` для дальнейшего map-aware vision.
- Lobby/result/reward visual assets из APK.
- Модельные файлы APK сохранены в `assets/apk_port/models` как исходные данные для последующего подключения совместимого inference pipeline. Они не запускаются автоматически и не требуют anti-debug/stealth слоя APK.
- BrawlerSelector теперь имеет дополнительный visual fallback через APK assets.
- Accessibility gestures сериализованы: одновременно выполняется только один gesture, есть callback completion и timeout recovery.
- Match watchdog: при краткой потере player/vision бот продолжает короткое movement heartbeat, чтобы не оставаться полностью без ввода.
- `PLAYING` больше не завершается через 180 секунд; установлен длинный recovery timeout 15 минут, а нормальный RESULT по-прежнему завершает матч значительно раньше.
- ScreenCaptureService получил frame watchdog, который восстанавливает ImageReader/VirtualDisplay после зависания потока кадров.
- Запуск Brawl Stars после выдачи MediaProjection теперь ждёт подтверждения активности capture, а не полагается на один таймер.
- GitHub Actions разделён на отдельные зелёные/красные проверки: структура, 108 бойцов, APK assets, карты, watchdog, compile Debug, compile Release, Debug APK, Release APK.

## Важно
Скомпилированный APK не позволяет честно восстановить его оригинальный Kotlin-код 1:1. В этот проект перенесены доступные визуальные данные и воспроизведена функциональность на уровне открытого исходника. Anti-debug/anti-Frida защитный слой исходного APK намеренно не переносится.


## v31.1 reliability/gameplay upgrades

- Replaced the conflated Bitmap channel with an atomic latest-frame handoff so dropped frames are explicitly recycled instead of being leaked.
- Added frame-processing telemetry to the supervisor status (processed FPS and last processing time).
- Added `Detection.velocity` temporal tracking for player, enemy and ball detections.
- Added explicit right-stick aim vectors for attacks instead of relying only on game auto-aim.
- Added predictive enemy aim using short-horizon velocity.
- Added `MapPlanner` with A* pathing over the imported 33x21 Brawl Ball occupancy maps; `#` and `W` are treated as hard obstacles.
- Added active-map recognition from OCR in the Brawl Ball lobby and feeds the detected map into the movement planner.
- Added crash/process-death queue persistence and automatic restoration.
- Added an explicit empty-gesture guard so no invalid empty Accessibility gesture is submitted.
- Version bumped to 31.1.0 / versionCode 51.

The project still cannot honestly claim empirical device validation until the generated APK is installed and tested on a real Android device. No anti-debug/anti-Frida or anti-cheat evasion logic is included.
