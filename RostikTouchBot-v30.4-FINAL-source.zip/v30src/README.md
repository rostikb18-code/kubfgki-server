# Rostik Touch Bot v30.4

v30.4 is the UI/vision/navigation revision based on the supplied Brawl Stars screenshots and the supplied gameplay video.

## App flow

- MainActivity: ИГРАТЬ / СТАТИСТИКА / РАЗРЕШЕНИЯ
- ИГРАТЬ starts the overlay and opens Brawl Stars after capture permission.
- Floating AI bubble stays over the game.
- AI panel: БОТ / ОЧЕРЕДЬ / РАЗМЕР.
- Queue: all 108 catalog entries are visible; selected fighters appear in the right queue with current/target cups.
- Size: overlay width/height are configurable and persisted.
- Statistics: total time, net cups, matches, wins/losses/draws and win rate.

## v30.4 vision/navigation changes

- Brawler selection uses visual reference matching plus OCR, with whole-grid low-resolution scanning instead of only a fixed 5x3 coordinate table.
- Brawler scrolling is verified with a frame fingerprint and reverses direction if the list does not change.
- Critical navigation does not tap an arbitrary mode. It searches specifically for Brawl Ball and only uses a coordinate fallback after a whole-screen reference match.
- The Brawl Ball lobby from the supplied video is included as a reference.
- Play and Play Again have OCR plus a constrained yellow-action visual fallback.
- Match entry requires repeated game-HUD evidence including both joystick regions; a single false player detection cannot immediately start the match.
- A missing player for a few frames is treated as temporary perception loss rather than a match end.
- Result cup deltas require repeated confirmation before statistics/queue progress are updated.
- The old hard-coded `nearest to 800` cup heuristic was removed; the configured current-cup value is used as the expected value.
- Gameplay dispatch uses detected joystick positions when available.

## Important limitation

The gameplay controller is still a deterministic reactive controller, not a trained neural policy. The vision/navigation and UI are hardened, but match win rate cannot be guaranteed from source code alone. The app deliberately stops instead of issuing a blind action when a critical screen cannot be confirmed.

The catalog contains 108 brawler IDs. The supplied screenshots provide visual assets for 91 of them; the remaining catalog entries are still selectable in the UI and use OCR/name matching until dedicated reference images are supplied.


## v30.4 UI update

- Queue selection now renders the 108 brawler entries in fixed weighted rows; the previous zero-width GridLayout issue is removed.
- The BOT tab contains only statistics plus START / PAUSE / STOP.
- STOP stops the supervisor and destroys the overlay; the AI bubble returns only after pressing ИГРАТЬ in the main app again.
- The main СТАТИСТИКА screen no longer has a reset button and uses a compact 2x2 dashboard plus result summary.

## Avatar assets

The project contains exact avatar/reference assets extracted from the supplied brawler screenshots where available. The current supplied screenshot set provides exact assets for 91 of the 108 catalog entries; the remaining 17 catalog IDs are still selectable and use the built-in initials fallback until source pixels for those specific portraits are supplied.


## v30.4 UI / identity
- Queue uses a compact five-column mini-avatar grid so 108 brawler entries remain scrollable instead of filling the overlay.
- Every avatar cell is bound to its exact `BrawlerCatalog.Entry.id`; tapping it immediately shows the brawler name and persists that ID into the queue.
- Each cell exposes a descriptive accessibility label with the brawler name.
- When the bot selects a brawler, `BrawlerSelector` prefers the matching visual reference and does not use a blind coordinate fallback. If an entry has no local visual reference, only an exact OCR alias can be used, followed by the existing visual/OCR verification state.
- Current bundled assets contain 91 real avatar/reference pairs; 17 catalog entries still use a compact initials fallback because their original avatar files were not present in the supplied asset set.
