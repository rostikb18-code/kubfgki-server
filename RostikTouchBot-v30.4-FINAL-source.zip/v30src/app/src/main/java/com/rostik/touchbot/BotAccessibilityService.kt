package com.rostik.touchbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class BotAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: BotAccessibilityService? = null }

    override fun onServiceConnected(){
        super.onServiceConnected()
        instance=this
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt(){}

    override fun onDestroy(){
        if(instance===this) instance=null
        super.onDestroy()
    }

    fun dispatch(frame:ControlFrame, left:Point, right:Point, duration:Long=80L):Boolean {
        val builder=GestureDescription.Builder()
        val lp=Path().apply{moveTo(left.x*resources.displayMetrics.widthPixels,left.y*resources.displayMetrics.heightPixels);lineTo(
            (left.x+frame.moveX*.12f).coerceIn(0f,1f)*resources.displayMetrics.widthPixels,
            (left.y+frame.moveY*.12f).coerceIn(0f,1f)*resources.displayMetrics.heightPixels)}
        builder.addStroke(GestureDescription.StrokeDescription(lp,0,duration))
        val rp=Path().apply{moveTo(right.x*resources.displayMetrics.widthPixels,right.y*resources.displayMetrics.heightPixels);lineTo(
            (right.x+frame.aimX*.14f).coerceIn(0f,1f)*resources.displayMetrics.widthPixels,
            (right.y+frame.aimY*.14f).coerceIn(0f,1f)*resources.displayMetrics.heightPixels)}
        if(frame.fire || kotlin.math.abs(frame.aimX)+kotlin.math.abs(frame.aimY)>.05f)
            builder.addStroke(GestureDescription.StrokeDescription(rp,0,duration))
        if(frame.useSuper && frame.superPoint!=null){
            val s=Path().apply{
                moveTo(frame.superPoint.x*resources.displayMetrics.widthPixels,frame.superPoint.y*resources.displayMetrics.heightPixels)
                lineTo(frame.superPoint.x*resources.displayMetrics.widthPixels,frame.superPoint.y*resources.displayMetrics.heightPixels)
            }
            builder.addStroke(GestureDescription.StrokeDescription(s,0,55L))
        }
        return dispatchGesture(builder.build(),null,null)
    }

    fun swipe(from: Point, to: Point, duration: Long = 420L): Boolean {
        val w = resources.displayMetrics.widthPixels
        val h = resources.displayMetrics.heightPixels
        val path = Path().apply {
            moveTo(from.x * w, from.y * h)
            lineTo(to.x * w, to.y * h)
        }
        return dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
                .build(), null, null
        )
    }

    fun tap(p:Point):Boolean{
        val x=p.x*resources.displayMetrics.widthPixels
        val y=p.y*resources.displayMetrics.heightPixels
        val path=Path().apply{moveTo(x,y);lineTo(x,y)}
        return dispatchGesture(GestureDescription.Builder().addStroke(
            GestureDescription.StrokeDescription(path,0,55L)).build(),null,null)
    }
}
