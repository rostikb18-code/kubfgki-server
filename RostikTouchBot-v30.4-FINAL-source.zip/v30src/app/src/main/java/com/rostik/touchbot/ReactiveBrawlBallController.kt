package com.rostik.touchbot

import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class ReactiveBrawlBallController {
    private var lastSuperAt = 0L
    private var lastDodgeAt = 0L
    private var patrolSign = 1f
    private var patrolUntil = 0L

    fun next(scene: MatchScene, now: Long, matchElapsedMs: Long): ControlFrame {
        val p=scene.player ?: return ControlFrame(moveY=.25f)
        if(now>=patrolUntil){
            patrolSign = if(Random.nextBoolean()) 1f else -1f
            patrolUntil = now + 900L + Random.nextLong(0,700)
        }

        val enemy=scene.enemies.minByOrNull{distance(it.point,p.point)}
        val ball=scene.ball
        val enemyThreat=enemy!=null && distance(enemy.point,p.point)<.20f

        if(enemyThreat && now-lastDodgeAt>800L){
            val dx=-(enemy!!.point.y-p.point.y)
            val dy=(enemy.point.x-p.point.x)
            val mag=max(.001f,hypot(dx.toDouble(),dy.toDouble()).toFloat())
            lastDodgeAt=now
            return ControlFrame(moveX=(dx/mag*patrolSign).coerceIn(-1f,1f),moveY=(dy/mag*patrolSign).coerceIn(-1f,1f))
        }

        val ballClose=ball!=null && distance(ball.point,p.point)<.13f
        val enemyBlocks=enemy!=null && ball!=null && isBetween(p.point,ball.point,enemy.point)
        val upwardAlly=scene.allies.filter{it.point.y<.35f && ball!=null && it.point.y<ball.point.y}
            .maxByOrNull{it.confidence}

        val attackPoint=when{
            enemyBlocks -> enemy!!.point
            ballClose && upwardAlly!=null -> upwardAlly.point
            ballClose -> Point(.5f,.08f)
            enemy!=null && distance(enemy.point,p.point)<.32f -> enemy.point
            else -> null
        }

        val aim=attackPoint ?: Point(.5f,.08f)
        val ax=(aim.x-p.point.x).coerceIn(-1f,1f)
        val ay=(aim.y-p.point.y).coerceIn(-1f,1f)

        val defendX=(.5f-p.point.x)*1.3f + patrolSign*.22f
        val defendY=(.73f-p.point.y)*1.3f
        val moveX=if(ball!=null && distance(ball.point,p.point)<.22f) (ball.point.x-p.point.x)*1.8f else defendX
        val moveY=if(ball!=null && distance(ball.point,p.point)<.22f) (ball.point.y-p.point.y)*1.5f else defendY

        val fire=attackPoint!=null
        val opportunity=enemy!=null && (enemyBlocks || ballClose || distance(enemy.point,p.point)<.30f)
        val useSuper=scene.superReady && opportunity && matchElapsedMs>=20_000L && now-lastSuperAt>=1_800L
        if(useSuper) lastSuperAt=now

        return ControlFrame(
            moveX=moveX.coerceIn(-1f,1f),
            moveY=moveY.coerceIn(-1f,1f),
            aimX=ax, aimY=ay, fire=fire,
            useSuper=useSuper, superPoint=scene.superPoint
        )
    }

    private fun isBetween(a:Point,b:Point,c:Point):Boolean{
        val abx=b.x-a.x; val aby=b.y-a.y
        val acx=c.x-a.x; val acy=c.y-a.y
        val len2=abx*abx+aby*aby
        if(len2<.0001f) return false
        val t=((acx*abx+acy*aby)/len2)
        if(t !in .12f..1.05f) return false
        val px=a.x+abx*t; val py=a.y+aby*t
        return hypot((c.x-px).toDouble(),(c.y-py).toDouble()).toFloat()<.09f
    }

    private fun distance(a:Point,b:Point)=hypot((a.x-b.x).toDouble(),(a.y-b.y).toDouble()).toFloat()
}
