package com.rostik.touchbot

import android.content.res.AssetManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Adaptive brawler-card matcher.
 *
 * The live screen is searched in two independent ways:
 *  - OCR identifies the card label when readable;
 *  - a low-resolution visual scan searches the whole brawler grid, so the
 *    selector is not tied to a fixed 5x3 coordinate table.
 *
 * The caller must still verify the tap on a subsequent frame.
 */
class BrawlerSelector(private val assets: AssetManager) {
    data class Target(val point: Point, val confidence: Float, val source: String)

    private val cache = HashMap<String, Bitmap?>()
    private var lastGridFingerprint = 0L
    private var lastScrollAt = 0L

    fun findByOcr(lines: List<OcrLine>, id: String): Target? {
        val aliases = BrawlerCatalog.aliases(id).map(::norm).filter { it.length >= 3 }
        val line = lines.asSequence()
            .filter { it.rect.t > .08f && it.rect.b < .95f }
            .mapNotNull { line ->
                val value = norm(line.text)
                if (aliases.any { a -> value == a || value.contains(a) || (a.contains(value) && value.length >= 4) }) line else null
            }
            .maxByOrNull { scoreTextLine(it, aliases) }
            ?: return null

        val cy = line.rect.center().y
        // Name labels are at the lower part of a card. Move to the card body,
        // but clamp aggressively so a two-line OCR box cannot jump to another row.
        val y = (cy - 0.075f).coerceIn(.13f, .90f)
        return Target(Point(line.rect.center().x.coerceIn(.03f, .97f), y), scoreTextLine(line, aliases), "OCR")
    }

    fun findByAvatar(bitmap: Bitmap, id: String): Target? {
        val template = loadTemplate(id) ?: return null
        val direct = scanWholeGrid(bitmap, template)
        if (direct != null) return direct
        return scanExpectedGrid(bitmap, template)
    }

    fun find(bitmap: Bitmap, lines: List<OcrLine>, id: String): Target? {
        val visual = findByAvatar(bitmap, id)
        val ocr = findByOcr(lines, id)
        if (visual != null && ocr != null) {
            val close = distance(visual.point, ocr.point) < .16f
            val boost = if (close) .08f else 0f
            return Target(visual.point, (visual.confidence + boost).coerceAtMost(.99f), "AVATAR+OCR")
        }
        // If a local avatar reference exists, never fall back to a blind coordinate.
        // For catalog entries without a supplied visual reference, an exact OCR alias
        // is the only fallback; the supervisor still verifies the selected brawler
        // on a subsequent frame before continuing.
        if (templateExists(id)) {
            return visual
        }
        if (ocr != null && ocr.confidence >= .96f) return ocr
        return null
    }

    private fun templateExists(id: String): Boolean {
        if (cache.containsKey(id)) return cache[id] != null
        return loadTemplate(id) != null
    }

    fun scrollPoint(direction: Int = 1): Pair<Point, Point> =
        if (direction >= 0) Point(.52f, .80f) to Point(.52f, .30f)
        else Point(.52f, .30f) to Point(.52f, .80f)

    fun shouldScroll(now: Long): Boolean = now - lastScrollAt >= 850L
    fun markScroll(now: Long) { lastScrollAt = now }

    fun gridFingerprint(bitmap: Bitmap): Long {
        val small = Bitmap.createScaledBitmap(bitmap, 40, 24, true)
        val pixels = IntArray(40 * 24)
        small.getPixels(pixels, 0, 40, 0, 0, 40, 24)
        var h = 1469598103934665603L
        for (i in pixels.indices step 3) {
            h = h xor pixels[i].toLong()
            h *= 1099511628211L
        }
        if (small !== bitmap) small.recycle()
        lastGridFingerprint = h
        return h
    }

    private fun scanWholeGrid(src: Bitmap, template: Bitmap): Target? {
        val sw = 160
        val sh = max(74, (src.height * sw.toFloat() / src.width).toInt())
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val pixels = IntArray(sw * sh)
        small.getPixels(pixels, 0, sw, 0, 0, sw, sh)

        val tw = 32
        val th = 15
        val t = Bitmap.createScaledBitmap(template, tw, th, true)
        val tp = IntArray(tw * th)
        t.getPixels(tp, 0, tw, 0, 0, tw, th)

        var bestScore = -1f
        var bestX = -1
        var bestY = -1
        var second = -1f
        val cw = max(25, (sw * .178f).toInt())
        val ch = max(13, (sh * .175f).toInt())
        val step = 3
        val yMin = (sh * .10f).toInt().coerceAtLeast(0)
        val yMax = (sh * .90f).toInt().coerceAtMost(sh - ch - 1)

        var y = yMin
        while (y <= yMax) {
            var x = 0
            while (x <= sw - cw) {
                val score = patchScore(pixels, sw, sh, x, y, cw, ch, tp, tw, th)
                if (score > bestScore) { second = bestScore; bestScore = score; bestX = x; bestY = y }
                else if (score > second) second = score
                x += step
            }
            y += step
        }
        if (small !== src) small.recycle()
        t.recycle()

        if (bestX < 0 || bestScore < .80f) return null
        val margin = (bestScore - second).coerceAtLeast(0f)
        val confidence = (bestScore * .78f + min(1f, margin * 4.5f) * .22f).coerceIn(0f, .99f)
        if (confidence < .82f) return null
        return Target(
            Point(((bestX + cw / 2f) / sw).coerceIn(.02f, .98f), ((bestY + ch * .52f) / sh).coerceIn(.10f, .92f)),
            confidence,
            "AVATAR_SCAN"
        )
    }

    private fun scanExpectedGrid(src: Bitmap, template: Bitmap): Target? {
        // Fallback only after the adaptive scan. This keeps the known reference
        // layout useful on the supplied 1280x588 screenshots without making it
        // the primary coordinate system.
        val best = mutableListOf<Target>()
        for (row in 0 until 3) for (col in 0 until 5) {
            val card = cropReferenceGrid(src, col, row) ?: continue
            val score = similarity(template, card)
            card.recycle()
            if (score >= .82f) best += Target(cardCenter(col, row), score, "REFERENCE_GRID")
        }
        return best.maxByOrNull { it.confidence }
    }

    private fun loadTemplate(id: String): Bitmap? {
        if (cache.containsKey(id)) return cache[id]
        val b = try {
            assets.open("brawler_refs/$id.png").use { BitmapFactory.decodeStream(it) }
        } catch (_: Throwable) { null }
        cache[id] = b
        return b
    }

    private fun cropReferenceGrid(src: Bitmap, col: Int, row: Int): Bitmap? {
        val w = src.width; val h = src.height
        val left = ((.005f + col * .195f) * w).toInt().coerceAtLeast(0)
        val right = ((.182f + col * .195f) * w).toInt().coerceAtMost(w)
        val top = ((.162f + row * .272f) * h).toInt().coerceAtLeast(0)
        val bottom = ((.335f + row * .272f) * h).toInt().coerceAtMost(h)
        if (right - left < 20 || bottom - top < 15) return null
        return Bitmap.createBitmap(src, left, top, right - left, bottom - top)
    }

    private fun cardCenter(col: Int, row: Int) = Point(
        (.093f + col * .195f).coerceIn(.03f, .97f),
        (.248f + row * .272f).coerceIn(.10f, .90f)
    )

    private fun patchScore(src: IntArray, sw: Int, sh: Int, x: Int, y: Int, cw: Int, ch: Int,
                           tp: IntArray, tw: Int, th: Int): Float {
        var colorErr = 0.0
        var edgeErr = 0.0
        var n = 0
        var py = 0
        while (py < th) {
            val sy = y + (py * ch / th).coerceIn(0, ch - 1)
            var px = 0
            while (px < tw) {
                val sx = x + (px * cw / tw).coerceIn(0, cw - 1)
                val a = tp[py * tw + px]
                val b = src[sy * sw + sx]
                colorErr += (abs(Color.red(a) - Color.red(b)) + abs(Color.green(a) - Color.green(b)) + abs(Color.blue(a) - Color.blue(b))) / 765.0
                if (px > 0) {
                    val ap = tp[py * tw + px - 1]
                    val bp = src[sy * sw + (x + ((px - 1) * cw / tw).coerceIn(0, cw - 1))]
                    val ea = abs(Color.red(a)-Color.red(ap)) + abs(Color.green(a)-Color.green(ap)) + abs(Color.blue(a)-Color.blue(ap))
                    val eb = abs(Color.red(b)-Color.red(bp)) + abs(Color.green(b)-Color.green(bp)) + abs(Color.blue(b)-Color.blue(bp))
                    edgeErr += abs(ea-eb) / 765.0
                }
                n++; px++
            }
            py++
        }
        val colorScore = 1.0 - colorErr / n
        val edgeScore = if (tw <= 1) 1.0 else 1.0 - edgeErr / ((tw - 1) * th)
        return (colorScore * .78 + edgeScore * .22).toFloat().coerceIn(0f, 1f)
    }

    private fun similarity(a: Bitmap, b: Bitmap): Float {
        val aw = 32; val ah = 15
        val ar = Bitmap.createScaledBitmap(a, aw, ah, true)
        val br = Bitmap.createScaledBitmap(b, aw, ah, true)
        val ap = IntArray(aw * ah); val bp = IntArray(aw * ah)
        ar.getPixels(ap, 0, aw, 0, 0, aw, ah); br.getPixels(bp, 0, aw, 0, 0, aw, ah)
        var err = 0.0
        for (i in ap.indices) err += (abs(Color.red(ap[i])-Color.red(bp[i])) + abs(Color.green(ap[i])-Color.green(bp[i])) + abs(Color.blue(ap[i])-Color.blue(bp[i]))) / 765.0
        ar.recycle(); br.recycle()
        return (1.0 - err / ap.size).toFloat().coerceIn(0f,1f)
    }

    private fun scoreTextLine(line: OcrLine, aliases: List<String>): Float {
        val v = norm(line.text)
        val exact = if (aliases.any { it == v }) .98f else .90f
        val centerBonus = if (line.rect.center().x in .02f.. .98f) .02f else 0f
        return (exact + centerBonus).coerceAtMost(.99f)
    }

    private fun norm(s: String) = s.lowercase().replace('ё','е').replace(Regex("[^a-zа-я0-9]"), "")
    private fun distance(a: Point, b: Point): Float {
        val dx = a.x - b.x; val dy = a.y - b.y
        return kotlin.math.sqrt(dx * dx + dy * dy)
    }
}
