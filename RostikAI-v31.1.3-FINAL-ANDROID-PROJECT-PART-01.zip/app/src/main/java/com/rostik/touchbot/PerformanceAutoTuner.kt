package com.rostik.touchbot

import android.content.Context
import kotlin.math.max

/** Conservative 60-second adaptive tuner. It changes only processing cadence, never control coordinates. */
class PerformanceAutoTuner(private val context: Context) {
    private val prefs=context.getSharedPreferences("performance",Context.MODE_PRIVATE)
    private var rung=0; private var lowStreak=0; private var highStreak=0; private var windowStart=0L; private var lastApply=0L
    private val rungs=PerformanceProfiles.all
    var enabled: Boolean
        get() = prefs.getBoolean("autotune", false)
        set(value) { prefs.edit().putBoolean("autotune", value).apply() }
    var targetIps: Double
        get() = prefs.getFloat("target_ips", 0f).toDouble()
        set(value) { prefs.edit().putFloat("target_ips", value.toFloat()).apply() }
    fun current():PerformanceProfile=rungs[rung.coerceIn(0,rungs.lastIndex)]
    fun observe(ips:Double) {
        if(!enabled||ips<=0)return
        val now=System.currentTimeMillis(); if(windowStart==0L)windowStart=now; if(now-windowStart<60_000)return
        val target=if(targetIps>0)targetIps else max(1.0,ips); if(ips<target*.85){lowStreak++;highStreak=0}else if(ips>target*1.10){highStreak++;lowStreak=0}else{lowStreak=0;highStreak=0};windowStart=now
    }
    fun adjustmentIfDue():PerformanceProfile? {
        if(!enabled||System.currentTimeMillis()-lastApply<30_000)return null
        if(lowStreak>=2&&rung<rungs.lastIndex){rung++;lowStreak=0;highStreak=0;lastApply=System.currentTimeMillis();return current()}
        if(highStreak>=5&&rung>0){rung--;lowStreak=0;highStreak=0;lastApply=System.currentTimeMillis();return current()}
        return null
    }
}
