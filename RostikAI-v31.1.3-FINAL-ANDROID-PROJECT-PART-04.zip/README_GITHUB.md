# GitHub build — RostikAI v31.1.3

The repository can contain this Android project directly at its root. If GitHub web upload is being used because of the per-file size limit, upload the four `RostikAI-v31.1.3-PYTHON-PORT-3-PART-*.zip` files plus the standalone `.github/workflows/build.yml`. The workflow automatically reconstructs the project from the four ZIP parts before compiling. The included workflow also discovers nested Android roots by locating `settings.gradle(.kts)`, `app/build.gradle(.kts)`, and the main manifest.

The workflow uses Java 17 and the Gradle 8.10.2 GitHub action. It does not require a locally installed Gradle wrapper on the runner.

Artifacts produced:
- `app-debug.apk`
- `app-release.apk`

Before upload, the workflow verifies:
- 108 catalog entries
- 108 PNG brawler icons
- every catalog ID has a matching PNG
- neither known broken Kotlin symbol is present
- both APKs contain 108 brawler icon files


### Avatar/UI validation
- Responsive overlay: desktop/tablet uses a two-column layout; narrow phones switch to a vertical layout so the 108 brawler grid does not collapse into unusable 20–30dp cells.
- Brawler grid is scrollable and searchable. Queue and trophy editor are independently scrollable/interactive.
- Avatar decoding uses an in-memory cache and background preloading to avoid decoding 108 images repeatedly on the UI thread.
- The current asset set contains 106 real local portraits plus 2 remote-backed portraits (Cosmo/Vince); both have a bundled non-empty fallback and Discord diagnostics if remote loading fails.

### v31.1 validation targets
- Verify atomic latest-frame handoff and no bitmap accumulation.
- Verify map recognition and map-aware A* movement.
- Verify directional attack aiming.
- Verify queue restoration after process death.
- Run a real 30-60 minute device stress test before calling the release production-verified.

## Discord Logger

RostikAI includes a runtime `DiscordLogger` with categories `BUILD`, `CRASH`, `ERROR`, `VISION`, `BOT`, `UI`, `SCREEN`, `GESTURE`, `MATCH`, and `INFO`.

The Android app does **not** compile a webhook URL into the source. Configure it from the app's `РАЗРЕШЕНИЯ -> DISCORD LOGGER` card and use `ТЕСТ` to verify delivery.

For GitHub Actions, create a repository secret named `DISCORD_WEBHOOK_URL`. The workflow posts a build-start message and a final `SUCCESS` / `FAILURE` / `CANCELLED` state. The secret is never written to the repository files.

If a webhook URL has ever been exposed publicly, rotate/delete that webhook in Discord and use the newly generated URL instead.


## v31.1.3 Python-port four-part upload rule
Upload exactly one complete four-part family to the repository root. The current package is the `PYTHON-PORT-3` family:

- `RostikAI-v31.1.3-PYTHON-PORT-3-PART-01.zip`
- `RostikAI-v31.1.3-PYTHON-PORT-3-PART-02.zip`
- `RostikAI-v31.1.3-PYTHON-PORT-3-PART-03.zip`
- `RostikAI-v31.1.3-PYTHON-PORT-3-PART-04.zip`

The four source ZIPs intentionally do **not** contain `.github/workflows/build.yml`; upload the standalone workflow separately. This prevents a self-referential SHA-256 problem where the workflow would hash an archive that contains the workflow itself. The workflow pins the SHA-256 of the four parts and rejects mixed or partial sets.

The Python-to-Kotlin port now includes:
- exact supplied trophy win/loss/Showdown tables and win-streak arithmetic;
- Android-private CSV match history with playstyle hash/session statistics;
- result recognition from OCR plus bundled result templates;
- queue target/reselection handling;
- post-match Brawl Stars API trophy synchronization when a token/player tag is configured;
- conservative shop/popup/back recovery;
- reward/Star Drop/Prestige handling where the supplied Android assets/OCR provide evidence;
- Android Accessibility long-press support for the Python Star Drop hold flow.

No Python `pyautogui`, `win32gui`, `SendInput`, `scrcpy`, or desktop GPU code is copied into the Android runtime. Those responsibilities are translated to MediaProjection, AccessibilityService, Android Bitmaps, OCR, reference/template evidence, and the existing Brawl Ball controller.

## Reproducible verification

Run `python3 tools/verify_source.py` from the repository root for the same deterministic source/assets preflight used by CI.
See `VERIFICATION_REPORT.md` for the exact scope and the distinction between local static checks, pure Kotlin trophy-rule execution, and the authoritative GitHub Android build.
