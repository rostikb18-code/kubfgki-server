package com.rostik.touchbot

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.text.*
import android.view.*
import android.widget.*
import kotlin.math.roundToInt

/**
 * Stable v31.1 RostikAI overlay UI.
 * Layout is intentionally close to the supplied reference screenshot:
 * header -> search -> 6-column brawler grid + size sliders -> queue + cups -> controls.
 * All 108 catalog entries are scrollable; queue is independently scrollable.
 */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: View? = null
    private var expanded = false
    private var bubbleX = 24
    private var bubbleY = 220
    private var widthPct = 54
    private var heightPct = 90
    private var brawlerScrollY = 0
    private var queueScrollY = 0
    private var brawlerSearch = ""
    private var lastSelectedId: String? = null

    private val selected = linkedSetOf<String>()
    private val draft = linkedMapOf<String, Pair<Int, Int>>()

    override fun onCreate() {
        super.onCreate()
        StatsStore.init(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        loadDraft()
        loadSize()
        startForegroundCompat()
        showBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        try { bubble?.let(wm::removeView) } catch (_: Throwable) {}
        try { panel?.let(wm::removeView) } catch (_: Throwable) {}
        bubble = null
        panel = null
        super.onDestroy()
    }

    private fun startForegroundCompat() {
        val channelId = "overlay_v311"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(channelId, "Rostik AI overlay", NotificationManager.IMPORTANCE_LOW))
        }
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
                .setContentTitle("RostikAI 31.1")
                .setContentText("AI overlay active")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("RostikAI 31.1")
                .setContentText("AI overlay active")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .build()
        }
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(31, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else startForeground(31, notification)
    }

    private fun overlayType() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

    private fun bubbleParams() = WindowManager.LayoutParams(
        dp(58), dp(58), overlayType(),
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = bubbleX; y = bubbleY }

    private fun showBubble() {
        if (bubble != null) return
        bubble = TextView(this).apply {
            text = "AI"
            textSize = 15f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            background = circle(Color.rgb(0, 188, 245), dp(30f))
            elevation = dp(8f).toFloat()
            setOnClickListener { if (!dragging) togglePanel() }
        }
        bubble!!.setOnTouchListener(DragTouchListener { x, y ->
            bubbleX = x; bubbleY = y
            try { wm.updateViewLayout(bubble, bubbleParams()) } catch (_: Throwable) {}
        })
        try { wm.addView(bubble, bubbleParams()) } catch (_: Throwable) { bubble = null }
    }

    private fun togglePanel() { if (expanded) collapse() else expand() }

    private fun expand() {
        if (expanded) return
        expanded = true
        try { bubble?.let(wm::removeView) } catch (_: Throwable) {}
        bubble = null
        panel = buildPanel()
        try { wm.addView(panel, panelParams()) } catch (_: Throwable) {
            panel = null; expanded = false; showBubble()
        }
    }

    private fun collapse() {
        if (!expanded) return
        expanded = false
        try { panel?.let(wm::removeView) } catch (_: Throwable) {}
        panel = null
        showBubble()
    }

    private fun panelParams() = WindowManager.LayoutParams(
        panelWidthPx(), panelHeightPx(), overlayType(),
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.CENTER }

    private fun panelWidthPx(): Int {
        val w = resources.displayMetrics.widthPixels
        return (w * widthPct / 100f).roundToInt().coerceIn(dp(520).coerceAtMost(w - dp(20)), w - dp(8))
    }

    private fun panelHeightPx(): Int {
        val h = resources.displayMetrics.heightPixels
        return (h * heightPct / 100f).roundToInt().coerceIn(dp(520).coerceAtMost(h - dp(20)), h - dp(12))
    }

    private fun buildPanel(): View {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(Color.rgb(5, 34, 72), dp(22f).toFloat(), Color.rgb(20, 190, 255), dp(2))
            elevation = dp(14f).toFloat()
        }

        // Header
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "AI"; textSize = 20f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER
            background = circle(Color.rgb(0, 177, 239), dp(22f)); layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        })
        header.addView(TextView(this).apply {
            text = "  ROSTIK AI 31.1"; textSize = 17f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
        })
        header.addView(Button(this).apply {
            text = "−"; textSize = 23f; setTextColor(Color.WHITE); background = rounded(Color.rgb(20, 61, 105), dp(12f).toFloat())
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(44)); setOnClickListener { collapse() }
        })
        outer.addView(header)

        outer.addView(TextView(this).apply {
            text = "БОЙЦЫ  •  ВЫБОР + ОЧЕРЕДЬ + КУБКИ + РАЗМЕР"
            textSize = 12f; setTypeface(null, Typeface.BOLD); setTextColor(Color.rgb(89, 215, 255));
            setPadding(dp(4), dp(8), dp(4), dp(6))
        })

        outer.addView(buildSearchBar())
        outer.addView(buildMainSelection(), LinearLayout.LayoutParams(-1, 0, 1f))
        outer.addView(buildBottomArea(), LinearLayout.LayoutParams(-1, dp(205)))
        outer.addView(buildControls(), LinearLayout.LayoutParams(-1, dp(54)))
        return outer
    }

    private fun buildSearchBar(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = rounded(Color.rgb(15, 59, 103), dp(10f).toFloat()); setPadding(dp(10), 0, dp(10), 0)
            layoutParams = LinearLayout.LayoutParams(-1, dp(50)).apply { setMargins(0, 0, 0, dp(8)) }
        }
        box.addView(TextView(this).apply { text = "⌕"; textSize = 31f; setTextColor(Color.rgb(80, 174, 239)); gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(dp(40), -1) })
        val search = EditText(this).apply {
            hint = "Поиск..."; textSize = 16f; setSingleLine(true); setText(brawlerSearch)
            setTextColor(Color.WHITE); setHintTextColor(Color.rgb(137, 180, 219)); background = null
            setPadding(0, 0, 0, 0); inputType = android.text.InputType.TYPE_CLASS_TEXT
        }
        box.addView(search, LinearLayout.LayoutParams(0, -1, 1f))
        search.addTextChangedListener(simpleWatcher { brawlerSearch = it; brawlerScrollY = 0; rebuildPanel() })
        return box
    }

    private fun buildMainSelection(): View {
        val split = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, 0, 0) }

        val filter = brawlerSearch.trim().lowercase()
        val entries = if (filter.isBlank()) BrawlerCatalog.all else BrawlerCatalog.all.filter {
            it.name.lowercase().contains(filter) || it.id.lowercase().contains(filter) || it.aliases.any { a -> a.lowercase().contains(filter) }
        }

        val gridBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val columns = 6
        entries.chunked(columns).forEach { rowEntries ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            repeat(columns) { index ->
                val entry = rowEntries.getOrNull(index)
                if (entry == null) row.addView(Space(this), LinearLayout.LayoutParams(0, dp(77), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
                else row.addView(brawlerCell(entry), LinearLayout.LayoutParams(0, dp(77), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
            }
            gridBox.addView(row)
        }
        val gridScroll = ScrollView(this).apply {
            isFillViewport = true; overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS; addView(gridBox)
            setOnScrollChangeListener { _, _, sy, _, _ -> brawlerScrollY = sy }
            post { scrollTo(0, brawlerScrollY.coerceAtLeast(0)) }
        }
        left.addView(TextView(this).apply {
            text = "${entries.size} / ${BrawlerCatalog.all.size}"; textSize = 10f; setTextColor(Color.rgb(145, 190, 224)); gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, 0, dp(3))
        }, LinearLayout.LayoutParams(-1, dp(20)))
        left.addView(gridScroll, LinearLayout.LayoutParams(0, -1, 1f))

        // Size sliders exactly on the right side of the brawler grid.
        right.addView(sliderLabel("Высота", heightPct))
        right.addView(verticalSlider(heightPct, 45, 94) { heightPct = it; saveSize(); updatePanelSize() }, LinearLayout.LayoutParams(dp(42), 0, 1f))
        right.addView(sliderLabel("Ширина", widthPct))
        right.addView(verticalSlider(widthPct, 45, 70) { widthPct = it; saveSize(); updatePanelSize() }, LinearLayout.LayoutParams(dp(42), 0, 1f))

        split.addView(left, LinearLayout.LayoutParams(0, -1, 1f))
        split.addView(right, LinearLayout.LayoutParams(dp(82), -1))
        return split
    }

    private fun sliderLabel(label: String, value: Int): View = TextView(this).apply {
        text = "$label\n$value%"; textSize = 9f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setTypeface(null, Typeface.BOLD)
        layoutParams = LinearLayout.LayoutParams(-1, dp(38))
    }

    private fun verticalSlider(value: Int, min: Int, max: Int, onChange: (Int) -> Unit): View {
        val holder = FrameLayout(this).apply { setPadding(dp(4), dp(4), dp(4), dp(4)) }
        val seek = SeekBar(this).apply {
            this.max = max - min; progress = (value - min).coerceIn(0, max - min)
            rotation = -90f
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) onChange(min + p) }
                override fun onStartTrackingTouch(sb: SeekBar?) = Unit
                override fun onStopTrackingTouch(sb: SeekBar?) = Unit
            })
        }
        holder.addView(seek, FrameLayout.LayoutParams(dp(145), dp(36), Gravity.CENTER))
        return holder
    }

    private fun brawlerCell(entry: BrawlerCatalog.Entry): View {
        val chosen = selected.contains(entry.id)
        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(2), dp(2), dp(2), dp(1))
            background = rounded(if (chosen) Color.rgb(21, 91, 139) else Color.rgb(8, 46, 83), dp(8f), if (chosen) Color.rgb(35, 205, 255) else Color.TRANSPARENT, if (chosen) 2 else 0)
            contentDescription = "${entry.name}${if (chosen) ", выбран" else ""}"
        }
        val frame = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(dp(58), dp(55)) }
        val bmp = loadAvatar(entry.id)
        if (bmp != null) {
            frame.addView(ImageView(this).apply { setImageBitmap(bmp); scaleType = ImageView.ScaleType.CENTER_CROP; layoutParams = FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER) })
        } else {
            frame.addView(TextView(this).apply { text = initials(entry.name); textSize = 10f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER; background = circle(avatarColor(entry.id), dp(23f)); layoutParams = FrameLayout.LayoutParams(dp(50), dp(50), Gravity.CENTER) })
        }
        cell.addView(frame)
        cell.addView(TextView(this).apply {
            text = entry.name; textSize = 8f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(-1, dp(17)))
        cell.setOnClickListener {
            if (selected.contains(entry.id)) { lastSelectedId = entry.id; toast("${entry.name} уже в очереди"); return@setOnClickListener }
            selected.add(entry.id); draft.putIfAbsent(entry.id, 0 to 0); lastSelectedId = entry.id; saveDraft(); rebuildPanel()
        }
        return cell
    }

    private fun buildBottomArea(): View {
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(7), 0, dp(5)) }
        bottom.addView(buildQueueCard(), LinearLayout.LayoutParams(0, -1, 1.35f).apply { setMargins(0, 0, dp(5), 0) })
        bottom.addView(buildCupsCard(), LinearLayout.LayoutParams(0, -1, 0.65f).apply { setMargins(dp(5), 0, 0, 0) })
        return bottom
    }

    private fun buildQueueCard(): View {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(9), dp(7), dp(7), dp(7)); background = rounded(Color.rgb(5, 45, 84), dp(12f), Color.rgb(19, 101, 165), dp(1)) }
        card.addView(TextView(this).apply { text = "ОЧЕРЕДЬ  ${selected.size}"; textSize = 13f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD); setPadding(dp(2), 0, 0, dp(4)) }, LinearLayout.LayoutParams(-1, dp(25)))
        val scroll = ScrollView(this).apply { isFillViewport = true; overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS }
        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (selected.isEmpty()) rows.addView(TextView(this).apply { text = "Выберите бойцов"; textSize = 10f; setTextColor(Color.rgb(143, 181, 214)); setPadding(dp(4), dp(8), 0, 0) })
        else selected.forEachIndexed { i, id -> rows.addView(queueRowCompact(id, i + 1)) }
        scroll.addView(rows)
        scroll.setOnScrollChangeListener { _, _, sy, _, _ -> queueScrollY = sy }
        scroll.post { scroll.scrollTo(0, queueScrollY.coerceAtLeast(0)) }
        card.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        return card
    }

    private fun queueRowCompact(id: String, number: Int): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(5), dp(3), dp(3), dp(3)); background = rounded(Color.rgb(10, 55, 99), dp(8f)); layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { setMargins(0, dp(2), 0, dp(2)) } }
        row.addView(TextView(this).apply { text = "$number"; textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(dp(20), -1) })
        loadAvatar(id)?.let { bmp -> row.addView(ImageView(this).apply { setImageBitmap(bmp); scaleType = ImageView.ScaleType.CENTER_CROP; layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(dp(2), 0, dp(6), 0) } }) }
        row.addView(TextView(this).apply { text = BrawlerCatalog.name(id); textSize = 10f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD); layoutParams = LinearLayout.LayoutParams(0, -1, 1f); gravity = Gravity.CENTER_VERTICAL })
        val v = draft[id] ?: (0 to 0)
        row.addView(TextView(this).apply { text = "${v.first} → ${v.second}"; textSize = 9f; setTextColor(Color.rgb(171, 213, 242)); gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(dp(76), -1) })
        row.addView(Button(this).apply { text = "×"; textSize = 16f; setTextColor(Color.WHITE); background = rounded(Color.rgb(30, 85, 125), dp(7f)); layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)); setOnClickListener { selected.remove(id); draft.remove(id); if (lastSelectedId == id) lastSelectedId = selected.lastOrNull(); saveDraft(); rebuildPanel() } })
        row.setOnClickListener { lastSelectedId = id; rebuildPanel() }
        return row
    }

    private fun buildCupsCard(): View {
        val id = lastSelectedId ?: selected.firstOrNull()
        val v = id?.let { draft[it] } ?: (0 to 0)
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(9), dp(7), dp(7), dp(7)); background = rounded(Color.rgb(5, 45, 84), dp(12f), Color.rgb(19, 101, 165), dp(1)) }
        card.addView(TextView(this).apply { text = "🏆 КУБКИ"; textSize = 13f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD); setPadding(dp(2), 0, 0, dp(3)) }, LinearLayout.LayoutParams(-1, dp(25)))
        if (id == null) {
            card.addView(TextView(this).apply { text = "Выберите бойца"; textSize = 10f; setTextColor(Color.rgb(143, 181, 214)); setPadding(dp(4), dp(8), 0, 0) })
            return card
        }
        card.addView(TextView(this).apply { text = BrawlerCatalog.name(id); textSize = 11f; setTextColor(Color.rgb(76, 215, 255)); setTypeface(null, Typeface.BOLD) })
        val inputs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(5), 0, 0) }
        val current = numberInput(v.first)
        val target = numberInput(v.second)
        inputs.addView(labeledInput("текущие", current), LinearLayout.LayoutParams(0, dp(62), 1f))
        inputs.addView(TextView(this).apply { text = "→"; textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(dp(24), dp(62)) })
        inputs.addView(labeledInput("цель", target), LinearLayout.LayoutParams(0, dp(62), 1f))
        card.addView(inputs)
        current.addTextChangedListener(simpleWatcher { s -> val old = draft[id] ?: (0 to 0); draft[id] = (s.toIntOrNull() ?: old.first) to old.second; saveDraft(); refreshQueueOnly() })
        target.addTextChangedListener(simpleWatcher { s -> val old = draft[id] ?: (0 to 0); draft[id] = old.first to (s.toIntOrNull() ?: old.second); saveDraft(); refreshQueueOnly() })
        return card
    }

    private fun buildControls(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row.addView(actionButton("START", Color.rgb(0, 201, 117)) { startBot() })
        row.addView(actionButton("ПАУЗА", Color.rgb(241, 169, 28)) {
            if (BotRuntime.supervisor.status().contains("PAUSED")) { BotRuntime.supervisor.resume(); toast("Продолжено") }
            else { BotRuntime.supervisor.pause(); toast("Пауза") }
        })
        row.addView(actionButton("STOP", Color.rgb(235, 48, 73)) { BotRuntime.supervisor.stop(); toast("STOP") })
        return row
    }

    private fun actionButton(text: String, color: Int, click: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 11f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD); background = rounded(color, dp(10f)); setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(3), 0, dp(3), 0) }
    }

    private fun updatePanelSize() {
        if (!expanded) return
        try { panel?.let { wm.updateViewLayout(it, panelParams()) } } catch (_: Throwable) {}
    }

    private fun refreshQueueOnly() { rebuildPanel() }

    private fun rebuildPanel() {
        if (!expanded) return
        try { panel?.let(wm::removeView) } catch (_: Throwable) {}
        panel = buildPanel()
        try { wm.addView(panel, panelParams()) } catch (_: Throwable) { panel = null; expanded = false; showBubble() }
    }

    private fun startBot() {
        if (BotAccessibilityService.instance == null) { toast("Включи Accessibility"); return }
        if (!BotRuntime.captureActive) { toast("Включи захват экрана"); return }
        val items = selected.map { id ->
            val v = draft[id] ?: (0 to 0)
            QueueItem(id, v.first, v.second)
        }.filter { it.currentCups < it.targetCups }
        if (items.isEmpty()) { toast("Выбери бойца и цель"); return }
        BotRuntime.queue.replace(items)
        saveDraft(); BotRuntime.supervisor.start(); toast("START"); collapse()
    }

    private fun loadDraft() {
        val sp = getSharedPreferences("v311", MODE_PRIVATE)
        sp.getString("queue", "")?.takeIf { it.isNotBlank() }?.split(';')?.forEach { item ->
            val p = item.split(':')
            if (p.size == 3) {
                val c = p[1].toIntOrNull(); val t = p[2].toIntOrNull()
                if (c != null && t != null && BrawlerCatalog.all.any { it.id == p[0] }) { selected.add(p[0]); draft[p[0]] = c to t }
            }
        }
    }

    private fun saveDraft() { getSharedPreferences("v311", MODE_PRIVATE).edit().putString("queue", selected.joinToString(";") { id -> val v = draft[id] ?: (0 to 0); "$id:${v.first}:${v.second}" }).apply() }
    private fun loadSize() { val sp = getSharedPreferences("v311", MODE_PRIVATE); widthPct = sp.getInt("width_pct", 54).coerceIn(45, 70); heightPct = sp.getInt("height_pct", 90).coerceIn(60, 94) }
    private fun saveSize() { getSharedPreferences("v311", MODE_PRIVATE).edit().putInt("width_pct", widthPct).putInt("height_pct", heightPct).apply() }

    private fun numberInput(value: Int) = EditText(this).apply {
        inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText(value.toString()); setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER; setSingleLine(true); setSelectAllOnFocus(true)
        background = rounded(Color.rgb(19, 70, 119), dp(8f))
    }

    private fun labeledInput(label: String, edit: EditText): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(2), 0, dp(2), 0)
        addView(TextView(this@OverlayService).apply { text = label; textSize = 8f; setTextColor(Color.rgb(103, 215, 239)); gravity = Gravity.CENTER })
        addView(edit, LinearLayout.LayoutParams(-1, dp(40)))
    }

    private fun loadAvatar(id: String): Bitmap? = try { assets.open("brawler_icons/$id.png").use { BitmapFactory.decodeStream(it) } } catch (_: Throwable) { null }
    private fun simpleWatcher(after: (String) -> Unit) = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, afterCount: Int) = Unit
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { after(s?.toString() ?: "") }
        override fun afterTextChanged(s: Editable?) = Unit
    }
    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun dp(v: Float): Int = (v * resources.displayMetrics.density).roundToInt()
    private fun circle(color: Int, radius: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
    // Accept both pixel Int radii (dp(Int)) and Float radii (dp(Float)).
    // This prevents Kotlin Int/Float mismatches at every rounded() call site.
    private fun rounded(color: Int, radius: Int, strokeColor: Int = Color.TRANSPARENT, strokeWidth: Int = 0) =
        rounded(color, radius.toFloat(), strokeColor, strokeWidth)

    private fun rounded(color: Int, radius: Float, strokeColor: Int = Color.TRANSPARENT, strokeWidth: Int = 0) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            if (strokeWidth > 0) setStroke(dp(strokeWidth), strokeColor)
        }
    private fun avatarColor(id: String): Int { var h = id.hashCode(); h = h xor (h ushr 16); return Color.rgb(45 + (h and 0x7F), 65 + ((h ushr 8) and 0x7F), 90 + ((h ushr 16) and 0x7F)) }
    private fun initials(name: String): String = name.replace("-", " ").split(' ').filter { it.isNotBlank() }.take(2).joinToString("") { it.first().toString() }

    override fun onBind(intent: Intent?): IBinder? = null
    private var dragging = false
    private inner class DragTouchListener(private val moved: (Int, Int) -> Unit) : View.OnTouchListener {
        private var downX = 0f; private var downY = 0f; private var startX = 0; private var startY = 0
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dragging = false; downX=e.rawX; downY=e.rawY; startX=bubbleX; startY=bubbleY; return true }
                MotionEvent.ACTION_MOVE -> { val nx=startX+(e.rawX-downX).roundToInt(); val ny=startY+(e.rawY-downY).roundToInt(); if (kotlin.math.abs(e.rawX-downX)>8 || kotlin.math.abs(e.rawY-downY)>8) dragging=true; if(dragging) moved(nx.coerceAtLeast(0),ny.coerceAtLeast(0)); return true }
                MotionEvent.ACTION_UP -> { if(!dragging) v.performClick(); return true }
            }
            return false
        }
    }
}
