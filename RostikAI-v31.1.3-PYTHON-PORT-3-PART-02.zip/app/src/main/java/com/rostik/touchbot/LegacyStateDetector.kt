package com.rostik.touchbot

import android.content.res.AssetManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Android counterpart of the supplied Python state_finder.py.
 *
 * The Python implementation uses OpenCV template matching. Android's build does
 * not ship OpenCV, so this class performs a bounded low-resolution normalized
 * template search over the same kind of screen regions. It is intentionally
 * evidence-only: a weak match returns UNKNOWN and never authorizes a tap.
 */
class LegacyStateDetector(private val assets: AssetManager) {
    enum class State {
        UNKNOWN, LOBBY, MATCH_MAKING, BRAWLER_SELECTION, SHOP, POPUP,
        MATCH, RESULT_VICTORY, RESULT_DEFEAT, RESULT_DRAW,
        RESULT_SHOWDOWN_1ST, RESULT_SHOWDOWN_2ND, RESULT_SHOWDOWN_3RD, RESULT_SHOWDOWN_4TH,
        REWARD, TROPHY_REWARD, PRESTIGE_REWARD, STAR_DROP
    }

    data class Detection(val state: State, val confidence: Float, val result: MatchOutcome? = null)

    private val cache = HashMap<String, Bitmap?>()

    fun detect(screen: Bitmap, lines: List<OcrLine>): Detection {
        val result = detectResult(screen, lines)
        if (result.state != State.UNKNOWN) return result

        if (templatePresent(screen, "apk_port/states/brawler_menu_task.png", Region(0f, .0f, 1f, .35f), .84f)) {
            return Detection(State.BRAWLER_SELECTION, .90f)
        }
        if (templatePresent(screen, "apk_port/states/powerpoint.png", Region(0f, 0f, 1f, 1f), .84f)) {
            return Detection(State.SHOP, .90f)
        }
        if (templatePresent(screen, "apk_port/states/close_popup.png", Region(.2f, .05f, .8f, .85f), .86f)) {
            return Detection(State.POPUP, .90f)
        }
        if (templatePresent(screen, "apk_port/states/trophies_screen.png", Region(.2f, 0f, .8f, .35f), .72f)) {
            return Detection(State.TROPHY_REWARD, .80f)
        }

        val text = lines.joinToString(" ") { normalize(it.text) }
        if (containsAny(text, "matchmaking", "matchmaking", "поискматча", "поискигры", "отмена поиска", "cancel search")) {
            return Detection(State.MATCH_MAKING, .76f)
        }
        if (containsAny(text, "reward", "rewards", "награда", "claim", "получить", "open", "открыть", "continue", "продолжить")) {
            if (!containsAny(text, "play", "играть") && !containsAny(text, "brawlers", "бойцы")) {
                return Detection(State.REWARD, .70f)
            }
        }
        if (containsAny(text, "prestige", "престиж")) {
            return Detection(State.PRESTIGE_REWARD, .76f)
        }
        if (containsAny(text, "star drop", "stardrop", "звездный дроп", "звездныйдроп")) {
            return Detection(State.STAR_DROP, .72f)
        }

        // The Python state finder calls an unclassified in-game frame "match".
        // We only return MATCH here when the caller's MatchVision already has
        // concrete gameplay evidence; this avoids inventing a state from OCR.
        return Detection(State.UNKNOWN, 0f)
    }

    private fun detectResult(screen: Bitmap, lines: List<OcrLine>): Detection {
        val text = lines.joinToString(" ") { normalize(it.text) }
        val showdown = when {
            containsAny(text, "1st", "1stplace", "1 место", "1место") -> Detection(State.RESULT_SHOWDOWN_1ST, .91f)
            containsAny(text, "2nd", "2ndplace", "2 место", "2место") -> Detection(State.RESULT_SHOWDOWN_2ND, .91f)
            containsAny(text, "3rd", "3rdplace", "3 место", "3место") -> Detection(State.RESULT_SHOWDOWN_3RD, .91f)
            containsAny(text, "4th", "4thplace", "4 место", "4место") -> Detection(State.RESULT_SHOWDOWN_4TH, .91f)
            else -> null
        }
        if (showdown != null) return showdown

        val victory = templateScore(screen, "apk_port/lobby/victory.png", Region(0f, 0f, 1f, .72f))
        val defeat = max(
            templateScore(screen, "apk_port/lobby/defeat.png", Region(0f, 0f, 1f, .72f)),
            templateScore(screen, "reference/result_defeat.png", Region(0f, 0f, 1f, .72f))
        )
        val draw = templateScore(screen, "apk_port/lobby/draw.png", Region(0f, 0f, 1f, .72f))
        val wordResult = when {
            containsAny(text, "victory", "победа", "победили", "win", "won") -> State.RESULT_VICTORY
            containsAny(text, "defeat", "поражение", "loss", "lost") -> State.RESULT_DEFEAT
            containsAny(text, "draw", "ничья") -> State.RESULT_DRAW
            else -> State.UNKNOWN
        }
        val best = maxOf(victory, defeat, draw)
        if (best >= .72f) {
            return when (best) {
                victory -> Detection(State.RESULT_VICTORY, victory, MatchOutcome.WIN)
                defeat -> Detection(State.RESULT_DEFEAT, defeat, MatchOutcome.LOSS)
                else -> Detection(State.RESULT_DRAW, draw, MatchOutcome.DRAW)
            }
        }
        if (wordResult != State.UNKNOWN) {
            return Detection(wordResult, .84f, when (wordResult) {
                State.RESULT_VICTORY -> MatchOutcome.WIN
                State.RESULT_DEFEAT -> MatchOutcome.LOSS
                else -> MatchOutcome.DRAW
            })
        }
        return Detection(State.UNKNOWN, 0f)
    }

    private fun templatePresent(screen: Bitmap, asset: String, region: Region, threshold: Float): Boolean =
        templateScore(screen, asset, region) >= threshold

    private fun templateScore(screen: Bitmap, asset: String, region: Region): Float {
        val template = load(asset) ?: return 0f
        val sw = screen.width
        val sh = screen.height
        val l = (region.l * sw).toInt().coerceIn(0, sw - 1)
        val t = (region.t * sh).toInt().coerceIn(0, sh - 1)
        val r = (region.r * sw).toInt().coerceIn(l + 1, sw)
        val b = (region.b * sh).toInt().coerceIn(t + 1, sh)
        val crop = Bitmap.createBitmap(screen, l, t, r - l, b - t)
        try {
            // Keep the search bounded. The Python matcher scales templates with
            // the screen and then performs CCOEFF_NORMED inside a configured ROI.
            val maxTemplateW = 44
            val ratio = min(1f, maxTemplateW.toFloat() / max(1, template.width))
            val tw = max(8, (template.width * ratio).toInt())
            val th = max(6, (template.height * ratio).toInt())
            val tt = Bitmap.createScaledBitmap(template, tw, th, true)
            val searchScale = min(1f, 180f / max(crop.width, crop.height).toFloat())
            val cw = max(tw + 2, (crop.width * searchScale).toInt())
            val ch = max(th + 2, (crop.height * searchScale).toInt())
            val ss = Bitmap.createScaledBitmap(crop, cw, ch, true)
            try {
                val tp = IntArray(tw * th); tt.getPixels(tp, 0, tw, 0, 0, tw, th)
                val sp = IntArray(cw * ch); ss.getPixels(sp, 0, cw, 0, 0, cw, ch)
                var best = 0f
                val step = 2
                for (y in 0..(ch - th) step step) {
                    for (x in 0..(cw - tw) step step) {
                        var err = 0.0
                        var i = 0
                        for (yy in 0 until th) {
                            val base = (y + yy) * cw + x
                            val tbase = yy * tw
                            for (xx in 0 until tw) {
                                val a = tp[tbase + xx]
                                val bpx = sp[base + xx]
                                err += (abs(Color.red(a) - Color.red(bpx)) + abs(Color.green(a) - Color.green(bpx)) + abs(Color.blue(a) - Color.blue(bpx))) / 765.0
                                i++
                            }
                        }
                        val score = (1.0 - err / max(1, i)).toFloat()
                        if (score > best) best = score
                    }
                }
                return best.coerceIn(0f, 1f)
            } finally { if (ss !== crop) ss.recycle(); if (tt !== template) tt.recycle() }
        } finally { crop.recycle() }
    }

    private fun load(path: String): Bitmap? {
        if (cache.containsKey(path)) return cache[path]
        val value = try { assets.open(path).use { BitmapFactory.decodeStream(it) } } catch (_: Throwable) { null }
        cache[path] = value
        return value
    }

    private fun containsAny(text: String, vararg values: String): Boolean = values.any { text.contains(normalize(it)) }
    private fun normalize(value: String): String = value.lowercase().replace('ё', 'е').replace(Regex("[^a-zа-я0-9]"), "")
    private data class Region(val l: Float, val t: Float, val r: Float, val b: Float)
}
