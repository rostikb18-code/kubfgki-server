# Python -> Kotlin migration (RostikAI 31.1.3)

This release ports the runtime responsibilities from the supplied Pyla-RL modules into Android-native Kotlin components.

## Ported responsibilities

- `TrophyObserver` + trophy tables -> `TrophyObserver.kt` + `TrophyRules.kt`
  - victory/defeat/draw
  - Trio Showdown 1st/2nd/3rd/4th
  - win streak
  - session W/L/D counters
  - CSV match history
  - playstyle SHA-256
  - expected-vs-observed trophy diagnostics
- `runtime_metrics.py` -> `RuntimeMetrics.kt`
  - atomic-ish temp-file replacement
  - bounded IPS history
  - session state, brawler, target, trophies, recovery counters
- `runtime_log.py` -> `RuntimeLog.kt`
  - ERROR/WARN/INFO/DEBUG/TRACE
  - movement trace throttling
  - one-shot throttled messages
- `recovery_events.py` -> `RecoveryEvents.kt`
  - JSONL recovery events
  - repeated-event alert window
  - integrated with supervisor fail-safe, capture watchdog and gesture exceptions
- `performance_profile.py` -> `PerformanceProfile.kt`
  - balanced / low_end / quality / quality_fullres / high_ips profiles
- `performance_autotune.py` -> `PerformanceAutoTuner.kt`
  - 60-second observation windows
  - conservative step-down/step-up rules
  - Android-native processing cadence instead of desktop scrcpy settings
- `perf_profiler.py` -> `PerfProfiler.kt`
  - bounded stage timings and counters
  - vision/OCR timing instrumentation

## Android-specific replacements

Desktop-only `scrcpy`, `pyautogui`, `win32gui`, `SendInput`, DirectML/CUDA installation and process restarts are not copied into the Android application. The equivalent runtime primitives are:

- MediaProjection/ImageReader for screen feed
- AccessibilityService GestureDescription for input
- normalized coordinates for device-independent controls
- coroutine state machine for StageManager-like flow
- Android files/SharedPreferences for persistence
- ML Kit OCR and bitmap vision for screen recognition

No anti-cheat bypass, stealth, anti-debugging or evasion code is included.

## Verification boundary

Static source/assets checks are run locally. Android Gradle compilation, lint and APK installation require the GitHub Actions runner or an Android SDK/Gradle environment. This release does not claim a successful Android build until that external build actually reports success.
