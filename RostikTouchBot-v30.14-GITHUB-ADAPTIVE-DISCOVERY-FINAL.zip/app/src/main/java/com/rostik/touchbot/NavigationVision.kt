package com.rostik.touchbot

/**
 * Conservative screen classifier. It prefers explicit UI anchors and the game HUD
 * over generic words. Unknown screens remain UNKNOWN and therefore produce no tap.
 */
class NavigationVision {
    data class Observation(
        val type: ScreenType,
        val confidence: Float,
        val brawlBall: Boolean,
        val play: Point? = null,
        val playAgain: Point? = null,
        val proceed: Point? = null,
        val rewardAction: Pair<String, Point>? = null,
        val mapName: String? = null,
        val mapPoint: Point? = null,
        val explicitMapPicker: Boolean = false
    )

    private var lastType = ScreenType.UNKNOWN
    private var stable = 0

    fun observe(lines: List<OcrLine>, scene: MatchScene?): Observation {
        val text = lines.joinToString(" ") { norm(it.text) }
        fun has(vararg words: String) = words.any { text.contains(norm(it)) }

        val brawlBall = has("brawl ball", "brawlball", "броулбол", "бравлболл")
        val result = has("victory", "победа", "defeat", "поражение", "defeat", "victory!")
        val reward = has("reward", "rewards", "награда", "claim", "получить", "open", "открыть", "daily wins")
        val brawlerHeading = has("brawlers", "бойцы", "fighters")
        val brawlerNameCount = lines.count { isLikelyBrawlerName(it.text) }
        val brawlerList = brawlerHeading || brawlerNameCount >= 3
        val selectButton = findButton(lines, "select", "выбрать", "choose")
        val profileNameCount = lines.count { isLikelyBrawlerName(it.text) }
        val brawlerProfile = selectButton != null && profileNameCount >= 1 && !brawlerHeading && !brawlerList

        val modeHeading = has("trophy game modes", "game modes", "режимы игр", "режимы")
        val modeCards = has("knockout", "showdown", "gem grab", "hot zone", "wipeout", "brawl hockey")
        val modeSelect = (modeHeading || modeCards) && !brawlerList && !result

        val play = findButton(lines, "play", "играть", "ready", "готов", "play!")
        val again = findButton(lines, "play again", "играть снова", "ещё раз")
        val proceed = findButton(lines, "proceed", "continue", "продолжить", "exit", "выйти")
        val rewardAction = findButton(lines, "claim", "получить", "open", "открыть", "continue", "далее", "skip", "пропустить")
            ?.let { "REWARD" to it }

        val knownMapLine = lines.asSequence().mapNotNull { line ->
            BrawlBallMapCatalog.find(line.text)?.let { it to line }
        }.maxByOrNull { it.second.confidence }
        val mapName = knownMapLine?.first?.name
        val mapPoint = knownMapLine?.second?.rect?.center()
        val hud = scene?.let {
            it.combatControlsConfirmed && it.player != null && it.hudConfidence >= .30f
        } ?: false
        val match = hud || (scene?.player != null && scene.hudConfidence >= .62f && !result && !brawlerList && !modeSelect)
        val explicitMapPicker = has("choose map", "select map", "map selection", "выбор карты", "карта") &&
            !result && !match

        val candidate = when {
            result || again != null -> ScreenType.RESULT
            reward && !brawlerList && !modeSelect && !match -> ScreenType.REWARD
            match -> ScreenType.MATCH
            brawlerProfile -> ScreenType.BRAWLER_PROFILE
            brawlBall && play != null -> ScreenType.BRAWL_BALL_LOBBY
            brawlerList && !modeSelect -> ScreenType.BRAWLER_LIST
            modeSelect -> ScreenType.MODE_SELECT
            play != null && brawlBall -> ScreenType.BRAWL_BALL_LOBBY
            has("shop", "магазин", "quests", "задания", "friends", "друзья") -> ScreenType.HOME
            play != null -> ScreenType.HOME
            else -> ScreenType.UNKNOWN
        }

        stable = if (candidate == lastType) stable + 1 else 1
        lastType = candidate
        val confidence = when {
            stable >= 3 -> .97f
            stable == 2 -> .89f
            else -> .72f
        }
        return Observation(candidate, confidence, brawlBall, play, again, proceed, rewardAction, mapName, mapPoint, explicitMapPicker)
    }

    fun findButton(lines: List<OcrLine>, vararg words: String): Point? {
        val wanted = words.map(::norm).filter { it.length >= 3 }
        return lines.asSequence()
            .filter { it.rect.center().y > .25f }
            .mapNotNull { line ->
                val v = norm(line.text)
                val exact = wanted.any { w -> v == w || v.contains(w) || (w.contains(v) && v.length >= 4) }
                if (!exact) null else line
            }
            .maxByOrNull { buttonScore(it) }
            ?.rect?.center()
    }

    fun findSearch(lines: List<OcrLine>): Point? {
        val wanted = listOf("search", "поиск").map(::norm)
        return lines.asSequence()
            .mapNotNull { line ->
                val v = norm(line.text)
                if (wanted.any { w -> v == w || v.contains(w) }) line else null
            }
            .minByOrNull { it.rect.center().y }
            ?.rect?.center()
    }


    fun findCurrentMode(lines: List<OcrLine>): Point? {
        val modes = listOf(
            "solo showdown", "showdown", "knockout", "gem grab", "hot zone",
            "wipeout", "brawl hockey", "basket brawl", "heist"
        ).map(::norm)
        return lines.asSequence()
            .mapNotNull { line ->
                val v=norm(line.text)
                if (modes.any { m -> v == m || v.contains(m) }) line else null
            }
            .filter { it.rect.center().y > .72f }
            .maxByOrNull { 1f - kotlin.math.abs(it.rect.center().x - .55f) }
            ?.rect?.center()
    }

    fun findMap(lines: List<OcrLine>, mapId: String): Point? {
        val wanted = BrawlBallMapCatalog.all.firstOrNull { it.id == mapId } ?: return null
        return lines.asSequence().mapNotNull { line ->
            if (BrawlBallMapCatalog.find(line.text)?.id == wanted.id) line else null
        }.maxByOrNull { it.confidence }?.rect?.center()
    }

    fun findBrawlBall(lines: List<OcrLine>): Point? {
        val candidates = lines.filter { line ->
            val v = norm(line.text)
            v.contains("brawlball") || v.contains("броулбол") || v.contains("бравлболл")
        }
        return candidates.maxByOrNull { line ->
            val c = line.rect.center()
            // The supplied mode screen has Brawl Ball in the upper/middle card area.
            (1f - kotlin.math.abs(c.x - .50f)).coerceIn(0f, 1f) * .4f +
                (1f - kotlin.math.abs(c.y - .35f)).coerceIn(0f, 1f) * .6f
        }?.rect?.center()
    }

    private fun buttonScore(line: OcrLine): Float {
        val c = line.rect.center()
        val bottom = if (c.y > .55f) 1f else .5f
        val center = (1f - kotlin.math.abs(c.x - .5f)).coerceIn(0f,1f)
        return bottom * .65f + center * .35f
    }

    private fun isLikelyBrawlerName(text: String): Boolean {
        val v = norm(text)
        if (v.length < 3) return false
        return BrawlerCatalog.all.any { e -> BrawlerCatalog.aliases(e.id).any { norm(it) == v || (v.length >= 4 && v.contains(norm(it))) } }
    }

    private fun norm(s: String) = s.lowercase().replace('ё','е').replace(Regex("[^a-zа-я0-9]"), "")
}
