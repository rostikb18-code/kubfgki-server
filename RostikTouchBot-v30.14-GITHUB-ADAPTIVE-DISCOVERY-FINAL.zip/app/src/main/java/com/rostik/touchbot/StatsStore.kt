package com.rostik.touchbot

import android.content.Context
import kotlin.math.roundToInt

/** Persistent runtime statistics used by the app's "Статистика" section. */
object StatsStore {
    private const val PREFS = "v30_stats"
    private const val TOTAL_MS = "total_ms"
    private const val NET_CUPS = "net_cups"
    private const val WINS = "wins"
    private const val LOSSES = "losses"
    private const val DRAWS = "draws"
    private const val MATCHES = "matches"
    private const val ACTIVE_STARTED = "active_started"

    private lateinit var app: Context

    fun init(context: Context) { app = context.applicationContext }

    private fun prefs() = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized fun beginRun(now: Long = System.currentTimeMillis()) {
        if (prefs().getLong(ACTIVE_STARTED, 0L) == 0L) {
            prefs().edit().putLong(ACTIVE_STARTED, now).apply()
        }
    }

    @Synchronized fun endRun(now: Long = System.currentTimeMillis()) {
        val started = prefs().getLong(ACTIVE_STARTED, 0L)
        if (started > 0L) {
            val add = (now - started).coerceAtLeast(0L)
            prefs().edit()
                .putLong(TOTAL_MS, prefs().getLong(TOTAL_MS, 0L) + add)
                .putLong(ACTIVE_STARTED, 0L)
                .apply()
        }
    }

    @Synchronized fun recordMatch(cupDelta: Int, outcome: MatchOutcome) {
        val p = prefs()
        val e = p.edit()
            .putLong(NET_CUPS, p.getLong(NET_CUPS, 0L) + cupDelta)
            .putInt(MATCHES, p.getInt(MATCHES, 0) + 1)
        when (outcome) {
            MatchOutcome.WIN -> e.putInt(WINS, p.getInt(WINS, 0) + 1)
            MatchOutcome.LOSS -> e.putInt(LOSSES, p.getInt(LOSSES, 0) + 1)
            MatchOutcome.DRAW -> e.putInt(DRAWS, p.getInt(DRAWS, 0) + 1)
        }
        e.apply()
    }

    fun snapshot(now: Long = System.currentTimeMillis()): StatsSnapshot {
        val p = prefs()
        val active = p.getLong(ACTIVE_STARTED, 0L)
        val activeMs = if (active > 0L) (now - active).coerceAtLeast(0L) else 0L
        val matches = p.getInt(MATCHES, 0)
        val wins = p.getInt(WINS, 0)
        val losses = p.getInt(LOSSES, 0)
        val decisive = wins + losses
        val winRate = if (decisive == 0) 0 else ((wins.toDouble() / decisive) * 100.0).roundToInt()
        return StatsSnapshot(
            totalTimeMs = p.getLong(TOTAL_MS, 0L) + activeMs,
            netCups = p.getLong(NET_CUPS, 0L).toInt(),
            matches = matches,
            wins = wins,
            losses = losses,
            draws = p.getInt(DRAWS, 0),
            winRate = winRate
        )
    }

    @Synchronized fun reset() {
        prefs().edit().clear().apply()
    }
}

enum class MatchOutcome { WIN, LOSS, DRAW }

data class StatsSnapshot(
    val totalTimeMs: Long,
    val netCups: Int,
    val matches: Int,
    val wins: Int,
    val losses: Int,
    val draws: Int,
    val winRate: Int
) {
    fun timeText(): String {
        val totalSeconds = totalTimeMs / 1000L
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0) "%02d:%02d:%02d".format(hours, minutes, seconds)
        else "%02d:%02d".format(minutes, seconds)
    }
}
