package com.rostik.touchbot

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class OcrEngine {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun read(bitmap: Bitmap): List<OcrLine> =
        suspendCancellableCoroutine { cont ->
            val image = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(image)
                .addOnSuccessListener { result ->
                    val now = System.currentTimeMillis()
                    val lines = result.textBlocks.flatMap { block ->
                        block.lines.map { line ->
                            val r = line.boundingBox
                            val w = bitmap.width.coerceAtLeast(1)
                            val h = bitmap.height.coerceAtLeast(1)
                            OcrLine(
                                line.text,
                                RectN(
                                    (r?.left ?: 0) / w.toFloat(),
                                    (r?.top ?: 0) / h.toFloat(),
                                    (r?.right ?: 0) / w.toFloat(),
                                    (r?.bottom ?: 0) / h.toFloat()
                                ),
                                0.8f,
                                now
                            )
                        }
                    }
                    if (cont.isActive) cont.resume(lines)
                }
                .addOnFailureListener { if (cont.isActive) cont.resumeWithException(it) }
        }

    fun close() { recognizer.close() }
}
