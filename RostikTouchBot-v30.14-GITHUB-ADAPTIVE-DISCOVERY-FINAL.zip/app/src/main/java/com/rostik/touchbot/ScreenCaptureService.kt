package com.rostik.touchbot

import android.app.*
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.hardware.display.VirtualDisplay
import android.os.*
import android.util.Log
import androidx.core.app.ServiceCompat
import java.util.concurrent.Executor
import java.util.concurrent.atomic.AtomicBoolean

/**
 * High-quality, low-GC MediaProjection pipeline.
 *
 * The display is captured at a quality selected from the current thermal state,
 * while MatchVision works on a small reusable analysis surface. This is the
 * important split: OCR/navigation still receive the complete captured frame,
 * but the hot gameplay CV loop does not repeatedly resize/copy the whole screen.
 */
class ScreenCaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        @Volatile var onBitmap: ((Bitmap) -> Unit)? = null
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var started = false

    private var sourceWidth = 0
    private var sourceHeight = 0
    private var currentProfileName = ""
    private var currentMaxDimension = 0
    private var lastFrameAt = 0L
    private var framesSeen = 0L
    private var framesDelivered = 0L
    private var lastStatsAt = 0L
    private var thermalListenerRegistered = false
    private val rebuilding = AtomicBoolean(false)

    private val handlerExecutor = Executor { command -> handler?.post(command) }

    private val thermalListener = PowerManager.OnThermalStatusChangedListener { status ->
        handler?.post { applyThermalProfile(status) }
    }

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Log.i("Capture", "MediaProjection stopped by system/user")
            stopCaptureResources()
            stopSelf()
        }
    }

    override fun onCreate() {
        super.onCreate()
        thread = HandlerThread("rostik-capture", Process.THREAD_PRIORITY_MORE_FAVORABLE).also { it.start() }
        handler = Handler(thread!!.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (started) return START_STICKY

        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        } ?: return START_NOT_STICKY

        val pm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = try {
            pm.getMediaProjection(code, data)
        } catch (t: Throwable) {
            Log.e("Capture", "getMediaProjection failed", t)
            null
        }
        if (projection == null) return START_NOT_STICKY

        if (Build.VERSION.SDK_INT >= 29) {
            ServiceCompat.startForeground(
                this,
                29,
                notification(),
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(29, notification())
        }

        projection!!.registerCallback(projectionCallback, handler)

        val dm = resources.displayMetrics
        sourceWidth = dm.widthPixels
        sourceHeight = dm.heightPixels

        val thermal = if (Build.VERSION.SDK_INT >= 29) {
            (getSystemService(POWER_SERVICE) as PowerManager).currentThermalStatus
        } else 0
        val profile = CapturePerformance.profile(this, thermal)
        val size = CapturePerformance.fitInside(sourceWidth, sourceHeight, profile.maxDimension)

        BotRuntime.setVisionTargetFps(profile.targetVisionFps)
        installSurface(size.first, size.second, profile.name, profile.maxDimension)

        if (Build.VERSION.SDK_INT >= 29) {
            try {
                (getSystemService(POWER_SERVICE) as PowerManager)
                    .addThermalStatusListener(handlerExecutor, thermalListener)
                thermalListenerRegistered = true
            } catch (t: Throwable) {
                Log.w("Capture", "thermal listener unavailable", t)
            }
        }

        started = virtualDisplay != null && reader != null
        BotRuntime.setCaptureActive(started)
        return if (started) START_STICKY else START_NOT_STICKY
    }

    /** Rebuild only the ImageReader/VirtualDisplay surface; MediaProjection stays alive. */
    private fun installSurface(width: Int, height: Int, profileName: String, maxDimension: Int) {
        if (rebuilding.getAndSet(true)) return
        try {
            try { virtualDisplay?.release() } catch (_: Throwable) {}
            virtualDisplay = null
            try { reader?.setOnImageAvailableListener(null, null) } catch (_: Throwable) {}
            try { reader?.close() } catch (_: Throwable) {}
            reader = null

            val r = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3)
            if (Build.VERSION.SDK_INT >= 30) {
                try {
                    // Hint to Android that this consumer is interested in a
                    // high-refresh stream. The scheduler may ignore the hint
                    // when the physical display/game cannot provide it.
                    r.surface.setFrameRate(240f, android.view.Surface.FRAME_RATE_COMPATIBILITY_NO_VIOLATION)
                } catch (_: Throwable) { }
            }
            r.setOnImageAvailableListener({ imageReader ->
                val image = try { imageReader.acquireLatestImage() } catch (_: Throwable) { null }
                    ?: return@setOnImageAvailableListener
                framesSeen++
                try {
                    val plane = image.planes.firstOrNull() ?: return@setOnImageAvailableListener
                    val buffer = plane.buffer
                    val w = image.width
                    val h = image.height
                    val rowStride = plane.rowStride
                    val pixelStride = plane.pixelStride
                    if (pixelStride <= 0 || rowStride < w * pixelStride) return@setOnImageAvailableListener

                    val paddedWidth = rowStride / pixelStride
                    val source = Bitmap.createBitmap(
                        paddedWidth,
                        h,
                        Bitmap.Config.ARGB_8888
                    )
                    buffer.rewind()
                    source.copyPixelsFromBuffer(buffer)

                    val frame = if (paddedWidth == w) {
                        source
                    } else {
                        // The exact visible frame is used by OCR/navigation. The
                        // padding bitmap is immediately recycled after the crop.
                        val exact = Bitmap.createBitmap(source, 0, 0, w, h)
                        try { source.recycle() } catch (_: Throwable) {}
                        exact
                    }

                    val now = SystemClock.uptimeMillis()
                    val sink = onBitmap
                    if (sink != null) {
                        framesDelivered++
                        lastFrameAt = now
                        sink(frame)
                    } else {
                        try { frame.recycle() } catch (_: Throwable) {}
                    }
                    maybeLogStats(now, profileName, maxDimension, w, h)
                } catch (t: Throwable) {
                    Log.w("Capture", "frame failed", t)
                } finally {
                    try { image.close() } catch (_: Throwable) {}
                }
            }, handler)

            reader = r
            virtualDisplay = projection?.createVirtualDisplay(
                "RostikCapture",
                width,
                height,
                resources.displayMetrics.densityDpi,
                android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                r.surface,
                null,
                handler
            )
            currentProfileName = profileName
            currentMaxDimension = maxDimension
            Log.i("Capture", "surface ${width}x${height}, profile=$profileName, max=$maxDimension; requestedCaptureFps<=240")
        } finally {
            rebuilding.set(false)
        }
    }

    private fun applyThermalProfile(status: Int) {
        if (!started || projection == null || sourceWidth <= 0 || sourceHeight <= 0) return
        val profile = CapturePerformance.profile(this, status)

        // Do NOT recreate VirtualDisplay here. Android 14+ permits only one
        // createVirtualDisplay() call per MediaProjection instance. Thermal
        // changes therefore affect analysis cadence only; the capture surface
        // remains stable for the lifetime of this projection session.
        if (profile.targetVisionFps == BotRuntime.currentVisionTargetFps() &&
            profile.name == currentProfileName) return

        Log.i("Capture", "thermal=$status -> analysis=${profile.name}; capture surface stays stable")
        BotRuntime.setVisionTargetFps(profile.targetVisionFps)
    }

    private fun maybeLogStats(now: Long, profile: String, maxDimension: Int, width: Int, height: Int) {
        if (now - lastStatsAt < 5_000L) return
        lastStatsAt = now
        val seen = framesSeen
        val delivered = framesDelivered
        Log.i(
            "Capture",
            "profile=$profile max=$maxDimension size=${width}x${height} seen=$seen delivered=$delivered"
        )
    }

    private fun notification(): Notification {
        val ch = NotificationChannel("capture", "Rostik Capture", NotificationManager.IMPORTANCE_LOW)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        return Notification.Builder(this, "capture")
            .setContentTitle("Rostik Touch Bot v30.14")
            .setContentText("Adaptive high-quality screen capture")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    private fun stopCaptureResources() {
        started = false
        BotRuntime.setCaptureActive(false)
        if (Build.VERSION.SDK_INT >= 29 && thermalListenerRegistered) {
            try {
                (getSystemService(POWER_SERVICE) as PowerManager)
                    .removeThermalStatusListener(thermalListener)
            } catch (_: Throwable) {}
            thermalListenerRegistered = false
        }
        try { virtualDisplay?.release() } catch (_: Throwable) {}
        virtualDisplay = null
        try { reader?.setOnImageAvailableListener(null, null) } catch (_: Throwable) {}
        try { reader?.close() } catch (_: Throwable) {}
        reader = null
        try { projection?.unregisterCallback(projectionCallback) } catch (_: Throwable) {}
        try { projection?.stop() } catch (_: Throwable) {}
        projection = null
        onBitmap = null
    }

    override fun onDestroy() {
        stopCaptureResources()
        try { thread?.quitSafely() } catch (_: Throwable) {}
        thread = null
        handler = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
