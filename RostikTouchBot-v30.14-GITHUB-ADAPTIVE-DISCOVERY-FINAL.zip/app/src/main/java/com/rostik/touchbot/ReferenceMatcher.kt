package com.rostik.touchbot

import android.content.res.AssetManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import kotlin.math.abs

/** Whole-screen reference matcher used only to authorize a conservative fallback tap. */
class ReferenceMatcher(private val assets: AssetManager) {
    private val cache = HashMap<String, Bitmap?>()

    fun score(screen: Bitmap, referenceName: String): Float {
        val ref = load(referenceName) ?: return 0f
        val sw = 48; val sh = 22
        val a = Bitmap.createScaledBitmap(screen, sw, sh, true)
        val b = Bitmap.createScaledBitmap(ref, sw, sh, true)
        val ap = IntArray(sw * sh); val bp = IntArray(sw * sh)
        a.getPixels(ap, 0, sw, 0, 0, sw, sh)
        b.getPixels(bp, 0, sw, 0, 0, sw, sh)
        var err = 0.0
        for (i in ap.indices) {
            err += (abs(Color.red(ap[i])-Color.red(bp[i])) + abs(Color.green(ap[i])-Color.green(bp[i])) + abs(Color.blue(ap[i])-Color.blue(bp[i]))) / 765.0
        }
        a.recycle(); b.recycle()
        return (1.0 - err / ap.size).toFloat().coerceIn(0f,1f)
    }

    private fun load(name: String): Bitmap? {
        if (cache.containsKey(name)) return cache[name]
        val b = try { assets.open("reference/$name.png").use { BitmapFactory.decodeStream(it) } } catch (_: Throwable) { null }
        cache[name] = b
        return b
    }
}
