package com.rostik.touchbot

class CupReader {
    fun read(lines: List<OcrLine>, now: Long): Int? {
        val fresh = lines.filter { now - it.capturedAt <= 2000L }
        val candidates = fresh.flatMap { line ->
            Regex("""(?<!\d)(\d{2,4})(?!\d)""").findAll(line.text)
                .mapNotNull { it.groupValues[1].toIntOrNull() }
                .filter { it in 0..10000 }
                .toList()
        }
        return candidates.firstOrNull()
    }
}
