package com.rostik.touchbot

/** Conservative OCR reader for signed result deltas and current brawler trophies. */
class TrophyReader {
    fun resultDelta(lines: List<OcrLine>): Int? {
        val candidates = lines.asSequence()
            .filter { it.rect.t < .55f && it.rect.l < .75f }
            .flatMap { line ->
                Regex("""([+-])\s*(\d{1,3})""").findAll(line.text.replace('−','-')).mapNotNull {
                    val n = it.groupValues[2].toIntOrNull() ?: return@mapNotNull null
                    if (n <= 100) (if (it.groupValues[1] == "+") n else -n) else null
                }
            }
            .toList()
        return candidates.distinct().singleOrNull() ?: candidates.firstOrNull()
    }

    fun currentBrawlerCups(lines: List<OcrLine>, expected: Int? = null): Int? {
        data class Candidate(val value: Int, val line: OcrLine)
        val candidates = lines.asSequence()
            .flatMap { line ->
                Regex("(?<!\\d)(\\d{1,4})(?!\\d)").findAll(line.text).mapNotNull {
                    val n = it.groupValues[1].toIntOrNull() ?: return@mapNotNull null
                    if (n in 0..5000) Candidate(n, line) else null
                }
            }
            .filter { c ->
                val r = c.line.rect
                // Trophy counters in the supplied references live in the card/profile
                // content area, not in the top navigation bar or bottom tab bar.
                r.t < .86f && r.b > .08f
            }
            .toList()

        if (candidates.isEmpty()) return null
        val target = expected?.coerceIn(0,5000)
        return candidates.minByOrNull { c ->
            val r = c.line.rect
            val spatial = kotlin.math.abs(r.center().x - .25f) + kotlin.math.abs(r.center().y - .52f)
            val expectedPenalty = if (target == null) 0f else kotlin.math.abs(c.value - target) / 500f
            spatial + expectedPenalty
        }?.value
    }
}
