package com.rostik.touchbot

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import java.util.concurrent.atomic.AtomicLong

/** Process-local bridge shared by MainActivity, capture and floating overlay. */
object BotRuntime {
    private lateinit var app: Context
    val queue: QueueEngine = QueueEngine()
    val supervisor: MatchSupervisor by lazy { MatchSupervisor(queue, app.assets) }

    @Volatile var captureActive: Boolean = false
        private set

    @Volatile var preferredMapId: String? = null

    @Volatile private var visionTargetFps: Int = 60
    private val lastAcceptedFrameAt = AtomicLong(0L)

    fun init(context: Context) {
        app = context.applicationContext
        StatsStore.init(app)
    }

    fun submitFrame(bitmap: Bitmap) {
        // The capture service can produce more frames than the CV loop can safely
        // process. Keep the newest frame and pace acceptance to the thermal profile.
        val now = SystemClock.uptimeMillis()
        val fps = visionTargetFps.coerceIn(15, 240)
        val interval = 1000L / fps
        val previous = lastAcceptedFrameAt.get()
        if (previous != 0L && now - previous < interval) {
            try { bitmap.recycle() } catch (_: Throwable) {}
            return
        }
        lastAcceptedFrameAt.set(now)
        supervisor.submitLatestFrame(bitmap)
    }

    fun setVisionTargetFps(fps: Int) {
        visionTargetFps = fps.coerceIn(15, 240)
    }

    fun currentVisionTargetFps(): Int = visionTargetFps

    fun setCaptureActive(active: Boolean) {
        captureActive = active
        if (!active) lastAcceptedFrameAt.set(0L)
    }
}
