package com.rostik.touchbot

/**
 * Safe fallbacks only. Normal operation uses ControlDetector's per-frame
 * coordinates. These defaults come from the supplied 1280x588 recording.
 */
object TouchLayout {
    val MOVE = Point(0.100f, 0.775f)
    val ATTACK = Point(0.905f, 0.790f)
    val SUPER = Point(0.710f, 0.745f)
    val GADGET = Point(0.64f, 0.77f)

    fun moveTarget(base: Point, x: Float, y: Float): Point = Point(
        (base.x + x * 0.12f).coerceIn(0.025f, 0.975f),
        (base.y + y * 0.12f).coerceIn(0.10f, 0.96f)
    )
}
