package com.rostik.touchbot

/**
 * Known Brawl Ball map names/aliases used only for recognition and safe verification.
 * The bot never taps a map merely because a name exists in this catalog: a map tap is
 * allowed only when the live screen also exposes an explicit map-selection UI.
 */
object BrawlBallMapCatalog {
    data class Entry(val id: String, val name: String, val aliases: List<String>)

    private fun e(id: String, name: String, vararg aliases: String) = Entry(id, name, aliases.toList())

    val all = listOf(
        e("backyard_bowl", "Backyard Bowl", "backyard bowl", "задний двор"),
        e("center_stage", "Center Stage", "center stage", "центр сцены"),
        e("field_goal", "Field Goal", "field goal", "гол в поле"),
        e("pinhole_punt", "Pinhole Punt", "pinhole punt"),
        e("sneaky_fields", "Sneaky Fields", "sneaky fields"),
        e("super_beach", "Super Beach", "super beach"),
        e("triple_dribble", "Triple Dribble", "triple dribble"),
        e("super_stadium", "Super Stadium", "super stadium"),
        e("playground", "Playground", "playground"),
        e("soccer_field", "Soccer Field", "soccer field"),
        e("sunny_soccer", "Sunny Soccer", "sunny soccer"),
        e("extra_rare", "Extra Rare", "extra rare"),
        e("hard_landing", "Hard Landing", "hard landing"),
        e("post_haste", "Post Haste", "post haste")
    )

    fun find(text: String): Entry? {
        val n = normalize(text)
        return all.firstOrNull { e ->
            e.aliases.any { a ->
                val x = normalize(a)
                x.isNotEmpty() && (n == x || n.contains(x))
            }
        }
    }

    private fun normalize(s: String) = s.lowercase().replace('ё', 'е')
        .replace(Regex("[^a-zа-я0-9]"), "")
}
