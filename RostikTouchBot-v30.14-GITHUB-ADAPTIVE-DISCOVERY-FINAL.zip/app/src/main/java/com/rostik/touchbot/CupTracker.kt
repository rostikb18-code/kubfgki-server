package com.rostik.touchbot

class CupTracker {
    private var lastValue: Int? = null
    private var confirmations = 0
    private var lastTimestamp = 0L

    fun offer(value: Int?, timestamp: Long): Int? {
        if (value == null || timestamp <= lastTimestamp) return null
        lastTimestamp = timestamp
        if (lastValue == value) confirmations++ else {
            lastValue = value
            confirmations = 1
        }
        return if (confirmations >= 3) value else null
    }

    fun reset() {
        lastValue = null
        confirmations = 0
        lastTimestamp = 0L
    }
}
