package com.rostik.touchbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class BotAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: BotAccessibilityService? = null }

    override fun onServiceConnected(){ super.onServiceConnected(); instance=this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt(){}
    override fun onDestroy(){ if(instance===this) instance=null; super.onDestroy() }

    /**
     * One control frame: hold/drag movement and press attack independently.
     * The attack control is intentionally a TAP, not an aim-drag. This matches
     * the requested auto-aim-by-press behavior. Super is a separate tap.
     */
    fun dispatch(frame:ControlFrame, left:Point = TouchLayout.MOVE, right:Point = TouchLayout.ATTACK, duration:Long=85L):Boolean {
        val w=resources.displayMetrics.widthPixels.toFloat()
        val h=resources.displayMetrics.heightPixels.toFloat()
        val builder=GestureDescription.Builder()

        // Do not touch the movement stick when this frame is a fire-only or
        // super-only action. A zero-length movement stroke still occupies a
        // gesture slot on some Android builds and was a source of lag/dropped taps.
        if (kotlin.math.abs(frame.moveX) > .04f || kotlin.math.abs(frame.moveY) > .04f) {
            val move=TouchLayout.moveTarget(left, frame.moveX, frame.moveY)
            val lp=Path().apply{
                moveTo(left.x*w,left.y*h)
                lineTo(move.x*w,move.y*h)
            }
            builder.addStroke(GestureDescription.StrokeDescription(lp,0,duration))
        }

        if(frame.fire){
            val ap=Path().apply{
                moveTo(right.x*w,right.y*h)
                lineTo(right.x*w,right.y*h)
            }
            builder.addStroke(GestureDescription.StrokeDescription(ap,0,55L))
        }

        if(frame.useSuper){
            val s=frame.superPoint ?: TouchLayout.SUPER
            val sp=Path().apply{
                moveTo(s.x*w,s.y*h)
                lineTo(s.x*w,s.y*h)
            }
            builder.addStroke(GestureDescription.StrokeDescription(sp,0,55L))
        }

        return dispatchGesture(builder.build(),null,null)
    }

    fun tap(p:Point):Boolean{
        val x=p.x*resources.displayMetrics.widthPixels
        val y=p.y*resources.displayMetrics.heightPixels
        val path=Path().apply{moveTo(x,y);lineTo(x,y)}
        return dispatchGesture(GestureDescription.Builder().addStroke(
            GestureDescription.StrokeDescription(path,0,55L)).build(),null,null)
    }

    /** Best-effort text entry for game search fields that expose an editable
     * AccessibilityNodeInfo. Unity screens often expose no nodes, so failure
     * simply returns false and the vision selector continues with horizontal
     * traversal. */
    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findEditable(root) ?: return false
        val args = android.os.Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable && node.isEnabled) return node
        for (i in 0 until node.childCount) {
            val child = try { node.getChild(i) } catch (_: Throwable) { null } ?: continue
            val found = findEditable(child)
            if (found != null) return found
        }
        return null
    }

    fun swipe(from: Point, to: Point, duration: Long = 420L): Boolean {
        val w = resources.displayMetrics.widthPixels
        val h = resources.displayMetrics.heightPixels
        val path = Path().apply { moveTo(from.x * w, from.y * h); lineTo(to.x * w, to.y * h) }
        return dispatchGesture(GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration)).build(), null, null)
    }
}
