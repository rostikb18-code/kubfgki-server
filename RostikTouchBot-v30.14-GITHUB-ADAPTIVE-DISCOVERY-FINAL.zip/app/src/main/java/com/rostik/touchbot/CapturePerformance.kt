package com.rostik.touchbot

import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.PowerManager
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * High-FPS capture policy.
 *
 * 240 FPS is a CEILING, not a promise. Android can only deliver frames that
 * the source display/game actually produces. A 60/90/120 Hz phone will not
 * magically become a 240 Hz capture source.
 *
 * Capture resolution is kept stable during one MediaProjection session. This
 * is important on Android 14+: recreating VirtualDisplay on the same
 * MediaProjection instance is not allowed. Thermal throttling therefore
 * changes the analysis cadence, not the capture session itself.
 */
object CapturePerformance {
    data class Profile(
        val maxDimension: Int,
        val targetVisionFps: Int,
        val analysisWidth: Int,
        val name: String
    )

    fun supportedDisplayFps(context: Context): Int {
        if (Build.VERSION.SDK_INT < 23) return 60
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val display = dm.getDisplay(android.view.Display.DEFAULT_DISPLAY) ?: return 60
        val max = display.supportedModes.maxOfOrNull { it.refreshRate } ?: 60f
        return max.coerceAtLeast(30f).coerceAtMost(240f).toInt()
    }

    fun profile(context: Context, thermalStatus: Int): Profile {
        val hardwareMax = supportedDisplayFps(context)
        val target = if (Build.VERSION.SDK_INT < 29) {
            60
        } else {
            when (thermalStatus) {
                PowerManager.THERMAL_STATUS_CRITICAL,
                PowerManager.THERMAL_STATUS_EMERGENCY,
                PowerManager.THERMAL_STATUS_SHUTDOWN -> 30

                PowerManager.THERMAL_STATUS_SEVERE -> 60
                PowerManager.THERMAL_STATUS_MODERATE -> 120
                PowerManager.THERMAL_STATUS_LIGHT -> 180
                else -> hardwareMax
            }
        }.coerceAtMost(hardwareMax).coerceIn(30, 240)

        return Profile(
            maxDimension = 1920,
            targetVisionFps = target,
            analysisWidth = when {
                target >= 180 -> 400
                target >= 120 -> 384
                target >= 90 -> 368
                target >= 60 -> 352
                else -> 320
            },
            name = "${target}fps-cap"
        )
    }

    fun fitInside(width: Int, height: Int, maxDimension: Int): Pair<Int, Int> {
        val w = max(1, width)
        val h = max(1, height)
        val maxSide = max(w, h)
        if (maxSide <= maxDimension) return w to h
        val scale = maxDimension.toFloat() / maxSide.toFloat()
        return max(1, (w * scale).roundToInt()) to max(1, (h * scale).roundToInt())
    }
}
