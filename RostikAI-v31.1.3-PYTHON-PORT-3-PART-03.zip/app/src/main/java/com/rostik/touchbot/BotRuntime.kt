package com.rostik.touchbot

import android.content.Context
import android.graphics.Bitmap

/** Process-local bridge shared by MainActivity, capture and floating overlay. */
object BotRuntime {
    @Volatile private var app: Context? = null
    @Volatile private var initialized = false
    @Volatile private var crashHandlerInstalled = false
    val queue: QueueEngine = QueueEngine()
    val supervisor: MatchSupervisor by lazy {
        val context = app ?: throw IllegalStateException("BotRuntime.init() must be called before supervisor is used")
        MatchSupervisor(queue, context.assets, context)
    }

    val runtimeMetrics: RuntimeMetrics by lazy { RuntimeMetrics(app ?: throw IllegalStateException("BotRuntime.init() must be called before metrics")) }
    val perfProfiler: PerfProfiler by lazy { PerfProfiler() }
    val performanceAutoTuner: PerformanceAutoTuner by lazy { PerformanceAutoTuner(app ?: throw IllegalStateException("BotRuntime.init() must be called before autotune")) }

    @Volatile var captureActive: Boolean = false
        private set
    @Volatile var feedFps: Double = 0.0
        private set

    fun updateFeedFps(value: Double) { feedFps = value.coerceIn(0.0, 240.0) }

    fun init(context: Context) {
        val application = context.applicationContext
        if (initialized) return
        synchronized(this) {
            if (initialized) return
            app = application
            StatsStore.init(application)
            DiscordLogger.init(application)
            installCrashHandler(application)
            QueuePersistence.restore(application, queue)
            queue.setChangeListener { QueuePersistence.save(application, queue) }
            RuntimeLog.configure()
            runtimeMetrics.begin()
            initialized = true
        }
    }

    fun applicationContext(): Context = app ?: throw IllegalStateException("BotRuntime is not initialized")

    fun ensureInitialized(context: Context) {
        init(context)
    }

    fun submitFrame(bitmap: Bitmap) {
        // Ownership is transferred to MatchSupervisor. Do not keep another reference
        // here because the supervisor recycles each consumed frame.
        supervisor.submitLatestFrame(bitmap)
    }

    fun setCaptureActive(active: Boolean) {
        captureActive = active
        if (!active) feedFps = 0.0
        DiscordLogger.info(DiscordLogger.Category.SCREEN, if (active) "Захват экрана активен" else "Захват экрана остановлен", "captureActive=$active")
    }

    private fun installCrashHandler(context: Context) {
        if (crashHandlerInstalled) return
        synchronized(this) {
            if (crashHandlerInstalled) return
            crashHandlerInstalled = true
        }
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try { DiscordLogger.crash(context, thread, throwable) } catch (_: Throwable) {}
            try { previous?.uncaughtException(thread, throwable) } catch (_: Throwable) {}
        }
    }
}
