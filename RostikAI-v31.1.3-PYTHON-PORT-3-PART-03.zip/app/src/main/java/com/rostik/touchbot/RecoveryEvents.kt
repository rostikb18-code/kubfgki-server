package com.rostik.touchbot

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.util.concurrent.ConcurrentHashMap

object RecoveryEvents {
    private val recent = ConcurrentHashMap<String, MutableList<Long>>()
    fun log(context: Context, type:String, detail:String="", notice:String="", sessionId:String="android", screenshotPath:String=""): JSONObject {
        val record=JSONObject().put("ts", Instant.now().toString()).put("event_type",type).put("detail",detail).put("notice",notice).put("session_id",sessionId).put("screenshot_path",screenshotPath)
        val f=File(context.filesDir,"recovery_events.jsonl"); f.parentFile?.mkdirs(); synchronized(this){f.appendText(record.toString()+"\n")}
        return record
    }
    fun shouldSendAlert(eventType:String, threshold:Int=3, windowSeconds:Long=600):Boolean {
        val now=System.currentTimeMillis(); val list=recent.computeIfAbsent(eventType){mutableListOf()}
        synchronized(list){list.removeAll{now-it>windowSeconds*1000}; list.add(now); if(list.size>=threshold.coerceAtLeast(1)){list.clear();return true}}
        return false
    }
}
