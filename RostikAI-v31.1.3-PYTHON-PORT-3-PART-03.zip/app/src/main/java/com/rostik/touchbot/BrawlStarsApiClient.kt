package com.rostik.touchbot

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Port of the Python post-match Brawl Stars profile sync.
 * Only a manually supplied API token is used here; developer-account passwords
 * are deliberately not stored by the Android app.
 */
class BrawlStarsApiClient(private val context: Context) {
    companion object {
        private const val PREFS = "brawl_stars_api"
        private const val TOKEN = "api_token"
        private const val PLAYER_TAG = "player_tag"
        private const val SYNC = "sync_trophies_after_match"
        private const val TIMEOUT = 15000

        fun configure(context: Context, playerTag: String, token: String, enabled: Boolean = true) {
            context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(PLAYER_TAG, normalizeTag(playerTag))
                .putString(TOKEN, token.trim())
                .putBoolean(SYNC, enabled)
                .apply()
        }

        fun clear(context: Context) {
            context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
        }

        private fun normalizeTag(tag: String): String {
            val t = tag.trim().uppercase()
            return if (t.startsWith("#")) t else "#$t"
        }
    }

    data class SyncResult(val attempted: Boolean, val updated: Boolean, val reason: String, val trophies: Map<String, Int> = emptyMap())

    fun syncQueue(queue: QueueEngine, currentBrawlerId: String): SyncResult {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!p.getBoolean(SYNC, false)) return SyncResult(false, false, "disabled")
        val token = p.getString(TOKEN, "").orEmpty().trim()
        val tag = p.getString(PLAYER_TAG, "").orEmpty().trim()
        if (token.isBlank() || tag.isBlank() || tag == "#YOURTAG") return SyncResult(false, false, "missing_token_or_tag")
        return try {
            val data = fetchPlayer(token, tag)
            val brawlers = data.optJSONArray("brawlers") ?: return SyncResult(true, false, "no_brawlers_array")
            val map = LinkedHashMap<String, Int>()
            for (i in 0 until brawlers.length()) {
                val row = brawlers.optJSONObject(i) ?: continue
                val name = normalizeName(row.optString("name"))
                if (name.isBlank()) continue
                map[name] = row.optInt("trophies", 0).coerceIn(0, 10000)
            }
            var updated = false
            queue.snapshot().forEachIndexed { index, item ->
                val key = normalizeName(BrawlerCatalog.name(item.brawlerId))
                val api = map[key] ?: return@forEachIndexed
                if (api != item.currentCups) {
                    if (kotlin.math.abs(api - item.currentCups) <= 120) {
                        queue.setCupsFromAuthoritativeSource(index, api)
                        updated = true
                    }
                }
            }
            SyncResult(true, updated, if (updated) "updated" else "already_matches", map)
        } catch (t: Throwable) {
            SyncResult(true, false, "api_error:${t.message ?: t::class.java.simpleName}")
        }
    }

    private fun fetchPlayer(token: String, tag: String): JSONObject {
        val encoded = URLEncoder.encode(tag, Charsets.UTF_8.name()).replace("+", "%20")
        val connection = (URL("https://api.brawlstars.com/v1/players/$encoded").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = TIMEOUT
            readTimeout = TIMEOUT
            setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "RostikAI/${BuildConfig.VERSION_NAME}")
        }
        return try {
            val code = connection.responseCode
            val body = (if (code in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("Brawl Stars API HTTP $code: ${body.take(300)}")
            JSONObject(body)
        } finally { connection.disconnect() }
    }

    private fun normalizeName(value: String): String = value.lowercase().replace(Regex("[^a-z0-9]"), "")
}
