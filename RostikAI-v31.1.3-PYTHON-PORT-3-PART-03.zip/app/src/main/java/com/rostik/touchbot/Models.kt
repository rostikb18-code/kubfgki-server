package com.rostik.touchbot

import android.graphics.Bitmap
import java.util.concurrent.atomic.AtomicLong

data class Point(val x: Float, val y: Float)
data class RectN(val l: Float, val t: Float, val r: Float, val b: Float) {
    fun center() = Point((l + r) / 2f, (t + b) / 2f)
    fun area() = ((r-l).coerceAtLeast(0f) * (b-t).coerceAtLeast(0f))
}
data class Detection(
    val point: Point,
    val confidence: Float,
    val kind: String,
    val rect: RectN? = null,
    val velocity: Point = Point(0f, 0f)
)

enum class ScreenType { HOME, BRAWLER_LIST, BRAWLER_PROFILE, MODE_SELECT, BRAWL_BALL_LOBBY, LOADING, MATCH, RESULT, REWARD, UNKNOWN, PAUSED }

data class OcrLine(val text: String, val rect: RectN, val confidence: Float, val capturedAt: Long)

data class MatchScene(
    val player: Detection?,
    val enemies: List<Detection>,
    val allies: List<Detection>,
    val ball: Detection?,
    val superPoint: Point?,
    val superReady: Boolean,
    val superConfidence: Float = 0f,
    val leftJoystick: Point?,
    val rightJoystick: Point?,
    val attackConfidence: Float = 0f,
    val hudConfidence: Float,
    val confidence: Float,
    val timestamp: Long
)

data class ControlFrame(
    val moveX: Float = 0f,
    val moveY: Float = 0f,
    val aimX: Float = 0f,
    val aimY: Float = 0f,
    val fire: Boolean = false,
    val useSuper: Boolean = false,
    val superPoint: Point? = null
)

data class QueueItem(
    val brawlerId: String,
    var currentCups: Int,
    var targetCups: Int,
    var startCups: Int = currentCups,
    var matchesPlayed: Int = 0,
    var winStreak: Int = 0
) {
    val remaining get() = (targetCups - currentCups).coerceAtLeast(0)
    val reached get() = currentCups >= targetCups
}

enum class RunState { IDLE, PREPARE, SELECT_BRAWLER, VERIFY_BRAWLER, VERIFY_CUPS, SELECT_MODE, SELECT_MAP, PRESS_PLAY, LOADING, PLAYING, RESULT, REWARD, VERIFY_RESULT_CUPS, PLAY_AGAIN, DONE, PAUSED, ERROR }

class FrameLease(private val bitmap: Bitmap) {
    private val refs = AtomicLong(1)
    fun retain(): FrameLease { refs.incrementAndGet(); return this }
    fun get(): Bitmap = bitmap
    fun release() {
        if (refs.decrementAndGet() == 0L && !bitmap.isRecycled) {
            try { bitmap.recycle() } catch (_: Throwable) {}
        }
    }
}
