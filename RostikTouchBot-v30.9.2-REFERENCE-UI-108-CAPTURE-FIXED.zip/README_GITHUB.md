# GitHub build

The repository can contain this Android project directly at its root. The included workflow also discovers nested Android roots by locating `settings.gradle(.kts)`, `app/build.gradle(.kts)`, and the main manifest.

The workflow does not use the legacy Android SDK `tools` package and does not use `android-actions/setup-android`.

Artifacts produced:
- `app-debug.apk`
- `app-release.apk`

Before upload, the workflow verifies:
- 108 catalog entries
- 108 PNG brawler icons
- every catalog ID has a matching PNG
- neither known broken Kotlin symbol is present
- both APKs contain 108 brawler icon files
