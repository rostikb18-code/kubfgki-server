# Rostik Touch Bot v30.9.1 Stable

This release is based on the previously stable v30.9 source tree.

## What was changed
- Kept the v30.9 application architecture and UI as the base.
- Added all 108 brawler icon PNG assets required by `BrawlerCatalog`.
- Added `brawler_icons_manifest.txt` with all 108 IDs.
- Reworked `ScreenCaptureService` for the Android MediaProjection foreground-service order required by modern Android.
- Removed the later 240 FPS frame-rate API changes from the stable base.
- Removed the known invalid `FRAME_RATE_COMPATIBILITY_NO_VIOLATION` and `selectAllOnFocus =` patterns.
- MainActivity now waits for capture startup before automatically opening Brawl Stars.
- GitHub Actions automatically finds the Android project root, installs only modern SDK components, builds Debug/Release, and verifies that both APKs contain all 108 icons.

## Important Android flow
1. Grant overlay permission.
2. Enable Accessibility if automation is required.
3. Press `Захват экрана` and approve the Android system dialog.
4. The foreground MediaProjection service starts.
5. Only then is `getMediaProjection()` called and the virtual display created.

The screen-capture permission is an Android system permission and must be approved by the user.
