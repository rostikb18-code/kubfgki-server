package com.rostik.touchbot

import android.content.Context

/** Small crash/process-death recovery store for the active queue. */
object QueuePersistence {
    private const val PREF = "rostik_queue_state_v311"
    private const val KEY = "items"
    private const val IDX = "index"

    fun save(context: Context, queue: QueueEngine) {
        val encoded = queue.snapshot().joinToString(";") {
            "${it.brawlerId},${it.currentCups},${it.targetCups},${it.startCups},${it.matchesPlayed},${it.winStreak}"
        }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString(KEY, encoded)
            .putInt(IDX, queue.currentIndex())
            .apply()
    }

    fun restore(context: Context, queue: QueueEngine): Boolean {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val raw = sp.getString(KEY, null) ?: return false
        val parsed = raw.split(';').mapNotNull { row ->
            val p = row.split(',')
            if (p.size !in 5..6) return@mapNotNull null
            val c = p[1].toIntOrNull() ?: return@mapNotNull null
            val t = p[2].toIntOrNull() ?: return@mapNotNull null
            val s = p[3].toIntOrNull() ?: c
            val m = p[4].toIntOrNull() ?: 0
            val streak = if (p.size >= 6) p[5].toIntOrNull() ?: 0 else 0
            if (p[0].isBlank() || c !in 0..10000 || t !in 0..10000 || s !in 0..10000 || streak !in 0..100) null
            else QueueItem(p[0], c, t, s, m, streak)
        }
        if (parsed.isEmpty()) return false
        queue.restore(parsed, sp.getInt(IDX, 0))
        return true
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
