#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, zipfile, sys

ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / 'app/src/main/java/com/rostik/touchbot'
fail=[]

def req(ok,msg):
    if not ok: fail.append(msg)

kt=sorted(JAVA.glob('*.kt'))
req(len(kt)==39, f'expected 39 Kotlin files, got {len(kt)}')
req((ROOT/'settings.gradle.kts').is_file(), 'missing settings.gradle.kts')
req((ROOT/'build.gradle.kts').is_file(), 'missing build.gradle.kts')
req((ROOT/'gradle.properties').is_file(), 'missing gradle.properties')
req((ROOT/'app/build.gradle.kts').is_file(), 'missing app/build.gradle.kts')
req((ROOT/'app/src/main/AndroidManifest.xml').is_file(), 'missing AndroidManifest.xml')

build=(ROOT/'build.gradle.kts').read_text()
app=(ROOT/'app/build.gradle.kts').read_text()
props=(ROOT/'gradle.properties').read_text()
req('com.android.application") version "8.7.2"' in build, 'AGP must be 8.7.2 for KGP 2.1.0 compatibility')
req('org.jetbrains.kotlin.android") version "2.1.0"' in build, 'unexpected Kotlin plugin version')
req('compileSdk = 35' in app and 'targetSdk = 35' in app, 'compile/target SDK 35 missing')
req('jvmTarget = "17"' in app and 'targetCompatibility = JavaVersion.VERSION_17' in app, 'Java/Kotlin 17 alignment missing')
req('kotlin.jvm.target.validation.mode=error' in props, 'strict JVM target validation missing')

manifest=(ROOT/'app/src/main/AndroidManifest.xml').read_text()
for x in ['FOREGROUND_SERVICE_MEDIA_PROJECTION','FOREGROUND_SERVICE_SPECIAL_USE','BIND_ACCESSIBILITY_SERVICE','android:foregroundServiceType="mediaProjection"','android:foregroundServiceType="specialUse"']:
    req(x in manifest, f'manifest missing {x}')

overlay=(JAVA/'OverlayService.kt').read_text()
main=(JAVA/'MainActivity.kt').read_text()
capture=(JAVA/'ScreenCaptureService.kt').read_text()
supervisor=(JAVA/'MatchSupervisor.kt').read_text()
access=(JAVA/'BotAccessibilityService.kt').read_text()
for text,name in [(main,'MainActivity'),(capture,'ScreenCaptureService'),(supervisor,'MatchSupervisor'),(access,'BotAccessibilityService'),(overlay,'OverlayService')]:
    req('!!' not in '\n'.join(l for l in text.splitlines() if '!!' in l and '!!.' not in l), f'suspicious non-null assertion in {name}')
req('registerForActivityResult' in main, 'modern Activity Result API missing')
req('acquireLatestImage' in capture, 'capture must use acquireLatestImage')
req('canPerformGestures' in (ROOT/'app/src/main/res/xml/accessibility_service_config.xml').read_text(), 'gesture capability missing')
req('setSelectAllOnFocus(false)' in overlay, 'trophy input focus configuration missing')
req('this.text = text' in overlay, 'EditText text assignment fix missing')
req('TYPE_CLASS_NUMBER' in overlay, 'numeric trophy input missing')
req('take(5)' in overlay and 'coerceIn(0, 10000)' in overlay, 'trophy input range/multi-digit guard missing')
req('sizeSlider("ШИРИНА"' in overlay and 'sizeSlider("ВЫСОТА"' in overlay, 'width/height sliders missing')
req('wm.updateViewLayout' in overlay and 'updatePanelSize()' in overlay, 'live panel resize missing')
req('putInt("width_pct"' in overlay and 'putInt("height_pct"' in overlay, 'size persistence missing')
req('QueueItem(id, v.first, v.second)' in overlay, 'trophy values are not passed to queue')
req('val superPoint = frame.superPoint' in supervisor and 'left ?: TouchLayout.MOVE, right' in supervisor, 'Super gesture dispatch fix missing')

icons=list((ROOT/'app/src/main/assets/brawler_icons').iterdir()) if (ROOT/'app/src/main/assets/brawler_icons').is_dir() else []
req(len(icons)==108, f'expected 108 brawler icons, got {len(icons)}')
req((ROOT/'app/src/main/assets/apk_port/maps/brawl_ball_maps.json').is_file(), 'maps asset missing')
for m in ['m0.bin','m1.bin','m2.bin']:
    req((ROOT/'app/src/main/assets/apk_port/models'/m).is_file(), f'model missing: {m}')

# duplicate class/object top-level names
names={}
for f in kt:
    s=f.read_text(errors='ignore')
    for m in re.finditer(r'^(?:public\s+|internal\s+|private\s+)?(?:data\s+class|sealed\s+class|enum\s+class|class|object|interface)\s+(\w+)',s,re.M):
        n=m.group(1)
        names.setdefault(n,[]).append(str(f))
for n,fs in names.items():
    if len(fs)>1 and n not in {'Point'}:
        fail.append(f'duplicate top-level type {n}: {fs}')

# Hard placeholder/error markers.
for f in kt:
    s=f.read_text(errors='ignore')
    if '!!' in s:
        fail.append(f'non-null assertion (!!) in {f}')
    for pat in [r'\bTODO\b',r'FIXME',r'NotImplementedException',r'UnsupportedOperationException']:
        if re.search(pat,s): fail.append(f'placeholder marker {pat} in {f}')

# Verify all repo text files are UTF-8 readable.
for f in ROOT.rglob('*'):
    if f.is_file() and f.stat().st_size < 8_000_000 and f.suffix in {'.kt','.kts','.xml','.py','.txt','.md','.yml','.yaml','.properties'}:
        try: f.read_text()
        except Exception as e: fail.append(f'not UTF-8 readable: {f}: {e}')

if fail:
    print('FULL_AUDIT_FAIL')
    for x in fail: print('ERROR:',x)
    sys.exit(1)
print('FULL_AUDIT_PASS')
print(f'kotlin={len(kt)} brawler_icons={len(icons)}')
print('agp=8.7.2 kotlin=2.1.0 gradle_ci=8.10.2 java=17 sdk=35')
