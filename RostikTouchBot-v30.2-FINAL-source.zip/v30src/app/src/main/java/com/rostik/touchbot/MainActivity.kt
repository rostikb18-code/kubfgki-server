package com.rostik.touchbot

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var body: LinearLayout
    private var activeSection = 0
    private var launchGameAfterCapture = false

    private val captureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val captureIntent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
            }
            ScreenCaptureService.onBitmap = { bmp -> BotRuntime.submitFrame(bmp) }
            ContextCompat.startForegroundService(this, captureIntent)
            BotRuntime.setCaptureActive(true)
            toast("Захват экрана включён")
            if (activeSection == 2) showSection(2)
            if (launchGameAfterCapture) { launchGameAfterCapture = false; openBrawlStars() }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::body.isInitialized && activeSection == 2) showSection(2)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        StatsStore.init(this)
        BotRuntime.init(this)
        requestNotificationPermissionIfNeeded()
        buildShell()
    }

    private fun buildShell() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(8, 25, 48))
            setPadding(dp(16), dp(14), dp(16), dp(10))
        }
        val title = TextView(this).apply {
            text = "ROSTIK TOUCH BOT v30.2"
            textSize = 24f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(title, LinearLayout.LayoutParams(-1, dp(46)))

        val nav = LinearLayout(this).apply { gravity = Gravity.CENTER }
        listOf("ИГРАТЬ", "СТАТИСТИКА", "РАЗРЕШЕНИЯ").forEachIndexed { i, label ->
            nav.addView(Button(this).apply {
                text = label
                textSize = 11f
                setTextColor(Color.WHITE)
                background = tabBackground(i == activeSection)
                setOnClickListener { activeSection = i; updateNav(nav); showSection(i) }
                tag = i
                layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply {
                    setMargins(dp(3), 0, dp(3), 0)
                }
            })
        }
        root.addView(nav)
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(12), 0, 0)
        }
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        showSection(0)
    }

    private fun updateNav(nav: LinearLayout) {
        for (i in 0 until nav.childCount) {
            nav.getChildAt(i).background = tabBackground(i == activeSection)
        }
    }

    private fun showSection(section: Int) {
        body.removeAllViews()
        when (section) {
            0 -> showPlay()
            1 -> showStats()
            2 -> showPermissions()
        }
    }

    private fun showPlay() {
        body.addView(TextView(this).apply {
            text = "Нажми «ИГРАТЬ» — поверх игры появится маленькая кнопка AI.\nЧерез AI можно открыть очередь, выбрать бойцов, задать кубки и запустить бота."
            textSize = 15f
            setTextColor(Color.rgb(205, 222, 240))
            setPadding(dp(4), dp(8), dp(4), dp(18))
        })
        body.addView(Button(this).apply {
            text = "ИГРАТЬ"
            textSize = 18f
            setTextColor(Color.WHITE)
            background = actionBackground(Color.rgb(0, 170, 105))
            layoutParams = LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(0, dp(6), 0, dp(12)) }
            setOnClickListener { play() }
        })
        body.addView(infoCard("После запуска", "AI остаётся маленькой плавающей кнопкой. Нажми её в любой момент, чтобы открыть управление."))
        body.addView(infoCard("Очередь", "Слева выбираешь бойцов. Справа для каждого задаёшь «сейчас → цель». START запускает последовательность."))
        body.addView(infoCard("Размер", "В панели AI можно отдельно изменить ширину и высоту окна, чтобы оно не занимало весь экран."))
    }

    private fun play() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Сначала разреши отображение поверх других приложений")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (!isAccessibilityEnabled()) {
            toast("Включи Accessibility для управления жестами")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        startOverlayService()
        if (!BotRuntime.captureActive) {
            launchGameAfterCapture = true
            requestCapture()
            return
        }
        openBrawlStars()
    }

    private fun openBrawlStars() {
        packageManager.getLaunchIntentForPackage("com.supercell.brawlstars")?.let { startActivity(it) }
            ?: toast("Brawl Stars не найден на устройстве")
    }

    private fun showStats() {
        val s = StatsStore.snapshot()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(statCard("ВРЕМЯ ИГРЫ", s.timeText()))
        box.addView(statCard("ЧИСТЫЕ КУБКИ", if (s.netCups >= 0) "+${s.netCups}" else s.netCups.toString()))
        box.addView(statCard("ВИНРЕЙТ", "${s.winRate}%"))
        box.addView(statCard("МАТЧИ", "${s.matches}   •   побед ${s.wins}   •   поражений ${s.losses}   •   ничьих ${s.draws}"))
        box.addView(Button(this).apply {
            text = "СБРОСИТЬ СТАТИСТИКУ"
            setOnClickListener {
                StatsStore.reset()
                showSection(1)
            }
        })
        body.addView(box)
        handler.postDelayed({ if (activeSection == 1) showSection(1) }, 1000L)
    }

    private fun showPermissions() {
        body.addView(permissionRow(
            "Окно поверх других приложений",
            Settings.canDrawOverlays(this),
            "ВЫДАТЬ"
        ) { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) })

        body.addView(permissionRow(
            "Accessibility / управление жестами",
            isAccessibilityEnabled(),
            "ОТКРЫТЬ"
        ) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })

        body.addView(permissionRow(
            "Захват экрана",
            BotRuntime.captureActive,
            "ВКЛЮЧИТЬ"
        ) { requestCapture() })

        if (Build.VERSION.SDK_INT >= 33) {
            val granted = checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            body.addView(permissionRow("Уведомления", granted, "ВЫДАТЬ") { requestNotificationPermissionIfNeeded() })
        }

        body.addView(TextView(this).apply {
            text = "Нужны все четыре разрешения, чтобы AI мог видеть экран и отправлять жесты. Android показывает системные окна разрешений сам."
            textSize = 13f
            setTextColor(Color.rgb(165, 190, 215))
            setPadding(dp(4), dp(18), dp(4), dp(4))
        })
    }

    private fun requestCapture() {
        val pm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureLauncher.launch(pm.createScreenCaptureIntent())
    }

    private fun isAccessibilityEnabled(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager
        return manager.isEnabled && manager.getEnabledAccessibilityServiceList(
            android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK
        ).any { it.resolveInfo.serviceInfo.packageName == packageName }
    }

    private fun permissionRow(title: String, granted: Boolean, button: String, click: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(8), dp(10))
            background = actionBackground(Color.rgb(15, 45, 78))
            layoutParams = LinearLayout.LayoutParams(-1, dp(66)).apply { setMargins(0, dp(5), 0, dp(5)) }
        }
        row.addView(TextView(this).apply {
            text = if (granted) "✓  $title" else "○  $title"
            textSize = 14f
            setTextColor(if (granted) Color.rgb(70, 230, 150) else Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
            gravity = Gravity.CENTER_VERTICAL
        })
        row.addView(Button(this).apply {
            text = button
            setOnClickListener { click() }
        })
        return row
    }

    private fun statCard(label: String, value: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(12), dp(16), dp(12))
        background = actionBackground(Color.rgb(15, 45, 78))
        layoutParams = LinearLayout.LayoutParams(-1, dp(82)).apply { setMargins(0, dp(5), 0, dp(5)) }
        addView(TextView(this@MainActivity).apply {
            text = label
            textSize = 11f
            setTextColor(Color.rgb(145, 177, 208))
        })
        addView(TextView(this@MainActivity).apply {
            text = value
            textSize = 21f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
    }

    private fun infoCard(title: String, text: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(10), dp(14), dp(10))
        background = actionBackground(Color.rgb(15, 45, 78))
        layoutParams = LinearLayout.LayoutParams(-1, dp(78)).apply { setMargins(0, dp(5), 0, dp(5)) }
        addView(TextView(this@MainActivity).apply { this.text = title; textSize = 14f; setTextColor(Color.WHITE) })
        addView(TextView(this@MainActivity).apply { this.text = text; textSize = 11f; setTextColor(Color.rgb(160, 188, 215)) })
    }

    private fun tabBackground(selected: Boolean) = actionBackground(if (selected) Color.rgb(55, 175, 235) else Color.rgb(19, 53, 86))
    private fun actionBackground(color: Int) = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(14).toFloat() }

    private fun startOverlayService() {
        val intent = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) ContextCompat.startForegroundService(this, intent) else startService(intent)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
