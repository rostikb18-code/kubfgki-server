package com.rostik.touchbot

import android.graphics.Bitmap
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * Single owner of the navigation state machine.
 *
 * Critical actions are always perception -> tap -> verification. If the current
 * screen is not recognized with enough confidence, the supervisor waits instead
 * of tapping a guessed coordinate.
 */
class MatchSupervisor(private val queue: QueueEngine, private val assets: android.content.res.AssetManager): AutoCloseable {
    private val vision = MatchVision()
    private val ocr = OcrEngine()
    private val cupTracker = CupTracker()
    private val trophyReader = TrophyReader()
    private val navigation = NavigationVision()
    private val references = ReferenceMatcher(assets)
    private val selector = BrawlerSelector(assets)
    private val controller = ReactiveBrawlBallController()
    private val reward = RewardHandler()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val frameChannel = Channel<BitmapRef>(Channel.CONFLATED)
    private val latestScene = AtomicReference<MatchScene?>(null)
    private val latestOcr = AtomicReference<List<OcrLine>>(emptyList())
    private val latestOcrAt = AtomicLong(0L)

    @Volatile private var state = RunState.IDLE
    @Volatile private var running = false
    @Volatile private var paused = false
    @Volatile private var stateBeforePause = RunState.IDLE

    private var lastOcrAt = 0L
    private var stateSince = 0L
    private var actionBusyUntil = 0L
    private var workerStarted = false
    private var brawlerAttempts = 0
    private var brawlerScrolls = 0
    private var brawlerScrollDirection = 1
    private var lastBrawlerGridFingerprint: Long? = null
    private var unchangedGridCount = 0
    private var cupMismatchSince = 0L
    private var loadingEvidence = 0
    private var lastLoadingEvidenceAt = 0L
    private var matchStartedAt = 0L
    private var matchStartCups: Int? = null
    private var pendingDelta: Int? = null
    private var deltaConfirmations = 0
    private var matchResultRecorded = false
    private var resultSince = 0L
    private var rewardSince = 0L
    private var lastOutcome: MatchOutcome? = null
    private var advanceAfterCupVerification = false

    data class BitmapRef(val bitmap: Bitmap)

    fun start() {
        if (running) return
        running = true; paused = false
        transition(RunState.PREPARE)
        brawlerAttempts = 0; brawlerScrolls = 0; brawlerScrollDirection = 1
        lastBrawlerGridFingerprint = null; unchangedGridCount = 0
        cupMismatchSince = 0L; matchStartCups = null
        loadingEvidence = 0; lastLoadingEvidenceAt = 0L
        pendingDelta = null; deltaConfirmations = 0
        matchResultRecorded = false; resultSince = 0L; rewardSince = 0L; advanceAfterCupVerification = false
        cupTracker.reset(); reward.reset()
        StatsStore.beginRun()
        startWorkerIfNeeded()
    }

    fun pause() {
        if (running && !paused) { stateBeforePause = state; paused = true; transition(RunState.PAUSED) }
    }

    fun resume() {
        if (running && paused) { paused = false; transition(stateBeforePause) }
    }

    fun stop() {
        running = false; paused = false; transition(RunState.IDLE)
        StatsStore.endRun()
        drainFrames()
        latestScene.set(null); latestOcr.set(emptyList()); latestOcrAt.set(0L)
    }

    fun submitLatestFrame(bitmap: Bitmap) {
        if (!running) { safeRecycle(bitmap); return }
        val result = frameChannel.trySend(BitmapRef(bitmap))
        if (!result.isSuccess) safeRecycle(bitmap)
    }

    private fun startWorkerIfNeeded() {
        if (workerStarted) return
        workerStarted = true
        scope.launch {
            for (ref in frameChannel) {
                if (!running) { safeRecycle(ref.bitmap); continue }
                try { processFrame(ref.bitmap) }
                catch (t: Throwable) { Log.w("Supervisor", "frame failed", t) }
                finally { safeRecycle(ref.bitmap) }
            }
        }
    }

    private suspend fun processFrame(bitmap: Bitmap) {
        if (paused) return
        val now = System.currentTimeMillis()
        val scene = vision.detect(bitmap, now)
        latestScene.set(scene)

        val needOcr = when (state) {
            RunState.PLAYING -> now - lastOcrAt >= 900L
            RunState.RESULT, RunState.REWARD, RunState.PLAY_AGAIN -> now - lastOcrAt >= 160L
            else -> now - lastOcrAt >= 260L
        }
        if (needOcr) {
            lastOcrAt = now
            val lines = try { ocr.read(bitmap) } catch (t: Throwable) { Log.w("OCR", "failed", t); emptyList() }
            latestOcr.set(lines); latestOcrAt.set(now)
        }
        step(bitmap, scene, now)
    }

    private fun step(bitmap: Bitmap, scene: MatchScene, now: Long) {
        val obs = navigation.observe(freshOcr(now), scene)
        when (state) {
            RunState.PAUSED, RunState.IDLE, RunState.DONE, RunState.ERROR -> Unit

            RunState.PREPARE -> {
                if (queue.current() == null) transition(RunState.DONE) else transition(RunState.SELECT_BRAWLER)
            }

            RunState.SELECT_BRAWLER -> selectBrawler(bitmap, obs, now)
            RunState.VERIFY_BRAWLER -> verifyBrawler(obs, now)
            RunState.VERIFY_CUPS -> verifyCups(now)
            RunState.VERIFY_RESULT_CUPS -> verifyResultCups(obs, now)
            RunState.SELECT_MODE -> selectMode(bitmap, obs, now)
            RunState.SELECT_MAP -> selectMap(obs, now)
            RunState.PRESS_PLAY -> pressPlay(bitmap, obs, now)
            RunState.LOADING -> loading(scene, obs, now)
            RunState.PLAYING -> playing(scene, obs, now)
            RunState.RESULT -> result(obs, now)
            RunState.REWARD -> rewardStep(obs, now)
            RunState.PLAY_AGAIN -> playAgain(bitmap, obs, now)
        }

        if (state != RunState.PLAYING && state != RunState.IDLE && state != RunState.DONE && now - stateSince > stateTimeout(state)) {
            onTimeout(now)
        }
    }

    private fun selectBrawler(bitmap: Bitmap, obs: NavigationVision.Observation, now: Long) {
        val q = queue.current() ?: run { transition(RunState.DONE); return }
        val service = BotAccessibilityService.instance ?: return
        val lines = freshOcr(now)

        when (obs.type) {
            ScreenType.HOME -> {
                val target = navigation.findButton(lines, "brawlers", "бойцы", "fighters")
                if (target != null && now >= actionBusyUntil) {
                    service.tap(target)
                    actionBusyUntil = now + 850L
                    brawlerAttempts++
                    return
                }
                // Reference-authorized fallback: the tap is allowed only when the whole
                // HOME reference matches strongly. This is not a blind coordinate tap.
                if (now >= actionBusyUntil && references.score(bitmap, "home") >= .86f) {
                    if (service.tap(Point(.085f, .43f))) {
                        actionBusyUntil = now + 900L
                        brawlerAttempts++
                    }
                }
            }
            ScreenType.BRAWLER_LIST -> {
                val target = selector.find(bitmap, lines, q.brawlerId)
                if (target != null && now >= actionBusyUntil && target.confidence >= .84f) {
                    service.tap(target.point)
                    actionBusyUntil = now + 1000L
                    brawlerAttempts++
                    transition(RunState.VERIFY_BRAWLER)
                    return
                }

                if (now >= actionBusyUntil && now - stateSince > 1100L && brawlerScrolls < 30 && selector.shouldScroll(now)) {
                    val before = selector.gridFingerprint(bitmap)
                    if (lastBrawlerGridFingerprint != null) {
                        if (before == lastBrawlerGridFingerprint) unchangedGridCount++ else unchangedGridCount = 0
                        if (unchangedGridCount >= 2) brawlerScrollDirection *= -1
                    }
                    lastBrawlerGridFingerprint = before
                    val (from, to) = selector.scrollPoint(brawlerScrollDirection)
                    if (service.swipe(from, to)) {
                        selector.markScroll(now)
                        actionBusyUntil = now + 900L
                        brawlerScrolls++
                    }
                }
            }
            ScreenType.BRAWLER_PROFILE -> {
                val button = navigation.findButton(lines, "select", "выбрать", "choose")
                if (button != null && now >= actionBusyUntil) {
                    service.tap(button)
                    actionBusyUntil = now + 900L
                    transition(RunState.VERIFY_BRAWLER)
                }
            }
            else -> Unit
        }

        if (brawlerScrolls >= 30 && now - stateSince > 18_000L) {
            failSafe("Не удалось найти бойца ${BrawlerCatalog.name(q.brawlerId)} по аватарке/тексту")
        }
    }

    private fun verifyBrawler(obs: NavigationVision.Observation, now: Long) {
        val q = queue.current() ?: run { transition(RunState.DONE); return }
        val lines = freshOcr(now)
        val nameSeen = lines.any { lineContainsBrawler(it.text, q.brawlerId) }
        val accepted = when (obs.type) {
            ScreenType.BRAWLER_PROFILE -> nameSeen || obs.confidence >= .90f
            ScreenType.BRAWL_BALL_LOBBY, ScreenType.HOME -> nameSeen
            else -> false
        }
        if (accepted && now - stateSince >= 500L) {
            transition(RunState.VERIFY_CUPS)
            cupMismatchSince = 0L
        } else if (now - stateSince > 3200L && brawlerAttempts < 3) {
            transition(RunState.SELECT_BRAWLER)
        }
    }

    private fun verifyCups(now: Long) {
        val q = queue.current() ?: run { transition(RunState.DONE); return }
        val actual = trophyReader.currentBrawlerCups(freshOcr(now), q.currentCups) ?: return
        val configured = q.currentCups
        if (kotlin.math.abs(actual - configured) <= 8) {
            queue.updateCups(actual)
            matchStartCups = actual
            transition(RunState.SELECT_MODE)
            return
        }
        if (cupMismatchSince == 0L) cupMismatchSince = now
        if (now - cupMismatchSince > 2500L) {
            failSafe("Кубки не совпали: введено $configured, на экране $actual. Бот остановлен, чтобы не ошибиться.")
        }
    }

    private fun selectMode(bitmap: Bitmap, obs: NavigationVision.Observation, now: Long) {
        val service = BotAccessibilityService.instance ?: return
        val lines = freshOcr(now)
        val lobbyRef = references.score(bitmap, "brawl_ball_lobby")
        if ((obs.type == ScreenType.BRAWL_BALL_LOBBY && obs.brawlBall) || lobbyRef >= .86f) {
            transition(RunState.PRESS_PLAY)
            return
        }
        if (obs.type == ScreenType.HOME) {
            val current = navigation.findCurrentMode(lines)
            if (current != null && now >= actionBusyUntil) {
                if (service.tap(current)) { actionBusyUntil = now + 1200L }
                return
            }
            if (now >= actionBusyUntil && references.score(bitmap, "home") >= .86f) {
                // In the supplied HOME reference this point is the current-mode card.
                if (service.tap(Point(.60f, .91f))) actionBusyUntil = now + 1200L
            }
            return
        }
        if (obs.type != ScreenType.MODE_SELECT) return
        val ball = navigation.findBrawlBall(lines)
        if (ball != null && now >= actionBusyUntil) {
            if (service.tap(ball)) {
                actionBusyUntil = now + 1200L
                transition(RunState.SELECT_MAP)
            }
        } else if (now >= actionBusyUntil && references.score(bitmap, "mode_select") >= .86f) {
            if (service.tap(Point(.375f, .35f))) {
                actionBusyUntil = now + 1200L
                transition(RunState.SELECT_MAP)
            }
        }
    }

    private fun selectMap(obs: NavigationVision.Observation, now: Long) {
        if (obs.type == ScreenType.BRAWL_BALL_LOBBY && obs.brawlBall) transition(RunState.PRESS_PLAY)
    }

    private fun pressPlay(bitmap: Bitmap, obs: NavigationVision.Observation, now: Long) {
        val service = BotAccessibilityService.instance ?: return
        val lobbyRef = references.score(bitmap, "brawl_ball_lobby")
        if ((obs.type != ScreenType.BRAWL_BALL_LOBBY || !obs.brawlBall) && lobbyRef < .86f) return
        val p = obs.play ?: navigation.findButton(freshOcr(now), "play", "играть", "ready", "готов")
        val visualPlay = p ?: UiButtonVision.findYellowAction(bitmap)
        if (visualPlay != null && now >= actionBusyUntil) {
            if (service.tap(visualPlay)) {
                actionBusyUntil = now + 1500L
                matchStartCups = queue.current()?.currentCups
                matchStartedAt = now
                matchResultRecorded = false
                pendingDelta = null; deltaConfirmations = 0
                loadingEvidence = 0; lastLoadingEvidenceAt = 0L
                transition(RunState.LOADING)
            }
        }
    }

    private fun loading(scene: MatchScene, obs: NavigationVision.Observation, now: Long) {
        val evidence = obs.type == ScreenType.MATCH && scene.leftJoystick != null && scene.rightJoystick != null && scene.hudConfidence >= .42f && scene.player != null
        if (evidence) {
            if (now - lastLoadingEvidenceAt >= 180L) loadingEvidence++
            lastLoadingEvidenceAt = now
        }
        if (loadingEvidence >= 3) {
            matchStartedAt = now
            resultSince = 0L
            transition(RunState.PLAYING)
        }
    }

    private fun playing(scene: MatchScene, obs: NavigationVision.Observation, now: Long) {
        if (obs.type == ScreenType.RESULT || obs.type == ScreenType.REWARD) {
            transition(if (obs.type == ScreenType.REWARD) RunState.REWARD else RunState.RESULT)
            resultSince = now
            return
        }
        if (obs.type != ScreenType.MATCH) return

        val player = scene.player
        if (player == null) {
            // A player can disappear for a few frames because of effects/respawn.
            // Do not interpret that as match end.
            if (now - resultSince > 900L) resultSince = now
            return
        }
        resultSince = 0L
        val elapsed = now - matchStartedAt
        val frame = controller.next(scene, now, elapsed)
        if (now >= actionBusyUntil && scene.hudConfidence >= .42f) {
            val left = scene.leftJoystick ?: Point(.20f, .78f)
            val right = scene.rightJoystick ?: Point(.80f, .78f)
            if (BotAccessibilityService.instance?.dispatch(frame, left, right, 80L) == true) {
                actionBusyUntil = now + 70L
            }
        }
    }

    private fun result(obs: NavigationVision.Observation, now: Long) {
        if (obs.type != ScreenType.RESULT && obs.type != ScreenType.REWARD) return
        val lines = freshOcr(now)
        val delta = trophyReader.resultDelta(lines)
        if (delta != null) {
            if (pendingDelta == delta) deltaConfirmations++ else { pendingDelta = delta; deltaConfirmations = 1 }
            if (deltaConfirmations >= 3 && !matchResultRecorded) {
                applyConfirmedDelta(delta)
                matchResultRecorded = true
                lastOutcome = ResultReader.read(lines) ?: when {
                    delta > 0 -> MatchOutcome.WIN
                    delta < 0 -> MatchOutcome.LOSS
                    else -> MatchOutcome.DRAW
                }
                StatsStore.recordMatch(delta, lastOutcome!!)
            }
        }
        if (obs.type == ScreenType.REWARD) {
            if (matchResultRecorded) { transition(RunState.REWARD); rewardSince = now }
            return
        }
        if (matchResultRecorded && now - resultSince > 900L) transition(RunState.PLAY_AGAIN)
    }

    private fun rewardStep(obs: NavigationVision.Observation, now: Long) {
        val service = BotAccessibilityService.instance
        if (service != null && obs.rewardAction != null && now >= actionBusyUntil) {
            service.tap(obs.rewardAction.second); actionBusyUntil = now + 700L; rewardSince = now; return
        }
        if (now - rewardSince > 1200L) transition(RunState.PLAY_AGAIN)
    }

    private fun playAgain(bitmap: Bitmap, obs: NavigationVision.Observation, now: Long) {
        val service = BotAccessibilityService.instance ?: return
        val q = queue.current() ?: run { transition(RunState.DONE); return }
        if (!matchResultRecorded) return
        if (q.reached) {
            val proceed = obs.proceed ?: navigation.findButton(freshOcr(now), "proceed", "continue", "продолжить", "exit", "выйти")
            if (proceed != null && now >= actionBusyUntil && service.tap(proceed)) {
                actionBusyUntil = now + 1100L
                advanceAfterCupVerification = true
                transition(RunState.VERIFY_RESULT_CUPS)
            }
            return
        }
        val again = obs.playAgain ?: navigation.findButton(freshOcr(now), "play again", "играть снова", "ещё раз")
        val visualAgain = again ?: UiButtonVision.findYellowAction(bitmap)
        if (visualAgain != null && now >= actionBusyUntil && service.tap(visualAgain)) {
            actionBusyUntil = now + 1400L
            matchStartCups = q.currentCups
            matchStartedAt = now
            matchResultRecorded = false
            pendingDelta = null; deltaConfirmations = 0
            loadingEvidence = 0; lastLoadingEvidenceAt = 0L
            transition(RunState.LOADING)
        }
    }

    private fun verifyResultCups(obs: NavigationVision.Observation, now: Long) {
        val q = queue.current() ?: run { transition(RunState.DONE); return }
        val actual = trophyReader.currentBrawlerCups(freshOcr(now), q.currentCups) ?: return
        if (actual != q.currentCups) {
            if (now - stateSince > 3500L) failSafe("После результата кубки не подтверждены: ожидалось ${q.currentCups}, экран показывает $actual")
            return
        }
        if (advanceAfterCupVerification) {
            advanceAfterCupVerification = false
            if (queue.next()) { resetForNextBrawler(); transition(RunState.SELECT_BRAWLER) }
            else transition(RunState.DONE)
        } else transition(RunState.PLAY_AGAIN)
    }

    private fun applyConfirmedDelta(delta: Int) {
        val q = queue.current() ?: return
        val before = q.currentCups
        val after = before + delta
        if (after in 0..10000 && kotlin.math.abs(delta) <= 100) queue.updateCups(after)
    }

    private fun resetForNextBrawler() {
        brawlerAttempts = 0; brawlerScrolls = 0; brawlerScrollDirection = 1; unchangedGridCount = 0
        lastBrawlerGridFingerprint = null; cupMismatchSince = 0L
        matchStartCups = null; pendingDelta = null; deltaConfirmations = 0
        loadingEvidence = 0; lastLoadingEvidenceAt = 0L
        matchResultRecorded = false; resultSince = 0L; rewardSince = 0L; advanceAfterCupVerification = false; reward.reset()
    }

    private fun onTimeout(now: Long) {
        when (state) {
            RunState.SELECT_BRAWLER -> failSafe("Не удалось подтвердить выбор бойца")
            RunState.VERIFY_BRAWLER -> if (brawlerAttempts < 3) transition(RunState.SELECT_BRAWLER) else failSafe("Не подтверждён выбранный боец")
            RunState.VERIFY_CUPS -> failSafe("Не удалось надёжно прочитать кубки")
            RunState.SELECT_MODE, RunState.SELECT_MAP, RunState.PRESS_PLAY -> failSafe("Не удалось подтвердить Brawl Ball / PLAY")
            RunState.LOADING -> failSafe("Матч не перешёл в игровой экран")
            RunState.PLAYING -> failSafe("Игровой экран пропал без подтверждённого результата")
            RunState.RESULT, RunState.REWARD, RunState.VERIFY_RESULT_CUPS, RunState.PLAY_AGAIN -> failSafe("Результат матча не подтверждён")
            else -> Unit
        }
    }

    private fun transition(next: RunState) {
        state = next; stateSince = System.currentTimeMillis()
        Log.i("Supervisor", "state=$next")
    }

    private fun failSafe(reason: String) {
        Log.e("Supervisor", reason)
        running = false; paused = false; state = RunState.ERROR
        StatsStore.endRun()
    }

    fun status(): String {
        val q = queue.current(); val s = latestScene.get()
        val p = s?.player?.point?.let { "P=${(it.x*100).toInt()}%,${(it.y*100).toInt()}%" } ?: "P=--"
        val b = s?.ball?.point?.let { "B=${(it.x*100).toInt()}%,${(it.y*100).toInt()}%" } ?: "B=--"
        return "v30.2 | $state | ${q?.brawlerId ?: "-"} ${q?.currentCups ?: 0}/${q?.targetCups ?: 0} | $p $b"
    }

    private fun freshOcr(now: Long): List<OcrLine> = if (now - latestOcrAt.get() <= 2200L) latestOcr.get() else emptyList()
    private fun lineContainsBrawler(text: String, id: String): Boolean {
        val v = text.lowercase().replace('ё','е').replace(Regex("[^a-zа-я0-9]"), "")
        return BrawlerCatalog.aliases(id).any { a -> val n=a.lowercase().replace('ё','е').replace(Regex("[^a-zа-я0-9]"), ""); n.length >= 3 && (v.contains(n) || n.contains(v) && v.length >= 4) }
    }
    private fun stateTimeout(s: RunState) = when (s) {
        RunState.SELECT_BRAWLER -> 30_000L; RunState.VERIFY_BRAWLER -> 4_000L; RunState.VERIFY_CUPS -> 4_000L
        RunState.SELECT_MODE, RunState.SELECT_MAP, RunState.PRESS_PLAY -> 8_000L; RunState.LOADING -> 12_000L
        RunState.PLAYING -> 180_000L; RunState.RESULT -> 8_000L; RunState.REWARD -> 7_000L; RunState.VERIFY_RESULT_CUPS -> 5_000L; RunState.PLAY_AGAIN -> 7_000L
        else -> 30_000L
    }
    private fun drainFrames() { while (true) { val x = frameChannel.tryReceive().getOrNull() ?: break; safeRecycle(x.bitmap) } }
    private fun safeRecycle(b: Bitmap) { try { if (!b.isRecycled) b.recycle() } catch (_: Throwable) {} }
    override fun close() {
        running = false; paused = false; StatsStore.endRun()
        frameChannel.close(); scope.cancel(); vision.close(); ocr.close()
    }
}
