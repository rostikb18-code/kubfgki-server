#!/usr/bin/env python3
"""Deterministic source/assets preflight for RostikAI.

This intentionally checks only facts that can be verified without an Android
runtime. GitHub Actions remains the authoritative Android compile/build check.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / "app/src/main/java/com/rostik/touchbot"
ASSETS = ROOT / "app/src/main/assets"


def fail(msg: str) -> None:
    raise SystemExit(f"VERIFY_SOURCE_ERROR: {msg}")


def require_file(path: Path) -> None:
    if not path.is_file():
        fail(f"missing file: {path.relative_to(ROOT)}")


def main() -> None:
    for rel in (
        "settings.gradle.kts",
        "build.gradle.kts",
        "app/build.gradle.kts",
        "app/src/main/AndroidManifest.xml",
        "ROSTIK_SOURCE_ID.txt",
    ):
        require_file(ROOT / rel)

    source_id = (ROOT / "ROSTIK_SOURCE_ID.txt").read_text(encoding="utf-8").strip()
    if source_id != "ROSTIKAI-31.1.3-COMPILE-FIX-2":
        fail(f"unexpected source identity: {source_id!r}")

    gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
    for needle in ('versionCode = 54', 'versionName = "31.1.3"', 'buildConfig = true'):
        if needle not in gradle:
            fail(f"missing Gradle setting: {needle}")

    manifest = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
    for needle in (
        '.MainActivity',
        '.BotAccessibilityService',
        '.ScreenCaptureService',
        '.OverlayService',
        'FOREGROUND_SERVICE_MEDIA_PROJECTION',
        'FOREGROUND_SERVICE_SPECIAL_USE',
    ):
        if needle not in manifest:
            fail(f"manifest missing: {needle}")

    kt = sorted(JAVA.glob("*.kt"))
    if len(kt) < 28:
        fail(f"only {len(kt)} Kotlin source files found")

    forbidden = re.compile(r"TODO|FIXME|NotImplementedException|UnsupportedOperationException")
    for path in kt:
        text = path.read_text(encoding="utf-8")
        if forbidden.search(text):
            fail(f"unfinished marker in {path.name}")
        if "ball.confidence" in text and path.name == "MatchSupervisor.kt":
            fail("known invalid ball.confidence reference remains")
        if 'mapOf("confidence" to "${target.confidence}")' in text or 'tap=brawlers.*target.confidence' in text:
            fail("known invalid target.confidence logging reference remains")

    icons = sorted((ASSETS / "brawler_icons").glob("*.png"))
    if len(icons) != 108:
        fail(f"expected 108 brawler icons, found {len(icons)}")
    for p in icons:
        if p.read_bytes()[:8] != b"\x89PNG\r\n\x1a\n":
            fail(f"invalid PNG header: {p.relative_to(ROOT)}")

    manifest_ids = [
        x.strip() for x in (ASSETS / "brawler_icons_manifest.txt").read_text(encoding="utf-8").splitlines()
        if x.strip()
    ]
    if len(manifest_ids) != 108 or len(set(manifest_ids)) != 108:
        fail("brawler icon manifest must contain 108 unique IDs")
    missing = [x for x in manifest_ids if not (ASSETS / "brawler_icons" / f"{x}.png").is_file()]
    if missing:
        fail(f"missing icon files: {missing[:8]}")

    catalog = (JAVA / "BrawlerCatalog.kt").read_text(encoding="utf-8")
    ids = re.findall(r'e\("([^"]+)"', catalog)
    if len(ids) != 108 or len(set(ids)) != 108:
        fail(f"BrawlerCatalog must contain 108 unique IDs; found {len(ids)}")

    rows = {}
    for raw in (ASSETS / "brawler_avatar_map.properties").read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        k, v = line.split("=", 1)
        rows[k] = v
    if len(rows) != 108 or set(rows) != set(ids):
        fail("avatar map does not exactly match BrawlerCatalog")

    maps = json.loads((ASSETS / "apk_port/maps/brawl_ball_maps.json").read_text(encoding="utf-8"))
    if len(maps) < 80:
        fail(f"too few Brawl Ball maps: {len(maps)}")
    for name, rows_ in maps.items():
        if len(rows_) != 33 or any(not isinstance(row, str) or len(row) != 21 for row in rows_):
            fail(f"invalid map grid: {name}")

    if re.search(r"discord(app)?\.com/api/webhooks/[0-9]+/[A-Za-z0-9_-]+", "\n".join(p.read_text(errors="ignore") for p in ROOT.rglob("*") if p.is_file() and p.stat().st_size < 2_000_000)):
        fail("raw Discord webhook token found in repository")

    print("SOURCE_PREFLIGHT_PASS")
    print(f"kotlin={len(kt)} brawler_icons={len(icons)} catalog={len(ids)} maps={len(maps)}")


if __name__ == "__main__":
    main()
