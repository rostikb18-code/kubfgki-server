package com.rostik.touchbot

/** Reads explicit match-result words when the result screen OCR exposes them. */
object ResultReader {
    private val winWords = listOf("победа", "победили", "victory", "win", "won")
    private val lossWords = listOf("поражение", "поражени", "defeat", "loss", "lost")

    fun read(lines: List<OcrLine>): MatchOutcome? {
        val text = lines.joinToString(" ") { it.text.lowercase().replace('ё', 'е') }
        return when {
            winWords.any(text::contains) -> MatchOutcome.WIN
            lossWords.any(text::contains) -> MatchOutcome.LOSS
            else -> null
        }
    }
}
