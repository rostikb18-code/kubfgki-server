package com.rostik.touchbot

import android.content.res.AssetManager
import org.json.JSONObject

/**
 * Map catalog imported from the supplied APK. It is used for recognition and
 * future map-aware planning; the current flow still lets Brawl Stars choose
 * the active rotation rather than blindly tapping a fixed map coordinate.
 */
object BrawlBallMapCatalog {
    data class MapDef(val name: String, val rows: List<String>)

    @Volatile private var cached: List<MapDef>? = null

    fun all(assets: AssetManager): List<MapDef> {
        cached?.let { return it }
        val loaded = try {
            val raw = assets.open("apk_port/maps/brawl_ball_maps.json").bufferedReader().use { it.readText() }
            val obj = JSONObject(raw)
            buildList {
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val name = keys.next()
                    val arr = obj.optJSONArray(name) ?: continue
                    val rows = buildList { for (i in 0 until arr.length()) add(arr.optString(i)) }
                    if (rows.isNotEmpty()) add(MapDef(name, rows))
                }
            }.sortedBy { it.name.lowercase() }
        } catch (_: Throwable) { emptyList() }
        cached = loaded
        return loaded
    }

    fun findByOcr(assets: AssetManager, lines: List<OcrLine>): MapDef? {
        val text = lines.joinToString(" ") { normalize(it.text) }
        return all(assets).maxByOrNull { map ->
            val n = normalize(map.name)
            if (n.isNotEmpty() && text.contains(n)) n.length.toFloat() else 0f
        }?.takeIf { normalize(it.name).isNotEmpty() && text.contains(normalize(it.name)) }
    }

    private fun normalize(s: String) = s.lowercase()
        .replace('ё', 'е')
        .replace(Regex("[^a-zа-я0-9]"), "")
}
