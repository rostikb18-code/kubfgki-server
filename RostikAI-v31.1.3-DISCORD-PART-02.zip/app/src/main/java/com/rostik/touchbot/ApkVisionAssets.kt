package com.rostik.touchbot

import android.content.res.AssetManager

/** Non-invasive registry for visual assets ported from the supplied APK. */
object ApkVisionAssets {
    const val MAPS = "apk_port/maps/brawl_ball_maps.json"
    const val ICON_DIR = "apk_port/brawler_icons"
    const val OBJECT_DIR = "apk_port/ui_objects"
    const val STATE_DIR = "apk_port/states"
    const val LOBBY_DIR = "apk_port/lobby"

    fun exists(assets: AssetManager, path: String): Boolean = try {
        assets.open(path).use { true }
    } catch (_: Throwable) { false }

    fun brawlerIconCandidates(id: String): List<String> = listOf(
        "$ICON_DIR/$id.png", "$ICON_DIR/$id.webp", "$ICON_DIR/Brawl_${id}.png",
        "$ICON_DIR/Brawl_${id}.webp"
    )
}
