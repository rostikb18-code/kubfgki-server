package com.rostik.touchbot

/** Current brawler catalog used by both the overlay and the visual/OCR selector.
 * English aliases are kept because the supplied game references use English UI text.
 */
object BrawlerCatalog {
    data class Entry(val id: String, val name: String, val aliases: List<String> = emptyList())

    private fun e(id: String, name: String, vararg aliases: String) = Entry(id, name, aliases.toList())

    val all = listOf(
        e("8_bit", "8-БИТ", "8-bit", "8 bit"),
        e("alli", "АЛЛИ", "Alli"), e("amber", "АМБЕР", "Amber"),
        e("angelo", "АНГЕЛО", "Angelo"), e("ash", "АШ", "Ash"),
        e("barley", "БАРЛИ", "Barley"), e("bea", "БЕА", "Bea"),
        e("belle", "БЕЛЛЬ", "Belle"), e("berry", "БЕРРИ", "Berry"),
        e("bibi", "БИБИ", "Bibi"), e("bo", "БО", "Bo"),
        e("bolt", "БОЛТ", "Bolt"), e("bonnie", "БОННИ", "Bonnie"),
        e("brock", "БРОК", "Brock"), e("bull", "БУЛЛ", "Bull"),
        e("buster", "БАСТЕР", "Buster"), e("buzz", "БАЗЗ", "Buzz"),
        e("byron", "БАЙРОН", "Byron"), e("carl", "КАРЛ", "Carl"),
        e("charlie", "ЧАРЛИ", "Charlie"), e("chester", "ЧЕСТЕР", "Chester"),
        e("chuck", "ЧАК", "Chuck"), e("clancy", "КЛЭНСИ", "Clancy"),
        e("colette", "КОЛЕТТ", "Colette"), e("colt", "КОЛЬТ", "Colt"),
        e("cordelius", "КОРДЕЛИУС", "Cordelius"), e("cosmo", "КОСМО", "Cosmo"),
        e("crow", "ВОРОН", "Crow"), e("damian", "ДЭМИАН", "Damian"),
        e("darryl", "ДЭРРИЛ", "Darryl"), e("doug", "ДАГ", "Doug"),
        e("draco", "ДРАКО", "Draco"), e("dynamike", "ДИНАМАЙК", "Dynamike"),
        e("edgar", "ЭДГАР", "Edgar"), e("el_primo", "ЭЛЬ ПРИМО", "El Primo", "ElPrimo"),
        e("emz", "ЭМЗ", "Emz"), e("eve", "ИВ", "Eve"),
        e("fang", "ФЭНГ", "Fang"), e("finx", "ФИНКС", "Finx"),
        e("frank", "ФРЭНК", "Frank"), e("gale", "ГЭЙЛ", "Gale"),
        e("gene", "ДЖИН", "Gene"), e("gigi", "ДЖИ-ДЖИ", "Gigi"),
        e("glowy", "ГЛОУИ", "Glowy"), e("gray", "ГРЭЙ", "Gray"),
        e("griff", "ГРИФФ", "Griff"), e("grom", "ГРОМ", "Grom"),
        e("gus", "ГАСС", "Gus"), e("hank", "ХЭНК", "Hank"),
        e("jacky", "ДЖЕКИ", "Jacky"), e("jae_yong", "ДЖЕ-ЙОНГ", "Jae-Yong", "Jae Yong"),
        e("janet", "ДЖАНЕТ", "Janet"), e("jessie", "ДЖЕССИ", "Jessie"),
        e("juju", "ДЖУДЖУ", "Juju"), e("kaze", "КАЗЕ", "Kaze"),
        e("kenji", "КЕНДЗИ", "Kenji"), e("kit", "КИТ", "Kit"),
        e("larry_lawrie", "ЛАРРИ И ЛОУРИ", "Larry & Lawrie", "Larry Lawrie"),
        e("leon", "ЛЕОН", "Leon"), e("lily", "ЛИЛИ", "Lily"),
        e("lola", "ЛОЛА", "Lola"), e("lou", "ЛУ", "Lou"),
        e("lumi", "ЛЮМИ", "Lumi"), e("maisie", "МЭЙСИ", "Maisie"),
        e("mandy", "МЭНДИ", "Mandy"), e("max", "МАКС", "Max"),
        e("meeple", "МИПЛ", "Meeple"), e("meg", "МЕГ", "Meg"),
        e("melodie", "МЕЛОДИ", "Melodie"), e("mico", "МИКО", "Mico"),
        e("mina", "МИНА", "Mina"), e("moe", "МО", "Moe"),
        e("mortis", "МОРТИС", "Mortis"), e("mr_p", "МИСТЕР П", "Mr. P", "Mr P"),
        e("nani", "НАНИ", "Nani"), e("najia", "НАДЖИЯ", "Najia"),
        e("nita", "НИТА", "Nita"), e("nori", "НОРИ", "Nori"),
        e("ollie", "ОЛЛИ", "Ollie"), e("otis", "ОТИС", "Otis"),
        e("pam", "ПЭМ", "Pam"), e("pearl", "ПЕРЛ", "Pearl"),
        e("penny", "ПЕННИ", "Penny"), e("pierce", "ПИРС", "Pierce"),
        e("piper", "ПАЙПЕР", "Piper"), e("poco", "ПОКО", "Poco"),
        e("rico", "РИКО", "Rico"), e("rosa", "РОЗА", "Rosa"),
        e("rt", "Р-Т", "R-T", "RT"), e("ruffs", "РАФФС", "Ruffs"),
        e("sam", "СЭМ", "Sam"), e("sandy", "СЭНДИ", "Sandy"),
        e("shade", "ШЕЙД", "Shade"), e("shelly", "ШЕЛЛИ", "Shelly"),
        e("sirius", "СИРИУС", "Sirius"), e("spike", "СПАЙК", "Spike"),
        e("sprout", "СПРАУТ", "Sprout"), e("squeak", "СКВИК", "Squeak"),
        e("starr_nova", "СТАРР НОВА", "Starr Nova", "StarrNova"), e("stu", "СТУ", "Stu"),
        e("surge", "СЁРДЖ", "Surge"), e("tara", "ТАРА", "Tara"),
        e("tick", "ТИК", "Tick"), e("trunk", "ТРАНК", "Trunk"),
        e("vince", "ВИНС", "Vince"), e("wendy", "ВЕНДИ", "Wendy"),
        e("willow", "УИЛЛОУ", "Willow"), e("ziggy", "ЗИГГИ", "Ziggy")
    )

    private val byId = all.associateBy { it.id }

    fun get(id: String): Entry? = byId[id]
    fun name(id: String): String = byId[id]?.name ?: id
    fun aliases(id: String): List<String> = byId[id]?.let { listOf(it.name) + it.aliases } ?: listOf(id)
}
