package com.rostik.touchbot

import android.util.Log

/**
 * Safe reward/popup state machine.
 * It never taps a generic screen center. Every tap is tied to OCR aliases
 * and/or a strongly constrained button geometry.
 */
class RewardHandler {
    private var actionCount = 0
    private var lastTapAt = 0L
    private var stableAction = ""
    private var stableCount = 0

    private val aliases = mapOf(
        "OPEN" to listOf("open","открыть","открыть!","открыть"),
        "CLAIM" to listOf("claim","забрать","получить"),
        "CONTINUE" to listOf("continue","продолжить","далее","дальше"),
        "HOME" to listOf("home","главная","выйти"),
        "CLOSE" to listOf("close","закрыть"),
        "SKIP" to listOf("skip","пропустить")
    )

    fun reset(){ actionCount=0; stableAction=""; stableCount=0; lastTapAt=0L }

    fun next(lines:List<OcrLine>, now:Long): Pair<String,Point>? {
        if(actionCount>=8) return null
        if(now-lastTapAt<450L) return null

        val candidates=lines.mapNotNull { line ->
            val normalized=line.text.lowercase().replace("ё","е").trim()
            aliases.entries.firstNotNullOfOrNull { (action, words) ->
                if(words.any{normalized.contains(it)}) action to line.rect.center() else null
            }?.let { it.first to it.second }
        }.filter { (_,p) -> p.y>.48f && p.y<.96f }

        val best=candidates.maxByOrNull { (_,p) -> if(p.x in .20f.. .85f) 1f else .5f } ?: return null
        if(best.first==stableAction) stableCount++ else { stableAction=best.first; stableCount=1 }
        if(stableCount<2) return null

        actionCount++
        lastTapAt=now
        Log.i("RewardHandler","confirmed action=${best.first} point=${best.second}")
        return best
    }

    fun exhausted()=actionCount>=8
}
