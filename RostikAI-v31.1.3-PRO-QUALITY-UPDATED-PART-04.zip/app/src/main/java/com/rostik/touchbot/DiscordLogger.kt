package com.rostik.touchbot

import com.rostik.touchbot.BuildConfig
import android.content.Context
import android.os.Build
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Reliable one-way Discord diagnostics.
 *
 * Events are written to a small local outbox first and sent in batches. This is
 * important for RostikAI because the app can generate several state/action logs
 * close together and Discord rate-limits webhook traffic. The logger never
 * stores the webhook in source code and never includes the full URL in logs.
 */
object DiscordLogger {
    enum class Category(val label: String, val color: Int) {
        BUILD("BUILD", 0x3498DB),
        CRASH("CRASH", 0xE74C3C),
        ERROR("ERROR", 0xE67E22),
        VISION("VISION", 0x9B59B6),
        BOT("BOT", 0x2ECC71),
        UI("UI", 0x1ABC9C),
        SCREEN("SCREEN", 0xF1C40F),
        GESTURE("GESTURE", 0x95A5A6),
        MATCH("MATCH", 0x3498DB),
        INFO("INFO", 0x7289DA)
    }

    private const val PREFS = "discord_logger"
    private const val WEBHOOK = "webhook_url"
    private const val ENABLED = "enabled"
    private const val PENDING_CRASH = "pending_crash"
    private const val TAG = "DiscordLogger"
    private const val MAX_MESSAGE = 5900
    private const val MAX_EMBEDS_PER_POST = 8
    private const val FLUSH_INTERVAL_MS = 2300L
    private const val MAX_OUTBOX_BYTES = 1_500_000L

    private val executor = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "RostikDiscordLogger").apply { isDaemon = true }
    }
    private val fileLock = Any()
    @Volatile private var app: Context? = null
    @Volatile private var configuredUrl: String? = null
    @Volatile private var schedulerStarted = false
    @Volatile private var lastPostAt = 0L

    fun init(context: Context) {
        app = context.applicationContext
        configuredUrl = prefs()?.getString(WEBHOOK, null)?.trim()?.takeIf { it.isNotEmpty() }
        startScheduler()
        sendPendingCrash()
    }

    fun configure(context: Context, webhookUrl: String?, enabled: Boolean = true) {
        val c = context.applicationContext
        app = c
        val normalized = webhookUrl?.trim().orEmpty()
        val valid = isDiscordWebhook(normalized)
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(WEBHOOK, if (valid) normalized else "")
            .putBoolean(ENABLED, enabled && valid)
            .apply()
        configuredUrl = if (valid && enabled) normalized else null
        startScheduler()
        if (valid && enabled) flushNow()
    }

    fun clearConfiguration(context: Context) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
        configuredUrl = null
    }

    fun isConfigured(context: Context): Boolean {
        val p = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return p.getBoolean(ENABLED, false) && isDiscordWebhook(p.getString(WEBHOOK, "").orEmpty())
    }

    fun maskedWebhook(context: Context): String {
        val url = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(WEBHOOK, "").orEmpty()
        if (!isDiscordWebhook(url)) return "не настроен"
        val token = url.substringAfterLast('/', "")
        return if (token.length >= 10) "...${token.takeLast(6)}" else "настроен"
    }

    fun test(context: Context) {
        initIfNeeded(context)
        log(Category.BUILD, "Discord Logger подключён", "Тестовая отправка из RostikAI.")
        flushNow()
    }

    fun info(category: Category = Category.INFO, title: String, message: String, fields: Map<String, String> = emptyMap()) =
        log(category, title, message, fields)

    fun error(category: Category = Category.ERROR, title: String, throwable: Throwable? = null, message: String = "", fields: Map<String, String> = emptyMap()) {
        val detail = buildString {
            if (message.isNotBlank()) append(message.trim())
            if (throwable != null) {
                if (isNotEmpty()) append("\n\n")
                append(throwable.stackTraceToString().take(4000))
            }
        }
        log(category, title, detail.ifBlank { "Неизвестная ошибка" }, fields)
    }

    fun crash(context: Context, thread: Thread, throwable: Throwable) {
        initIfNeeded(context)
        val text = buildString {
            append("thread=").append(thread.name).append('\n')
            append(throwable.stackTraceToString().take(4500))
        }
        val c = context.applicationContext
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(PENDING_CRASH, text)
            .apply()
        // The process may die immediately after the uncaught-exception handler,
        // so persist first and make one best-effort immediate delivery.
        log(Category.CRASH, "Необработанный crash", text, mapOf(
            "thread" to thread.name,
            "app" to BuildConfig.VERSION_NAME,
            "android" to Build.VERSION.RELEASE
        ))
        flushNow()
    }

    fun sendPendingCrash() {
        val c = app ?: return
        val p = prefs() ?: return
        val pending = p.getString(PENDING_CRASH, null)?.takeIf { it.isNotBlank() } ?: return
        val url = activeUrl() ?: return
        if (!isDiscordWebhook(url)) return
        val payload = payload(c, Category.CRASH, "Crash из предыдущего запуска", pending, emptyMap())
        enqueuePayload(payload)
        flushNow()
        p.edit().remove(PENDING_CRASH).apply()
    }

    fun buildState(context: Context, state: String, message: String, fields: Map<String, String> = emptyMap()) {
        initIfNeeded(context)
        log(Category.BUILD, "Build $state", message, fields)
    }

    private fun initIfNeeded(context: Context) {
        if (app == null) init(context)
    }

    private fun log(category: Category, title: String, message: String, fields: Map<String, String> = emptyMap()) {
        val c = app ?: return
        if (!isEnabled()) return
        val payload = payload(c, category, title, message, fields)
        enqueuePayload(payload)
    }

    private fun enqueuePayload(payload: String) {
        val c = app ?: return
        startScheduler()
        try {
            synchronized(fileLock) {
                val f = outboxFile(c)
                f.parentFile?.mkdirs()
                if (f.exists() && f.length() > MAX_OUTBOX_BYTES) {
                    val lines = f.readLines(Charsets.UTF_8).takeLast(500)
                    f.writeText(lines.joinToString("\n", postfix = if (lines.isNotEmpty()) "\n" else ""), Charsets.UTF_8)
                }
                f.appendText(payload.replace('\n', ' ') + "\n", Charsets.UTF_8)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Cannot persist Discord event: ${t.message}")
        }
    }

    private fun startScheduler() {
        if (schedulerStarted) return
        synchronized(this) {
            if (schedulerStarted) return
            schedulerStarted = true
            executor.scheduleWithFixedDelay({ flushBatch() }, 500L, FLUSH_INTERVAL_MS, TimeUnit.MILLISECONDS)
        }
    }

    private fun flushNow() {
        startScheduler()
        executor.execute { flushBatch() }
    }

    /** Sends at most 8 embeds per request, keeping us below Discord's webhook limits. */
    private fun flushBatch() {
        val c = app ?: return
        val url = activeUrl() ?: return
        if (!isEnabled() || !isDiscordWebhook(url)) return
        val now = System.currentTimeMillis()
        if (now - lastPostAt < FLUSH_INTERVAL_MS) return

        synchronized(fileLock) {
            val f = outboxFile(c)
            if (!f.exists() || f.length() == 0L) return
            val lines = try { f.readLines(Charsets.UTF_8).filter { it.isNotBlank() } } catch (_: Throwable) { return }
            if (lines.isEmpty()) return
            val batch = lines.take(MAX_EMBEDS_PER_POST)
            val rest = lines.drop(batch.size)
            val embeds = JSONArray()
            batch.forEach { line ->
                try {
                    val root = JSONObject(line)
                    val arr = root.optJSONArray("embeds") ?: return@forEach
                    for (i in 0 until arr.length()) embeds.put(arr.getJSONObject(i))
                } catch (_: Throwable) {}
            }
            if (embeds.length() == 0) {
                f.writeText(rest.joinToString("\n", postfix = if (rest.isNotEmpty()) "\n" else ""), Charsets.UTF_8)
                return
            }
            val payload = JSONObject()
                .put("username", "RostikAI Logger")
                .put("allowed_mentions", JSONObject().put("parse", JSONArray()))
                .put("embeds", embeds)
                .toString()
            try {
                post(url, payload)
                lastPostAt = System.currentTimeMillis()
                f.writeText(rest.joinToString("\n", postfix = if (rest.isNotEmpty()) "\n" else ""), Charsets.UTF_8)
            } catch (t: Throwable) {
                Log.w(TAG, "Discord webhook failed; event remains in outbox: ${t.message}")
            }
        }
    }

    private fun activeUrl(): String? {
        val p = prefs() ?: return null
        return configuredUrl ?: p.getString(WEBHOOK, null)?.trim().orEmpty().takeIf { it.isNotEmpty() }
    }

    private fun isEnabled(): Boolean = prefs()?.getBoolean(ENABLED, false) == true

    private fun post(webhookUrl: String, payload: String) {
        val connection = (URL(webhookUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 5000
            readTimeout = 7000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("User-Agent", "RostikAI/${BuildConfig.VERSION_NAME}")
        }
        try {
            connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
        } finally {
            connection.disconnect()
        }
    }

    private fun payload(context: Context, category: Category, title: String, message: String, fields: Map<String, String>): String {
        val embed = JSONObject()
            .put("title", "[${category.label}] ${title.take(230)}")
            .put("description", message.take(MAX_MESSAGE))
            .put("color", category.color)
            .put("timestamp", java.time.Instant.now().toString())
            .put("footer", JSONObject().put("text", "RostikAI ${BuildConfig.VERSION_NAME}"))

        val merged = LinkedHashMap<String, String>()
        merged["device"] = "${Build.MANUFACTURER} ${Build.MODEL}"
        merged["android"] = Build.VERSION.RELEASE
        merged["sdk"] = Build.VERSION.SDK_INT.toString()
        fields.forEach { (k, v) -> merged[k] = v }
        val array = JSONArray()
        merged.entries.take(25).forEach { (k, v) ->
            array.put(JSONObject().put("name", k.take(256)).put("value", v.take(1024)).put("inline", true))
        }
        embed.put("fields", array)

        return JSONObject()
            .put("username", "RostikAI Logger")
            .put("allowed_mentions", JSONObject().put("parse", JSONArray()))
            .put("embeds", JSONArray().put(embed))
            .toString()
    }

    private fun outboxFile(context: Context): File = File(context.filesDir, "discord_logger/outbox.ndjson")
    private fun prefs() = app?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun isDiscordWebhook(url: String): Boolean =
        url.startsWith("https://discord.com/api/webhooks/") ||
            url.startsWith("https://discordapp.com/api/webhooks/")
}
