package com.rostik.touchbot

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.max

/** Lightweight visual fallback for the large yellow action buttons used by the supplied UI. */
object UiButtonVision {
    fun findYellowAction(bitmap: Bitmap): Point? {
        val w = 160
        val h = max(74, bitmap.height * w / bitmap.width)
        val small = Bitmap.createScaledBitmap(bitmap, w, h, true)
        val px = IntArray(w*h)
        small.getPixels(px,0,w,0,0,w,h)
        val visited = BooleanArray(w*h)
        var bestArea = 0
        var best: IntArray? = null
        fun yellow(c:Int):Boolean {
            val r=Color.red(c); val g=Color.green(c); val b=Color.blue(c)
            return r>175 && g>105 && r>g*1.15f && b<115
        }
        val qx=IntArray(w*h); val qy=IntArray(w*h)
        for(y in (h*0.68f).toInt() until h-2) for(x in 0 until w) {
            val idx=y*w+x
            if(visited[idx] || !yellow(px[idx])) continue
            var head=0; var tail=0; qx[tail]=x; qy[tail]=y; tail++; visited[idx]=true
            var minX=x; var maxX=x; var minY=y; var maxY=y; var area=0
            while(head<tail){
                val cx=qx[head]; val cy=qy[head]; head++; area++
                if(cx<minX)minX=cx; if(cx>maxX)maxX=cx; if(cy<minY)minY=cy; if(cy>maxY)maxY=cy
                val neighbours = arrayOf(
                    (cx to (cy - 1)),
                    (cx to (cy + 1)),
                    ((cx - 1) to cy),
                    ((cx + 1) to cy)
                )
                for ((nx, ny) in neighbours) {
                    if (nx !in 0 until w || ny !in (h * 0.68f).toInt() until h) continue
                    val ni = ny * w + nx
                    if (visited[ni] || !yellow(px[ni])) continue
                    visited[ni] = true
                    qx[tail] = nx
                    qy[tail] = ny
                    tail++
                }
            }
            if(area>bestArea && maxX-minX>12 && maxY-minY>5) { bestArea=area; best=intArrayOf(minX,minY,maxX,maxY) }
        }
        if (small !== bitmap) small.recycle()
        val r=best ?: return null
        return Point(((r[0]+r[2])/2f/w).coerceIn(0f,1f),((r[1]+r[3])/2f/h).coerceIn(0f,1f))
    }
}
