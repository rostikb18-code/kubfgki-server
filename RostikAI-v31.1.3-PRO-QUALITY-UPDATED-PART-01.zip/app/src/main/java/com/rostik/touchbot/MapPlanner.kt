package com.rostik.touchbot

import android.content.res.AssetManager
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Lightweight map-aware planner. The imported map files are 33x21 symbolic
 * occupancy grids. '#' is treated as outside/solid and 'W' as a hard obstacle;
 * bushes/ball-spawn markers remain traversable. The planner falls back to a
 * direct vector when no map is known or no path can be found.
 */
class MapPlanner(private val assets: AssetManager) {
    private var active: BrawlBallMapCatalog.MapDef? = null

    fun setMap(name: String?) {
        active = name?.let { n ->
            BrawlBallMapCatalog.all(assets).firstOrNull { it.name.equals(n, true) }
        }
    }

    fun activeMapName(): String? = active?.name

    fun waypoint(from: Point, target: Point): Point {
        val map = active ?: return target
        val rows = map.rows
        if (rows.isEmpty()) return target
        val h = rows.size
        val w = rows.maxOf { it.length }
        fun cell(p: Point): Pair<Int, Int> = Pair(
            (p.x.coerceIn(0f, .999f) * w).toInt().coerceIn(0, w - 1),
            (p.y.coerceIn(0f, .999f) * h).toInt().coerceIn(0, h - 1)
        )
        val start = cell(from)
        val goal = cell(target)
        if (start == goal) return target

        fun blocked(x: Int, y: Int): Boolean {
            if (x !in 0 until w || y !in 0 until h) return true
            val c = rows[y].getOrNull(x) ?: '#'
            return c == '#' || c == 'W'
        }
        if (blocked(start.first, start.second) || blocked(goal.first, goal.second)) return target

        data class Node(val x: Int, val y: Int, val g: Int, val f: Int)
        val open = java.util.PriorityQueue<Node>(compareBy<Node> { it.f }.thenBy { it.g })
        val best = HashMap<Pair<Int, Int>, Int>()
        val parent = HashMap<Pair<Int, Int>, Pair<Int, Int>>()
        open += Node(start.first, start.second, 0, manhattan(start, goal))
        best[start] = 0
        val dirs = arrayOf(1 to 0, -1 to 0, 0 to 1, 0 to -1, 1 to 1, 1 to -1, -1 to 1, -1 to -1)

        var found = false
        var expanded = 0
        while (open.isNotEmpty() && expanded++ < 900) {
            val n = open.poll()
            val key = n.x to n.y
            if (key == goal) { found = true; break }
            if (n.g != best[key]) continue
            for ((dx, dy) in dirs) {
                val nx = n.x + dx; val ny = n.y + dy
                if (blocked(nx, ny)) continue
                // Do not cut diagonally through the corner of two walls.
                // That produces paths which look valid on the grid but are
                // physically impossible for the brawler to traverse.
                if (dx != 0 && dy != 0 && (blocked(n.x + dx, n.y) || blocked(n.x, n.y + dy))) continue
                val step = if (dx != 0 && dy != 0) 14 else 10
                val ng = n.g + step
                val nk = nx to ny
                if (ng < (best[nk] ?: Int.MAX_VALUE)) {
                    best[nk] = ng
                    parent[nk] = key
                    open += Node(nx, ny, ng, ng + manhattan(nk, goal) * 10)
                }
            }
        }
        if (!found) return target

        var cur = goal
        val path = ArrayList<Pair<Int, Int>>()
        path += cur
        while (cur != start) {
            cur = parent[cur] ?: return target
            path += cur
            if (path.size > 1000) return target
        }
        path.reverse()
        val lookAhead = path[minOf(path.size - 1, 4)]
        return Point(
            ((lookAhead.first + .5f) / w).coerceIn(.03f, .97f),
            ((lookAhead.second + .5f) / h).coerceIn(.08f, .94f)
        )
    }

    private fun manhattan(a: Pair<Int, Int>, b: Pair<Int, Int>): Int =
        abs(a.first - b.first) + abs(a.second - b.second)
}
