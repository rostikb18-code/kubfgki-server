package com.rostik.touchbot

import android.content.Context
import android.graphics.Bitmap

/** Process-local bridge shared by MainActivity, capture and floating overlay. */
object BotRuntime {
    @Volatile private var app: Context? = null
    @Volatile private var initialized = false
    @Volatile private var crashHandlerInstalled = false
    val queue: QueueEngine = QueueEngine()
    val supervisor: MatchSupervisor by lazy {
        val context = app ?: throw IllegalStateException("BotRuntime.init() must be called before supervisor is used")
        MatchSupervisor(queue, context.assets)
    }

    @Volatile var captureActive: Boolean = false
        private set

    fun init(context: Context) {
        val application = context.applicationContext
        if (initialized) return
        synchronized(this) {
            if (initialized) return
            app = application
            StatsStore.init(application)
            DiscordLogger.init(application)
            installCrashHandler(application)
            QueuePersistence.restore(application, queue)
            queue.setChangeListener { QueuePersistence.save(application, queue) }
            initialized = true
        }
    }

    fun ensureInitialized(context: Context) {
        init(context)
    }

    fun submitFrame(bitmap: Bitmap) {
        // Ownership is transferred to MatchSupervisor. Do not keep another reference
        // here because the supervisor recycles each consumed frame.
        supervisor.submitLatestFrame(bitmap)
    }

    fun setCaptureActive(active: Boolean) {
        captureActive = active
        DiscordLogger.info(DiscordLogger.Category.SCREEN, if (active) "Захват экрана активен" else "Захват экрана остановлен", "captureActive=$active")
    }

    private fun installCrashHandler(context: Context) {
        if (crashHandlerInstalled) return
        synchronized(this) {
            if (crashHandlerInstalled) return
            crashHandlerInstalled = true
        }
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try { DiscordLogger.crash(context, thread, throwable) } catch (_: Throwable) {}
            try { previous?.uncaughtException(thread, throwable) } catch (_: Throwable) {}
        }
    }
}
