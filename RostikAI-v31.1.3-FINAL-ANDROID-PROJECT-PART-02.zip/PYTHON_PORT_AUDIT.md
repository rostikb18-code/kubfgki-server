# Python -> RostikAI Kotlin integration audit

This document records the direct translation of the supplied Python modules into the Android architecture. It does not claim byte-for-byte source recovery; desktop-only APIs are translated to Android equivalents.

| Supplied Python responsibility | RostikAI Kotlin implementation | Integration status |
|---|---|---|
| `TrophyObserver.trophy_lose_ranges` / `trophy_win_ranges` | `TrophyRules.kt` | exact tables ported |
| `TrophyObserver.showdown_trio_ranges` | `TrophyRules.kt` | exact 4-place table ported |
| `TrophyObserver.win_streak_gain()` | `TrophyRules.kt` | same `<2000` / max-10 rule |
| `TrophyObserver.add_trophies()` | `TrophyObserver.record()` | result -> delta -> streak -> history |
| `session_stats()` | `TrophyObserver.sessionStats()` + `StatsStore` | integrated |
| `load_history()` / `save_history()` | app-private `match_history.csv` | integrated |
| `hash_playstyle()` | SHA-256 playstyle fingerprint | integrated |
| `fetch_brawl_stars_player()` | `BrawlStarsApiClient` | token/player-tag sync |
| `sync_trophies_from_api_after_match()` | `BrawlStarsApiClient.syncQueue()` | integrated after confirmed result |
| `state_finder.find_game_result()` | `LegacyStateDetector.detectResult()` | OCR + bundled result templates |
| `get_in_game_state()` | `LegacyStateDetector` + `NavigationVision` | integrated into frame state selection |
| brawler/shop/popup template states | `LegacyStateDetector` | bundled Android templates + evidence thresholds |
| `StageManager.start_game()` | `MatchSupervisor.PREPARE` / brawler selection / target gate | integrated |
| `StageManager.end_game()` | `MatchSupervisor.RESULT` / `REWARD` / `PLAY_AGAIN` | integrated |
| `handle_star_drop()` | `rewardStep()` + `BotAccessibilityService.longPress()` | Android gesture translation |
| `handle_prestige_reward()` | `rewardStep()` + green action detection + `VERIFY_RESULT_CUPS` | integrated where OCR/visual evidence exists |
| `dismiss_end_screen()` / `click_play_again_button()` | `MatchSupervisor.playAgain()` + `NavigationVision` / `UiButtonVision` | integrated |
| `save_brawler_data()` | `QueuePersistence` | process-death persistence |
| `WindowCapture` / screenshots | `ScreenCaptureService` | MediaProjection, not Win32 |
| `WindowController.click/press/swipe` | `BotAccessibilityService.tap/swipe/dispatch/longPress` | Android-native gestures |
| `notify_user()` | `DiscordLogger` + `StatsStore` | diagnostic/event path |
| desktop `pyautogui`, `win32gui`, `SendInput`, `scrcpy` | MediaProjection + AccessibilityService + Android normalized coordinates | intentionally translated, not copied |

## Important source limitations preserved honestly

- The supplied Python `state_finder.py` refers to additional `images/states`, `images/end_results`, and `images/star_drop_types` files that were not present in the supplied Android asset set. The Kotlin port therefore uses the result/state assets actually present in `app/src/main/assets/apk_port` plus OCR evidence rather than inventing missing templates.
- The supplied Python developer-account auto-token-refresh flow requires storing a developer email/password. The Android port deliberately does not persist those credentials. `BrawlStarsApiClient` supports the documented player-token flow; automatic developer-key creation is not silently faked.
- The supplied Python YOLO/scrcpy desktop pipeline is not claimed to be an Android YOLO model. RostikAI continues to use the existing Android `MatchVision`/reference/OCR pipeline. The opaque `m0.bin`, `m1.bin`, and `m2.bin` files are packaged and verified as assets, but are not claimed to be a working YOLO/TFLite model without runtime model validation.
- Android Gradle compilation and real-device match execution must be verified by GitHub Actions/device testing. Local static checks and the pure Kotlin trophy-rule test do not substitute for that.
