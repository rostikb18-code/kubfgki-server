package com.rostik.touchbot

import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max

class PerfProfiler {
    private val stages=ConcurrentHashMap<String,MutableList<Double>>()
    private val counters=ConcurrentHashMap<String,Long>()
    fun record(stage:String,ms:Double){stages.computeIfAbsent(stage){mutableListOf()}.let{ synchronized(it){it.add(max(0.0,ms));if(it.size>120)it.removeAt(0)}}}
    fun counter(name:String,amount:Long=1){counters.merge(name,amount,Long::plus)}
    fun snapshot():Map<String,Any>{
        val out=LinkedHashMap<String,Any>(); val stageOut=LinkedHashMap<String,Any>()
        stages.forEach{(k,v)->val a=synchronized(v){v.toList()};if(a.isNotEmpty()){val sorted=a.sorted();stageOut[k]=mapOf("count" to a.size,"avg_ms" to a.average(),"p50_ms" to sorted[sorted.size/2],"p95_ms" to sorted[(sorted.lastIndex*.95).toInt()])}}
        out["stages"]=stageOut;out["counters"]=HashMap(counters);return out
    }
    inline fun <T> time(stage:String,block:()->T):T{val s=System.nanoTime();try{return block()}finally{record(stage,(System.nanoTime()-s)/1_000_000.0)}}
}
