package com.rostik.touchbot

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.ArrayDeque
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.max

/** Atomic, bounded runtime telemetry equivalent to runtime_metrics.py. */
class RuntimeMetrics(private val context: Context) {
    private val path = File(context.filesDir, "runtime_metrics.json")
    private val samples = ArrayDeque<Double>()
    private val processed = AtomicLong(0)
    private val startedAt = AtomicLong(0)
    @Volatile var state: String = "IDLE"
    @Volatile var brawler: String = ""
    @Volatile var target: Int? = null
    @Volatile var trophies: Int? = null
    @Volatile var notice: String = "Running"
    @Volatile var lastMatch: String = ""
    @Volatile var lastRecovery: String = ""
    @Volatile var sessionWins: Int = 0
    @Volatile var sessionLosses: Int = 0
    @Volatile var sessionDraws: Int = 0
    @Volatile var recoveryCount: Int = 0
    @Volatile var displayRepairs: Int = 0
    @Volatile var appRestarts: Int = 0

    fun begin() { if (startedAt.get() == 0L) startedAt.compareAndSet(0L, System.currentTimeMillis()) }
    fun end() { startedAt.set(0L) }
    fun recordLoopMs(ms: Double) { synchronized(samples) { samples.addLast(max(0.0, ms)); while (samples.size > 120) samples.removeFirst() } }
    fun recordFrame() { processed.incrementAndGet() }

    fun snapshot(feedFps: Double = 0.0): JSONObject {
        val uptime = if (startedAt.get() == 0L) 0.0 else (System.currentTimeMillis() - startedAt.get()).coerceAtLeast(0L) / 1000.0
        val hist = synchronized(samples) { samples.toList() }
        val ips = if (hist.isEmpty()) 0.0 else hist.count { it > 0 }.toDouble() / max(1.0, hist.sum() / 1000.0)
        val history = JSONArray(); hist.forEach { history.put(1000.0 / it.coerceAtLeast(1.0)) }
        return JSONObject().put("ips", ips).put("feed_fps", feedFps).put("history", history).put("session", JSONObject()
            .put("uptime_s", uptime).put("state", state).put("brawler", brawler).put("target", target)
            .put("trophies", trophies).put("notice", notice).put("last_match", lastMatch).put("last_recovery", lastRecovery)
            .put("session_wins", sessionWins).put("session_losses", sessionLosses).put("session_draws", sessionDraws)
            .put("recovery_count_session", recoveryCount).put("display_repairs", displayRepairs).put("app_restarts", appRestarts))
    }

    @Synchronized fun write(feedFps: Double = 0.0) {
        val text = snapshot(feedFps).toString()
        val tmp = File(path.parentFile, path.name + ".tmp")
        try { tmp.writeText(text); if (!tmp.renameTo(path)) path.writeText(text) } catch (_: Throwable) { try { path.writeText(text) } catch (_: Throwable) {} }
        finally { try { tmp.delete() } catch (_: Throwable) {} }
    }
}
