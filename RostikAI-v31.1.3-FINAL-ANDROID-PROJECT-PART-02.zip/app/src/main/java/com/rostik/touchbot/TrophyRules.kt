package com.rostik.touchbot

/** Exact trophy arithmetic ported from the supplied Python TrophyObserver. */
object TrophyRules {
    private val lossRanges = listOf(
        49 to 0, 299 to 1, 599 to 2, 799 to 3, 999 to 4,
        1099 to 5, 1199 to 6, 1299 to 7, 1499 to 8, 1799 to 9,
        3999 to 10, Int.MAX_VALUE to 15
    )
    private val winRanges = listOf(
        1999 to 10, 2499 to 8, 2799 to 6, 2999 to 4, 3099 to 2, Int.MAX_VALUE to 1
    )
    private val showdownRanges = listOf(
        49 to intArrayOf(11, 5, 5, 5),
        99 to intArrayOf(11, 5, 4, -1),
        199 to intArrayOf(11, 5, 3, -1),
        299 to intArrayOf(11, 5, 2, -1),
        499 to intArrayOf(11, 5, 2, -2),
        599 to intArrayOf(11, 5, 1, -2),
        799 to intArrayOf(11, 5, 1, -3),
        999 to intArrayOf(11, 5, 1, -4),
        1099 to intArrayOf(11, 5, 0, -6),
        1199 to intArrayOf(11, 5, 0, -7),
        1299 to intArrayOf(11, 5, 0, -8),
        1499 to intArrayOf(11, 5, 0, -9),
        1799 to intArrayOf(11, 5, -5, -10),
        1999 to intArrayOf(11, 5, -5, -11),
        2199 to intArrayOf(9, 4, -5, -11),
        Int.MAX_VALUE to intArrayOf(9, 4, -5, -11)
    )

    fun delta(currentTrophies: Int, winStreakBeforeResult: Int, result: String, multiplier: Int = 1): Pair<Int, Int> {
        require(currentTrophies in 0..10000)
        require(multiplier > 0)
        val raw = result.trim().lowercase()
        var streak = winStreakBeforeResult
        val gain = { if (currentTrophies < 2000) (streak - 1).coerceAtMost(10) else 0 }
        return when {
            raw == "victory" -> {
                streak += 1
                val base = winRanges.first { currentTrophies <= it.first }.second
                (base * multiplier + gain()).coerceAtLeast(0) to streak
            }
            raw == "defeat" -> {
                streak = 0
                (-lossRanges.first { currentTrophies <= it.first }.second * multiplier) to streak
            }
            raw == "draw" -> 0 to streak
            raw.startsWith("trio_showdown_") || raw.startsWith("showdown_") -> {
                val place = raw.substringAfterLast('_').toIntOrNull()
                    ?: throw IllegalArgumentException("Invalid showdown result: $result")
                require(place in 0..3)
                if (place < 2) streak += 1 else if (place > 2) streak = 0
                val base = showdownRanges.first { currentTrophies <= it.first }.second[place]
                (base * multiplier + if (place < 2) gain() else 0) to streak
            }
            else -> throw IllegalArgumentException("Unknown match result: $result")
        }
    }
}
