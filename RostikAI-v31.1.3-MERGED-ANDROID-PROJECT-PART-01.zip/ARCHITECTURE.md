# RostikAI 31.1.3 — понятная архитектура

## Что делает приложение

RostikAI состоит из четырёх понятных слоёв:

1. **OverlayService** — интерфейс поверх Brawl Stars: выбор бойцов, очередь, текущие/целевые кубки, START/PAUSE/STOP.
2. **ScreenCaptureService** — получает кадры экрана через MediaProjection.
3. **MatchSupervisor** — единая state machine: подготовка → выбор бойца → проверка кубков → Brawl Ball → PLAY → матч → результат → награда → PLAY AGAIN → следующий боец.
4. **Vision / Control** — OCR, шаблоны аватаров/экранов, обнаружение джойстиков/игрока/мяча и Accessibility GestureDescription.

## Почему код не зависит от AccessibilityNodeInfo

Brawl Stars использует Unity, поэтому дерево Accessibility может быть пустым. Accessibility используется как транспорт жестов, а решение о том, куда нажать, принимает vision/OCR.

## START

START проверяет:

- AccessibilityService;
- MediaProjection;
- выбранных бойцов;
- текущие и целевые кубки;
- установлен ли Brawl Stars.

После этого приложение открывает Brawl Stars и запускает supervisor. Supervisor ждёт подтверждения реального экрана и не делает слепых действий на UNKNOWN.

## Кубки

Для каждого бойца хранится:

- currentCups — текущие кубки;
- targetCups — цель;
- startCups — стартовое значение;
- matchesPlayed;
- winStreak.

Значения сохраняются в SharedPreferences. После результата OCR и TrophyObserver обновляют очередь.

## Выбор бойца

Сначала используется OCR + визуальный поиск аватара. Список прокручивается вертикально; для нестандартного layout предусмотрен горизонтальный fallback. После нажатия выбор подтверждается следующим кадром.

## Безопасность действий

Каждое критическое действие построено как:

`распознать → нажать → дождаться следующего состояния → подтвердить`.

Если экран неизвестен, приложение ждёт. Если действие не подтверждается в допустимое время, включается fail-safe и бот останавливается вместо случайных тапов.

## Реальный матч

`ReactiveBrawlBallController` использует текущую сцену:

- позиция игрока;
- враги;
- союзники;
- мяч;
- левый joystick движения;
- правый joystick атаки/прицеливания;
- super.

Это не заявка на «обученную нейросеть»: контроллер является детерминированным perception-driven контроллером с картами/waypoints и recovery.

## Сборка

GitHub Actions выполняет source preflight, устанавливает Java 17, Android SDK 35 и Gradle 8.10.2, затем запускает:

- `compileDebugKotlin`
- `lintDebug`
- `assembleDebug`
- `assembleRelease`
- проверку APK

Локальный `gradlew` в этом пакете делегирует системному Gradle; в GitHub Actions Gradle предоставляется `gradle/actions/setup-gradle`.
