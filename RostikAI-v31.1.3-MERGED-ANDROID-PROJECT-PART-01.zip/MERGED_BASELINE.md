# RostikAI v31.1.3 — merged baseline

This repository is based on the previously verified RostikTouchBot/RostikAI source, with the professional Android CV architecture used as the design reference rather than replacing the functional implementation with a smaller demo.

## Preserved functional systems

- 108-brawler catalog and local avatar assets
- 88 Brawl Ball maps
- current/target trophy queue
- queue persistence across process restart
- trophy/result tracking
- Brawl Ball navigation state machine
- Play Again / reward handling
- MediaProjection screen capture
- Accessibility gesture control
- MatchVision / NavigationVision / OCR / reference matching
- reactive Brawl Ball controller
- recovery/watchdog/metrics/logging
- GitHub Actions debug + release APK artifacts

## Merge rule

The previous functional project is the runtime base. The smaller professional skeleton is not allowed to overwrite working queue, trophy, vision, capture, or match-supervisor implementations with placeholders.

The supplied APK is treated as a behavioral/reference asset source only. Its protected native/model implementation is not copied or bypassed.

## Verification

`python3 tools/verify_source.py` must report:

`SOURCE_PREFLIGHT_PASS`

with 39 Kotlin files, 108 brawler icons, 108 catalog entries, 88 maps and 11 Python-port assets.
