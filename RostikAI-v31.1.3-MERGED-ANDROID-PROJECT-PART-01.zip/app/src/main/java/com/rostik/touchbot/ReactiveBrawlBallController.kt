package com.rostik.touchbot

import kotlin.math.hypot
import kotlin.math.max

/**
 * Deterministic, perception-driven Brawl Ball controller.
 *
 * It uses only current/temporally tracked detections. It does not invent an
 * enemy when the vision system is uncertain. When an opponent is visible the
 * attack vector is calculated explicitly and carried in ControlFrame. The
 * Accessibility layer turns that vector into a right-stick aim gesture.
 */
class ReactiveBrawlBallController(private val mapPlanner: MapPlanner) {
    private var lastSuperAt = 0L
    private var lastDodgeAt = 0L
    private var activeMapName: String? = null

    fun setMap(name: String?) { activeMapName = name; mapPlanner.setMap(name) }

    fun next(scene: MatchScene, now: Long, matchElapsedMs: Long): ControlFrame {
        val p = scene.player ?: return ControlFrame()
        val enemy = scene.enemies.asSequence()
            .filter { it.kind == "ENEMY" || it.kind == "PREDICTED_ENEMY" }
            .filter { it.confidence >= ENEMY_CONFIDENCE }
            .minByOrNull { distance(it.point, p.point) }

        val enemyDistance = enemy?.let { distance(it.point, p.point) } ?: Float.POSITIVE_INFINITY
        val attackAvailable = scene.rightJoystick != null && scene.attackConfidence >= ATTACK_CONTROL_CONFIDENCE

        // Directional aim is computed even before firing so the right-stick path
        // is stable when the enemy moves slightly between frames.
        val aim = enemy?.let {
            val predicted = Point(
                (it.point.x + it.velocity.x * 0.10f).coerceIn(.02f, .98f),
                (it.point.y + it.velocity.y * 0.10f).coerceIn(.08f, .94f)
            )
            aimVector(p.point, predicted)
        } ?: Point(0f, 0f)
        val enemyNear = enemy != null && enemyDistance <= ENEMY_NEAR_DISTANCE
        // Do not wait until the enemy is almost on top of us before firing.
        // A Brawl Ball controller needs a medium-range attack window as well.
        val enemyAttackWindow = enemy != null && enemyDistance <= ENEMY_ATTACK_DISTANCE
        if (enemyAttackWindow) {
            // Super does not require a separately detected attack button: the
            // super control has its own coordinate and must remain usable even
            // when the attack detector temporarily loses the right stick.
            val useSuper = shouldSuper(scene, enemyDistance <= SUPER_ENEMY_DISTANCE, now, matchElapsedMs)
            if (useSuper) {
                return ControlFrame(
                    moveX = if (enemyNear) 0f else (p.point.x - enemy.point.x).coerceIn(-1f, 1f),
                    moveY = if (enemyNear) 0f else (p.point.y - enemy.point.y).coerceIn(-1f, 1f),
                    aimX = aim.x, aimY = aim.y, useSuper = true, superPoint = scene.superPoint
                )
            }
            if (!attackAvailable) return ControlFrame(aimX = aim.x, aimY = aim.y)
            return ControlFrame(
                moveX = if (enemyNear) 0f else (p.point.x - enemy.point.x).coerceIn(-1f, 1f) * .35f,
                moveY = if (enemyNear) 0f else (p.point.y - enemy.point.y).coerceIn(-1f, 1f) * .35f,
                aimX = aim.x, aimY = aim.y, fire = true
            )
        }

        // Dodge sideways when a close opponent is detected, but throttle it so
        // movement remains stable instead of oscillating every frame.
        if (enemy != null && enemyDistance < .18f && now - lastDodgeAt > 700L) {
            lastDodgeAt = now
            val ex = enemy.point.x - p.point.x
            val ey = enemy.point.y - p.point.y
            val sideX = -ey
            val sideY = ex
            val mag = max(.001f, hypot(sideX.toDouble(), sideY.toDouble()).toFloat())
            val sign = if (p.point.x < .5f) 1f else -1f
            return ControlFrame(
                moveX = (sideX / mag * sign).coerceIn(-1f, 1f),
                moveY = (sideY / mag * sign).coerceIn(-1f, 1f)
            )
        }

        val ball = scene.ball
        // Brawl Ball can present the team from either vertical side depending
        // on the camera/spawn orientation. Infer the friendly side from the
        // player's current position instead of assuming blue is always bottom.
        val playerIsBottom = p.point.y >= .50f
        val attackGoal = Point(.50f, if (playerIsBottom) .08f else .92f)
        val ownGoal = Point(.50f, if (playerIsBottom) .92f else .08f)
        val ballDistance = ball?.let { distance(it.point, p.point) } ?: Float.POSITIVE_INFINITY
        val ballThreat = ball != null && if (playerIsBottom) ball.point.y > .68f else ball.point.y < .32f
        val retreatY = if (playerIsBottom) .72f else .28f

        // Brawl Ball's important transition is possession -> advance -> kick.
        // Treat a close, confidently detected ball as the primary objective and
        // aim the attack control at the opponent goal when possession is likely.
        // This is the Android equivalent of the reference bot's perception ->
        // decision -> input loop; it never invents a ball when detection is weak.
        val ballConfident = ball != null && ball.confidence >= .60f
        val possessionLikely = ballConfident && ballDistance <= .12f
        if (possessionLikely && attackAvailable) {
            val goalAim = aimVector(p.point, attackGoal)
            val useSuper = shouldSuper(scene, enemyNear = enemyDistance <= SUPER_ENEMY_DISTANCE, now, matchElapsedMs)
            if (useSuper) {
                return ControlFrame(aimX = goalAim.x, aimY = goalAim.y, useSuper = true, superPoint = scene.superPoint)
            }
            return ControlFrame(aimX = goalAim.x, aimY = goalAim.y, fire = true)
        }

        val ballPoint = ball?.point
        val moveTarget = when {
            ballConfident && ballPoint != null && ballDistance < .22f -> ballPoint
            ballConfident && ballPoint != null && !ballThreat -> ballPoint
            ballConfident && ballPoint != null -> Point(ballPoint.x, retreatY)
            enemy != null && enemyDistance < .42f -> Point(
                (p.point.x + (p.point.x - enemy.point.x) * .55f).coerceIn(.08f, .92f),
                (p.point.y + (p.point.y - enemy.point.y) * .35f).coerceIn(.18f, .82f)
            )
            else -> Point(.50f, .50f)
        }

        // Keep a small map-dependent pathing hook. MapPlanner is installed by
        // MatchSupervisor through setMap; unknown maps use direct movement.
        val target = mapPlanner.waypoint(p.point, moveTarget)
        val targetAim = ballPoint?.let { aimVector(p.point, it) } ?: aim
        return ControlFrame(
            moveX = (target.x - p.point.x).coerceIn(-1f, 1f),
            moveY = (target.y - p.point.y).coerceIn(-1f, 1f),
            aimX = targetAim.x,
            aimY = targetAim.y
        )
    }

    private fun aimVector(from: Point, to: Point): Point {
        val dx = (to.x - from.x)
        val dy = (to.y - from.y)
        val mag = max(.001f, hypot(dx.toDouble(), dy.toDouble()).toFloat())
        return Point((dx / mag).coerceIn(-1f, 1f), (dy / mag).coerceIn(-1f, 1f))
    }

    private fun shouldSuper(scene: MatchScene, enemyNear: Boolean, now: Long, elapsed: Long): Boolean {
        if (!scene.superReady || !enemyNear) return false
        if (scene.superPoint == null || scene.superConfidence < SUPER_CONTROL_CONFIDENCE) return false
        if (elapsed < 8_000L || now - lastSuperAt < 2_800L) return false
        lastSuperAt = now
        return true
    }

    private fun distance(a: Point, b: Point): Float = hypot((a.x - b.x).toDouble(), (a.y - b.y).toDouble()).toFloat()

    companion object {
        private const val ENEMY_NEAR_DISTANCE = .34f
        private const val ENEMY_ATTACK_DISTANCE = .56f
        private const val SUPER_ENEMY_DISTANCE = .27f
        private const val ENEMY_CONFIDENCE = .72f
        private const val ATTACK_CONTROL_CONFIDENCE = .55f
        private const val SUPER_CONTROL_CONFIDENCE = .55f
    }
}
