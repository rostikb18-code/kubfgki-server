#!/usr/bin/env python3
"""Static deep audit for RostikAI UI/control contracts.

This is intentionally separate from Android compilation: it verifies that the
critical user-visible controls have handlers and that the automation state
machine has no accidental dead-end state in source.
"""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / "app/src/main/java/com/rostik/touchbot"


def fail(msg):
    print(f"DEEP_AUDIT_FAIL: {msg}")
    sys.exit(1)


def require(text, needle, where):
    if needle not in text:
        fail(f"missing {needle!r} in {where}")


overlay = (JAVA / "OverlayService.kt").read_text(encoding="utf-8")
main_activity = (JAVA / "MainActivity.kt").read_text(encoding="utf-8")
supervisor = (JAVA / "MatchSupervisor.kt").read_text(encoding="utf-8")
access = (JAVA / "BotAccessibilityService.kt").read_text(encoding="utf-8")
trophy = (JAVA / "TrophyReader.kt").read_text(encoding="utf-8")

# UI action contract.
for marker in (
    'setOnClickListener { if (!moved) togglePanel() }',
    'setOnClickListener { collapse() }',
    'setOnClickListener {',
    'startBot()',
    'BotRuntime.supervisor.pause()',
    'BotRuntime.supervisor.resume()',
    'BotRuntime.supervisor.stop()',
    'selected.add(entry.id)',
    'selected.remove(entry.id)',
    'draft.remove(id)',
    'editorField = field',
    'commitEditor(id)',
    'setEditorValue(id, value)',
    'adjustEditor(id, delta)',
    'handleKey(id, key)',
    'saveDraft()',
    'updatePanelSize()',
):
    require(overlay, marker, "OverlayService.kt")

# Direct multi-digit entry must exist; rebuilding the panel per key is the bug
# this audit is designed to prevent.
require(overlay, 'EditText(this).apply', "OverlayService.kt")
require(overlay, 'TYPE_CLASS_NUMBER', "OverlayService.kt")
require(overlay, 'editor.addTextChangedListener', "OverlayService.kt")
m = re.search(r'private fun handleKey\(id: String, key: String\) \{(.*?)\n    \}', overlay, re.S)
if not m:
    fail("handleKey function not found")
if 'rebuildPanel()' in m.group(1):
    fail("numeric key handler must not rebuild the overlay on every digit")

# Trophy range consistency.
require(overlay, 'coerceIn(0, 10000)', "OverlayService.kt")
require(trophy, 'n in 0..10000', "TrophyReader.kt")

# MainActivity controls: navigation, launch, permissions, Discord actions.
for marker in (
    'setOnClickListener { activeSection = i; updateNav(nav); showSection(i) }',
    'setOnClickListener { play() }',
    'requestCapture()',
    'openBrawlStars()',
    'DiscordLogger.configure(this@MainActivity, url, true)',
    'DiscordLogger.test(this@MainActivity)',
):
    require(main_activity, marker, "MainActivity.kt")

# Start pipeline.
for marker in (
    'RunState.PREPARE',
    'RunState.SELECT_BRAWLER',
    'RunState.VERIFY_BRAWLER',
    'RunState.VERIFY_CUPS',
    'RunState.SELECT_MODE',
    'RunState.SELECT_MAP',
    'RunState.PRESS_PLAY',
    'RunState.LOADING',
    'RunState.PLAYING',
    'RunState.RESULT',
    'RunState.REWARD',
    'RunState.VERIFY_RESULT_CUPS',
    'RunState.PLAY_AGAIN',
    'transition(RunState.PLAYING)',
    'transition(RunState.PLAY_AGAIN)',
):
    require(supervisor, marker, "MatchSupervisor.kt")

# No intentional idle movement in PLAYING: controller dispatch + heartbeat.
for marker in ('controller.next(scene, now, elapsed)', 'service.dispatch(', 'heartbeatMovement(scene, now)'):
    require(supervisor, marker, "MatchSupervisor.kt")

# Super must use the freshly detected super button coordinate, not the attack button.
require(supervisor, 'val superPoint = frame.superPoint', "MatchSupervisor.kt")
require(supervisor, 'left ?: TouchLayout.MOVE, right ?: TouchLayout.ATTACK, 55L', "MatchSupervisor.kt")

# Gesture gateway has both actual callback release and timeout fallback.
for marker in ('dispatchGesture(gesture', 'onCompleted', 'onCancelled', 'postDelayed({ releaseGesture()', 'fun tap(', 'fun swipe('):
    require(access, marker, "BotAccessibilityService.kt")

# Capture should never redeliver a stale MediaProjection token.
capture = (JAVA / "ScreenCaptureService.kt").read_text(encoding="utf-8")
if 'START_REDELIVER_INTENT' in capture:
    fail("stale MediaProjection redelivery is forbidden")
require(capture, 'START_NOT_STICKY', "ScreenCaptureService.kt")

# Count named controls for a useful audit summary.
clicks = len(re.findall(r'setOnClickListener\s*\{', overlay))
if clicks < 12:
    fail(f"unexpectedly few overlay click handlers: {clicks}")

print("DEEP_AUDIT_PASS")
print(f"overlay_click_handlers={clicks}")
print("multi_digit_trophy_input=PASS")
print("trophy_range_0_10000=PASS")
print("start_stop_pause_pipeline=PASS")
print("match_heartbeat_dispatch=PASS")
print("gesture_release_watchdog=PASS")
print("media_projection_no_redelivery=PASS")
