# RostikAI v31.1.3

RostikAI — Android-приложение с floating overlay для автоматизированного управления Brawl Stars через MediaProjection, vision/OCR и Android Accessibility gestures.

## Основной сценарий

`выбор бойцов → current cups / target cups → START → Brawl Stars → выбор бойца → Brawl Ball → PLAY → MATCH → RESULT → REWARD → PLAY AGAIN → следующий боец`

Для каждого бойца отдельно хранятся текущие и целевые кубки.

## Что есть в проекте

- 39 Kotlin source files;
- 108 brawler entries;
- 108 brawler PNG icons;
- 88 Brawl Ball maps;
- MediaProjection screen capture;
- OCR через ML Kit;
- visual/reference matching;
- Accessibility GestureDescription;
- queue persistence;
- trophy tracking;
- Brawl Ball controller;
- recovery/fail-safe state machine;
- floating overlay with search, queue and numeric trophy editor;
- GitHub Actions build.

## Как работает START

START проверяет Accessibility, screen capture, выбранных бойцов, корректность кубков и наличие Brawl Stars. Затем открывает игру и запускает `MatchSupervisor`.

Supervisor не использует AccessibilityNodeInfo как источник истины: Unity UI может не отдавать полезное дерево. Решения о состоянии экрана принимаются по кадру, OCR, reference images и vision.

## Кубки

Для каждого выбранного бойца вводится:

- `ТЕКУЩИЕ КУБКИ`;
- `ЦЕЛЕВЫЕ КУБКИ`.

Цель должна быть больше текущего значения. Значения сохраняются локально.

## Кнопки

- **START** — запускает автоматизацию;
- **PAUSE** — временно останавливает управление;
- **STOP** — останавливает текущий запуск, но оставляет overlay для повторного START;
- **×** в очереди — удаляет бойца;
- повторный тап по аватару — добавляет/убирает бойца из очереди;
- поля кубков открывают встроенную цифровую клавиатуру.

## Важное ограничение честности

Контроллер матча является perception-driven детерминированным контроллером, а не заявленной обученной нейросетью. Он использует обнаружение игрока, врагов, мяча, джойстиков, карт и условий атаки.

APK не позволяет честно восстановить оригинальный закрытый исходный код стороннего приложения 1:1. В проекте используются собственная реализация и доступные визуальные данные; защитный anti-debug/anti-Frida слой стороннего APK не переносится.

## Проверка

```bash
python3 tools/verify_source.py
```

Ожидаемый результат:

```text
SOURCE_PREFLIGHT_PASS
kotlin=39 brawler_icons=108 catalog=108 maps=88 python_port=11
```

Полная Android-сборка является задачей GitHub Actions.
