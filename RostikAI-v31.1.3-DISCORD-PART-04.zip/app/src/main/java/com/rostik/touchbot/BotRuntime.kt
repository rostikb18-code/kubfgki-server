package com.rostik.touchbot

import android.content.Context
import android.graphics.Bitmap

/** Process-local bridge shared by MainActivity, capture and floating overlay. */
object BotRuntime {
    private lateinit var app: Context
    @Volatile private var crashHandlerInstalled = false
    val queue: QueueEngine = QueueEngine()
    val supervisor: MatchSupervisor by lazy { MatchSupervisor(queue, app.assets) }

    @Volatile var captureActive: Boolean = false
        private set

    fun init(context: Context) {
        app = context.applicationContext
        StatsStore.init(app)
        DiscordLogger.init(app)
        installCrashHandler(app)
        QueuePersistence.restore(app, queue)
        queue.setChangeListener { QueuePersistence.save(app, queue) }
    }

    fun submitFrame(bitmap: Bitmap) {
        // Ownership is transferred to MatchSupervisor. Do not keep another reference
        // here because the supervisor recycles each consumed frame.
        supervisor.submitLatestFrame(bitmap)
    }

    fun setCaptureActive(active: Boolean) {
        captureActive = active
        DiscordLogger.info(DiscordLogger.Category.SCREEN, if (active) "Захват экрана активен" else "Захват экрана остановлен", "captureActive=$active")
    }

    private fun installCrashHandler(context: Context) {
        if (crashHandlerInstalled) return
        synchronized(this) {
            if (crashHandlerInstalled) return
            crashHandlerInstalled = true
        }
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try { DiscordLogger.crash(context, thread, throwable) } catch (_: Throwable) {}
            try { previous?.uncaughtException(thread, throwable) } catch (_: Throwable) {}
        }
    }
}
