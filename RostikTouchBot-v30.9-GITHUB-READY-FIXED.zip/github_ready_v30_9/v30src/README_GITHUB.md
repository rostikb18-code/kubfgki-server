# Rostik Touch Bot v30.8

## GitHub upload

Repository layout:

```text
RostikTouchBot-v30.8-FINAL-source.zip
.github/workflows/build.yml
```

The workflow extracts `v30src/` from the ZIP and builds debug and release APKs with JDK 17, Android SDK 35 and Gradle 8.10.2.

## Queue UI

The overlay uses one combined **БОЙЦЫ** screen:

- brawler avatars on the left;
- selected brawlers appear in the queue on the right;
- every queue item has editable **СЕЙЧАС** and **ЦЕЛЬ** trophy fields;
- any number of catalog brawlers can be queued, limited only by the available screen/scrolling area;
- the same brawler cannot be added twice;
- tapping an already queued avatar shows `Имя уже в очереди` and does not remove it;
- removal is done with the `×` button on that queue row;
- panel **ШИРИНА %** and **ВЫСОТА %** are adjusted independently;
- width and height are persisted.

The source currently contains 108 catalog entries. 91 entries have bundled image assets; entries without a bundled image use the existing initials fallback in the selector.

## Build verification

GitHub Actions is the authoritative Android compilation check. The local environment used to prepare this source does not include a usable Android Gradle installation, so this package is not described as locally APK-compiled.


## Combat control detection v30.8

During a Brawl Ball match the app detects the movement joystick, attack button and Super button from the current frame. Detection combines circular/ring structure, color/brightness cues, broad HUD-zone search and temporal tracking of the last confirmed position. The attack action is a short tap (auto-aim by the game), not an aim-drag. The movement joystick remains a separate drag and Super is a separate tap.

The calibrated coordinates are fallbacks only; normal play uses the per-frame detector.
