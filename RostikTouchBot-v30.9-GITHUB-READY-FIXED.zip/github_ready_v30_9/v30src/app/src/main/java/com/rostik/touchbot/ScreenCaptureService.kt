package com.rostik.touchbot

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.Log
import androidx.core.app.ServiceCompat

class ScreenCaptureService:Service(){
    companion object {
        const val EXTRA_RESULT_CODE="resultCode"
        const val EXTRA_RESULT_DATA="resultData"
        var onBitmap:((android.graphics.Bitmap)->Unit)?=null
    }
    private var projection:MediaProjection?=null
    private var reader:ImageReader?=null
    private var thread:HandlerThread?=null
    private var handler:Handler?=null

    override fun onCreate(){
        super.onCreate()
        thread=HandlerThread("capture").also{it.start()}
        handler=Handler(thread!!.looper)
    }

    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
        val code=intent?.getIntExtra(EXTRA_RESULT_CODE,-1) ?: -1
        val data=intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA) ?: return START_NOT_STICKY
        val pm=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection=pm.getMediaProjection(code,data)
        if(projection==null) return START_NOT_STICKY
        if(android.os.Build.VERSION.SDK_INT>=29){
            ServiceCompat.startForeground(
                this,
                29,
                notification(),
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        }else{
            startForeground(29,notification())
        }
        val dm=resources.displayMetrics
        reader=ImageReader.newInstance(dm.widthPixels,dm.heightPixels,PixelFormat.RGBA_8888,2)
        reader!!.setOnImageAvailableListener({r->
            val image=r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try{
                val planes=image.planes
                val p=planes[0]
                val buf=p.buffer
                val w=image.width; val h=image.height
                val row=p.rowStride; val pixel=p.pixelStride
                val paddedW=row/pixel
                val bmp=android.graphics.Bitmap.createBitmap(paddedW,h,android.graphics.Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(buf)
                val cropped=if(paddedW!=w) android.graphics.Bitmap.createBitmap(bmp,0,0,w,h) else bmp
                if(cropped!==bmp) try{bmp.recycle()}catch(_:Throwable){}
                onBitmap?.invoke(cropped) ?: try{cropped.recycle()}catch(_:Throwable){}
            }catch(t:Throwable){Log.w("Capture","frame failed",t)}
            finally{try{image.close()}catch(_:Throwable){}}
        },handler)
        projection!!.createVirtualDisplay("RostikCapture",dm.widthPixels,dm.heightPixels,dm.densityDpi,
            android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,handler)
        return START_STICKY
    }

    private fun notification():Notification{
        val ch=NotificationChannel("capture","Rostik Capture",NotificationManager.IMPORTANCE_LOW)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        return Notification.Builder(this,"capture").setContentTitle("Rostik Touch Bot").setContentText("Screen capture active").setSmallIcon(android.R.drawable.ic_menu_view).build()
    }

    override fun onDestroy(){
        reader?.close(); projection?.stop(); thread?.quitSafely(); thread=null; handler=null
        super.onDestroy()
    }
    override fun onBind(intent:Intent?)=null
}
