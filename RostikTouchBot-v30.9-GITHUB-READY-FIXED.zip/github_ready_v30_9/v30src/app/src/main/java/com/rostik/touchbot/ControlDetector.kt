package com.rostik.touchbot

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Finds the three virtual combat controls directly from the current frame.
 *
 * The detector does not trust one hard-coded pixel. It searches the lower HUD
 * in broad zones, scores circular/ring structure, color and temporal continuity,
 * and keeps the last confirmed position when an effect briefly covers a control.
 * This is deliberately independent from the map/player detector.
 */
class ControlDetector {
    data class Result(
        val move: Detection,
        val attack: Detection,
        val superButton: Detection?,
        val superReady: Boolean,
        val confidence: Float
    )

    private var lastMove: Point? = null
    private var lastAttack: Point? = null
    private var lastSuper: Point? = null
    private var lastMoveAt = 0L
    private var lastAttackAt = 0L
    private var lastSuperAt = 0L

    fun detect(src: Bitmap, now: Long): Result {
        val w = 360
        val h = 202
        val bmp = Bitmap.createScaledBitmap(src, w, h, true)
        val pix = IntArray(w * h)
        bmp.getPixels(pix, 0, w, 0, 0, w, h)

        val move = findStick(
            pix, w, h,
            x0 = 8, x1 = 118,
            y0 = 118, y1 = 201,
            previous = lastMove,
            previousAt = lastMoveAt,
            now = now,
            kind = "MOVE_JOYSTICK",
            blueBias = true
        )
        val attack = findStick(
            pix, w, h,
            x0 = 250, x1 = 358,
            y0 = 112, y1 = 201,
            previous = lastAttack,
            previousAt = lastAttackAt,
            now = now,
            kind = "ATTACK_BUTTON",
            blueBias = false
        )
        val superResult = findSuper(pix, w, h, now)

        val moveFinal = move ?: fallback(lastMove, TouchLayout.MOVE, "MOVE_JOYSTICK", lastMoveAt, now)
        val attackFinal = attack ?: fallback(lastAttack, TouchLayout.ATTACK, "ATTACK_BUTTON", lastAttackAt, now)

        if (moveFinal.confidence >= .36f) {
            lastMove = moveFinal.point
            lastMoveAt = now
        }
        if (attackFinal.confidence >= .30f) {
            lastAttack = attackFinal.point
            lastAttackAt = now
        }
        if (superResult != null && superResult.confidence >= .34f) {
            lastSuper = superResult.point
            lastSuperAt = now
        }

        val superFinal = superResult ?: lastSuper?.let {
            Detection(it, confidenceFromAge(lastSuperAt, now, .38f), "SUPER_BUTTON")
        }

        val c = (moveFinal.confidence * .36f +
                attackFinal.confidence * .36f +
                (superFinal?.confidence ?: .25f) * .28f).coerceIn(0f, .98f)

        if (bmp !== src) try { bmp.recycle() } catch (_: Throwable) {}
        return Result(moveFinal, attackFinal, superFinal, superResult?.let { it.confidence >= .55f && it.kind == "SUPER_READY" } ?: false, c)
    }

    private fun findStick(
        pix: IntArray, w: Int, h: Int,
        x0: Int, x1: Int, y0: Int, y1: Int,
        previous: Point?, previousAt: Long, now: Long,
        kind: String, blueBias: Boolean
    ): Detection? {
        val prevPx = previous?.let { Point(it.x * w, it.y * h) }
        var best: Detection? = null

        fun scan(ax0: Int, ax1: Int, ay0: Int, ay1: Int) {
            var y = ay0
            while (y < ay1) {
                var x = ax0
                while (x < ax1) {
                    val temporal = if (prevPx != null) {
                        val d = hypot((x - prevPx.x).toDouble(), (y - prevPx.y).toDouble()).toFloat()
                        (1f - d / 42f).coerceIn(0f, 1f)
                    } else 0f
                    val radius = if (blueBias) 25 else 24
                    val ring = ringScore(pix, w, h, x, y, radius)
                    val inner = innerScore(pix, w, h, x, y, radius)
                    val blue = blueScore(pix, w, h, x, y, radius)
                    val neutral = neutralTranslucentScore(pix, w, h, x, y, radius)
                    val zone = zonePrior(x, y, w, h, blueBias)
                    val score = if (blueBias) {
                        ring * .40f + blue * .28f + inner * .10f + zone * .12f + temporal * .10f
                    } else {
                        ring * .48f + neutral * .18f + inner * .08f + zone * .16f + temporal * .10f
                    }
                    if (score > (best?.confidence ?: .28f)) {
                        best = Detection(Point(x / w.toFloat(), y / h.toFloat()), score.coerceIn(0f, .98f), kind)
                    }
                    x += 3
                }
                y += 3
            }
        }

        // First search around the last confirmed position. This prevents map
        // circles from stealing the control while the game camera/effects move.
        if (prevPx != null && now - previousAt < 700L) {
            scan(
                (prevPx.x - 34).toInt().coerceAtLeast(x0),
                (prevPx.x + 35).toInt().coerceAtMost(x1),
                (prevPx.y - 34).toInt().coerceAtLeast(y0),
                (prevPx.y + 35).toInt().coerceAtMost(y1)
            )
            if ((best?.confidence ?: 0f) >= .48f) return best
        }
        scan(x0, x1, y0, y1)
        return best?.takeIf { it.confidence >= if (blueBias) .34f else .29f }
    }

    private fun findSuper(pix: IntArray, w: Int, h: Int, now: Long): Detection? {
        val prev = lastSuper?.let { Point(it.x * w, it.y * h) }
        var best: Detection? = null
        val x0 = 225; val x1 = 291; val y0 = 132; val y1 = 186
        var y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val radius = 20
                val yellow = yellowScore(pix, w, h, x, y, radius)
                val ring = ringScore(pix, w, h, x, y, radius)
                val inner = innerScore(pix, w, h, x, y, radius)
                val temporal = if (prev != null) {
                    val d = hypot((x - prev.x).toDouble(), (y - prev.y).toDouble()).toFloat()
                    (1f - d / 36f).coerceIn(0f, 1f)
                } else 0f
                val zone = zonePrior(x, y, w, h, blue = false)
                val score = yellow * .50f + ring * .20f + inner * .05f + zone * .20f + temporal * .05f
                if (score > (best?.confidence ?: .30f)) {
                    val ready = yellow >= .52f && ring >= .16f
                    best = Detection(Point(x / w.toFloat(), y / h.toFloat()), score.coerceIn(0f, .98f), if (ready) "SUPER_READY" else "SUPER_BUTTON")
                }
                x += 3
            }
            y += 3
        }
        return best?.takeIf { it.confidence >= .34f }
    }

    private fun ringScore(p: IntArray, w: Int, h: Int, cx: Int, cy: Int, radius: Int): Float {
        var good = 0f
        var total = 0f
        for (a in 0 until 360 step 30) {
            val rad = Math.toRadians(a.toDouble())
            val x1 = (cx + cos(rad) * radius).toInt()
            val y1 = (cy + sin(rad) * radius).toInt()
            val x2 = (cx + cos(rad) * (radius - 7)).toInt()
            val y2 = (cy + sin(rad) * (radius - 7)).toInt()
            if (x1 !in 1 until w - 1 || y1 !in 1 until h - 1 || x2 !in 1 until w - 1 || y2 !in 1 until h - 1) return 0f
            val a1 = brightness(p[y1 * w + x1])
            val a2 = brightness(p[y2 * w + x2])
            total += 1f
            good += (abs(a1 - a2) / 255f).coerceIn(0f, 1f)
        }
        return if (total == 0f) 0f else (good / total * 2.1f).coerceIn(0f, 1f)
    }

    private fun innerScore(p: IntArray, w: Int, h: Int, cx: Int, cy: Int, radius: Int): Float {
        var n = 0
        var sum = 0f
        var sum2 = 0f
        val r = (radius * .62f).toInt()
        for (dy in -r..r step 3) for (dx in -r..r step 3) {
            if (dx * dx + dy * dy > r * r) continue
            val x = cx + dx; val y = cy + dy
            if (x !in 0 until w || y !in 0 until h) continue
            val b = brightness(p[y * w + x])
            sum += b; sum2 += b * b; n++
        }
        if (n < 3) return 0f
        val mean = sum / n
        val variance = (sum2 / n - mean * mean).coerceAtLeast(0f)
        return (variance / 5000f).coerceIn(0f, 1f)
    }

    private fun blueScore(p: IntArray, w: Int, h: Int, cx: Int, cy: Int, radius: Int): Float {
        var good = 0; var n = 0
        val r = (radius * .75f).toInt()
        for (dy in -r..r step 3) for (dx in -r..r step 3) {
            if (dx * dx + dy * dy > r * r) continue
            val x = cx + dx; val y = cy + dy
            if (x !in 0 until w || y !in 0 until h) continue
            val c = p[y * w + x]
            val rr = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            if (b > 95 && b > rr * 1.18f && b > g * 1.02f) good++
            n++
        }
        return if (n == 0) 0f else good.toFloat() / n
    }

    private fun neutralTranslucentScore(p: IntArray, w: Int, h: Int, cx: Int, cy: Int, radius: Int): Float {
        var good = 0; var n = 0
        val r = (radius * .78f).toInt()
        for (dy in -r..r step 4) for (dx in -r..r step 4) {
            if (dx * dx + dy * dy > r * r) continue
            val x = cx + dx; val y = cy + dy
            if (x !in 0 until w || y !in 0 until h) continue
            val c = p[y * w + x]
            val rr = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            val maxc = maxOf(rr, g, b); val minc = minOf(rr, g, b)
            if (maxc - minc < 42 && maxc in 55..205) good++
            n++
        }
        return if (n == 0) 0f else good.toFloat() / n
    }

    private fun yellowScore(p: IntArray, w: Int, h: Int, cx: Int, cy: Int, radius: Int): Float {
        var good = 0; var n = 0
        val r = (radius * .75f).toInt()
        for (dy in -r..r step 3) for (dx in -r..r step 3) {
            if (dx * dx + dy * dy > r * r) continue
            val x = cx + dx; val y = cy + dy
            if (x !in 0 until w || y !in 0 until h) continue
            val c = p[y * w + x]
            val rr = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            if (rr > 155 && g > 105 && rr > b * 1.55f && g > b * 1.15f) good++
            n++
        }
        return if (n == 0) 0f else good.toFloat() / n
    }

    private fun zonePrior(x: Int, y: Int, w: Int, h: Int, blue: Boolean): Float {
        val expectedX = if (blue) .08f else .91f
        val expectedY = .82f
        val dx = abs(x / w.toFloat() - expectedX)
        val dy = abs(y / h.toFloat() - expectedY)
        return (1f - (dx * 1.9f + dy * 1.5f)).coerceIn(0f, 1f)
    }

    private fun fallback(last: Point?, default: Point, kind: String, lastAt: Long, now: Long): Detection {
        return if (last != null) Detection(last, confidenceFromAge(lastAt, now, .40f), kind)
        else Detection(default, .30f, kind)
    }

    private fun confidenceFromAge(at: Long, now: Long, base: Float): Float {
        if (at <= 0L) return base * .78f
        val age = (now - at).coerceAtLeast(0L)
        return (base - age / 5000f).coerceAtLeast(.18f)
    }

    private fun brightness(c: Int): Float = (Color.red(c) + Color.green(c) + Color.blue(c)) / 3f

    fun reset() {
        lastMove = null; lastAttack = null; lastSuper = null
        lastMoveAt = 0L; lastAttackAt = 0L; lastSuperAt = 0L
    }
}
