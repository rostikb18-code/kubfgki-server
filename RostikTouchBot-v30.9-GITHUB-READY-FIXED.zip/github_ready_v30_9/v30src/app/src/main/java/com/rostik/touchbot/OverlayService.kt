package com.rostik.touchbot

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.BitmapFactory
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import android.text.InputType
import android.text.Editable
import android.text.TextWatcher
import kotlin.math.roundToInt

/** Floating AI controller. The queue screen intentionally follows the supplied reference:
 * brawler selection is on the left, the selected queue/cups are on the right. */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: View? = null
    private var expanded = false
    private var bubbleX = 24
    private var bubbleY = 220
    private var widthPct = 88
    private var heightPct = 76
    private var lastSelectedId: String? = null
    private var brawlerScrollY = 0
    private var queueScrollY = 0
    private var brawlerSearch = ""

    private val selected = linkedSetOf<String>()
    private val draft = linkedMapOf<String, Pair<Int, Int>>()

    override fun onCreate() {
        super.onCreate()
        StatsStore.init(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        loadDraft()
        loadSize()
        startForegroundCompat()
        showBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        try { bubble?.let(wm::removeView) } catch (_: Throwable) {}
        try { panel?.let(wm::removeView) } catch (_: Throwable) {}
        bubble = null
        panel = null
        super.onDestroy()
    }

    private fun startForegroundCompat() {
        val channelId = "overlay_v30"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(channelId, "Rostik AI overlay", NotificationManager.IMPORTANCE_LOW))
        }
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("Rostik Touch Bot v30.8")
            .setContentText("AI overlay active")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(31, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else startForeground(31, notification)
    }

    private fun overlayType() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

    private fun bubbleParams() = WindowManager.LayoutParams(
        dp(58), dp(58), overlayType(),
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        android.graphics.PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = bubbleX; y = bubbleY
    }

    private fun showBubble() {
        if (bubble != null) return
        bubble = TextView(this).apply {
            text = "AI"
            textSize = 15f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            background = circle(Color.rgb(0, 188, 245), dp(30f))
            elevation = dp(8f).toFloat()
            setOnClickListener { if (!dragging) togglePanel() }
        }
        bubble!!.setOnTouchListener(DragTouchListener { x, y ->
            bubbleX = x; bubbleY = y
            try { wm.updateViewLayout(bubble, bubbleParams()) } catch (_: Throwable) {}
        })
        try { wm.addView(bubble, bubbleParams()) } catch (_: Throwable) { bubble = null }
    }

    private fun togglePanel() { if (expanded) collapse() else expand() }

    private fun expand() {
        if (expanded) return
        expanded = true
        try { bubble?.let(wm::removeView) } catch (_: Throwable) {}
        bubble = null
        val root = buildPanel()
        panel = root
        try { wm.addView(root, panelParams()) } catch (_: Throwable) {
            expanded = false
            panel = null
            showBubble()
        }
    }

    private fun collapse() {
        if (!expanded) return
        expanded = false
        try { panel?.let(wm::removeView) } catch (_: Throwable) {}
        panel = null
        showBubble()
    }

    private fun panelParams() = WindowManager.LayoutParams(
        panelWidthPx(), panelHeightPx(), overlayType(),
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        android.graphics.PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.CENTER }

    private fun panelWidthPx(): Int {
        val w = resources.displayMetrics.widthPixels
        return (w * widthPct / 100f).roundToInt().coerceIn(minOf(dp(300), w - dp(16)), w - dp(8))
    }

    private fun panelHeightPx(): Int {
        val h = resources.displayMetrics.heightPixels
        return (h * heightPct / 100f).roundToInt().coerceIn(minOf(dp(360), h - dp(20)), h - dp(12))
    }

    private fun buildPanel(): View {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(9), dp(10), dp(10))
            background = rounded(Color.rgb(8, 31, 66), dp(20f))
            elevation = dp(12f).toFloat()
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "AI"; textSize = 19f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER
            background = circle(Color.rgb(0, 177, 239), dp(21f)); layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
        })
        header.addView(TextView(this).apply {
            text = "  ROSTIK TOUCH BOT 30.8"; textSize = 16f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL; layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
        })
        header.addView(Button(this).apply {
            text = "—"; textSize = 18f; setTextColor(Color.WHITE); background = rounded(Color.rgb(22, 57, 101), dp(10f))
            layoutParams = LinearLayout.LayoutParams(dp(46), dp(42)); setOnClickListener { collapse() }
        })
        outer.addView(header)

        outer.addView(TextView(this).apply {
            text = "БОЙЦЫ · ВЫБОР + ОЧЕРЕДЬ + КУБКИ + РАЗМЕР"
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(190, 220, 244))
            setPadding(dp(4), dp(8), dp(4), dp(5))
        })

        outer.addView(buildBrawlersTab(), LinearLayout.LayoutParams(-1, 0, 1f))
        return outer
    }

    private fun buildBotTab(): View {
        val box = verticalBox()
        val stats = StatsStore.snapshot()

        box.addView(sectionTitle("СТАТИСТИКА"))
        val statsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(Color.rgb(14, 48, 88), dp(12f))
            layoutParams = LinearLayout.LayoutParams(-1, dp(112)).apply { setMargins(0, dp(3), 0, dp(7)) }
        }
        statsCard.addView(TextView(this).apply {
            text = "${stats.timeText()}  •  ${if (stats.netCups >= 0) "+${stats.netCups}" else stats.netCups} кубков"
            textSize = 18f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
        })
        statsCard.addView(TextView(this).apply {
            text = "Матчи ${stats.matches}   •   победы ${stats.wins}   •   поражения ${stats.losses}   •   ничьи ${stats.draws}"
            textSize = 11f; setTextColor(Color.rgb(167, 198, 226)); setPadding(0, dp(6), 0, 0)
        })
        statsCard.addView(TextView(this).apply {
            text = "ВИНРЕЙТ  ${stats.winRate}%"
            textSize = 15f; setTextColor(Color.rgb(70, 230, 160)); setTypeface(null, Typeface.BOLD); setPadding(0, dp(5), 0, 0)
        })
        box.addView(statsCard)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(actionButton("START", Color.rgb(0, 177, 103)) { startBot() })
        actions.addView(actionButton("ПАУЗА", Color.rgb(220, 150, 28)) {
            if (BotRuntime.supervisor.status().contains("PAUSED")) { BotRuntime.supervisor.resume(); toast("Продолжено") }
            else { BotRuntime.supervisor.pause(); toast("Пауза") }
        })
        actions.addView(actionButton("STOP", Color.rgb(205, 57, 76)) {
            BotRuntime.supervisor.stop()
            stopSelf()
        })
        box.addView(actions)
        return box
    }

    private fun buildBrawlersTab(): View {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val topLine = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        topLine.addView(TextView(this).apply {
            text = "ВЫБЕРИТЕ БОЙЦА · ${BrawlerCatalog.all.size}"
            textSize = 14f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE)
            setPadding(dp(5), dp(4), dp(5), dp(4))
        }, LinearLayout.LayoutParams(0, dp(36), 1f))
        val search = EditText(this).apply {
            hint = "Поиск..."
            textSize = 10f
            setSingleLine(true)
            setText(brawlerSearch)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(135, 169, 202))
            background = rounded(Color.rgb(15, 51, 88), dp(8f))
            setPadding(dp(8), 0, dp(8), 0)
            inputType = InputType.TYPE_CLASS_TEXT
        }
        topLine.addView(search, LinearLayout.LayoutParams(dp(150), dp(34)).apply { setMargins(0, dp(1), dp(3), dp(1)) })
        root.addView(topLine)

        val split = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(7), 0, 0, 0) }

        left.addView(TextView(this).apply {
            text = "Мини-аватарки · нажми — имя закрепится в очереди"
            textSize = 9f; setTextColor(Color.rgb(145, 177, 207)); setPadding(dp(4), 0, 0, dp(3))
        })
        lastSelectedId?.let { id ->
            left.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(6), dp(2), dp(6), dp(2)); background = rounded(Color.rgb(20, 72, 111), dp(8f))
                loadAvatar(id)?.let { bmp -> addView(ImageView(this@OverlayService).apply {
                    setImageBitmap(bmp); scaleType = ImageView.ScaleType.CENTER_CROP
                    contentDescription = "Аватар ${BrawlerCatalog.name(id)}"
                    layoutParams = LinearLayout.LayoutParams(dp(28), dp(28)).apply { setMargins(0,0,dp(6),0) }
                }) }
                addView(TextView(this@OverlayService).apply {
                    text = "ВЫБРАН: ${BrawlerCatalog.name(id)}"
                    textSize = 9f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
                })
            }, LinearLayout.LayoutParams(-1, dp(34)).apply { setMargins(dp(2), 0, dp(2), dp(2)) })
        }

        val gridBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val filter = brawlerSearch.trim().lowercase()
        val entries = if (filter.isBlank()) BrawlerCatalog.all else BrawlerCatalog.all.filter {
            it.name.lowercase().contains(filter) || it.id.lowercase().contains(filter) || it.aliases.any { a -> a.lowercase().contains(filter) }
        }
        val columns = 5
        entries.chunked(columns).forEach { rowEntries ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            repeat(columns) { index ->
                val entry = rowEntries.getOrNull(index)
                if (entry == null) {
                    row.addView(Space(this), LinearLayout.LayoutParams(0, dp(62), 1f).apply { setMargins(dp(1), dp(1), dp(1), dp(1)) })
                } else {
                    row.addView(brawlerCell(entry), LinearLayout.LayoutParams(0, dp(62), 1f).apply { setMargins(dp(1), dp(1), dp(1), dp(1)) })
                }
            }
            gridBox.addView(row)
        }
        val leftScroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            addView(gridBox)
            setOnScrollChangeListener { _, _, scrollY, _, _ -> brawlerScrollY = scrollY }
            post { scrollTo(0, brawlerScrollY.coerceAtLeast(0)) }
        }
        left.addView(leftScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        right.addView(TextView(this).apply {
            text = "ОЧЕРЕДЬ · ${selected.size} / ${BrawlerCatalog.all.size}"
            textSize = 13f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE); setPadding(0, 0, 0, dp(5))
        })
        val queueScroll = ScrollView(this).apply {
            isFillViewport = true; overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            setOnScrollChangeListener { _, _, scrollY, _, _ -> queueScrollY = scrollY }
        }
        val queueBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (selected.isEmpty()) {
            queueBox.addView(TextView(this).apply { text = "Выбери бойцов слева"; textSize = 11f; setTextColor(Color.rgb(145, 174, 205)); setPadding(dp(4), dp(8), dp(4), 0) })
        } else selected.forEachIndexed { index, id -> queueBox.addView(queueRow(id, index + 1)) }
        queueScroll.addView(queueBox)
        right.addView(queueScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        queueScroll.post { queueScroll.scrollTo(0, queueScrollY.coerceAtLeast(0)) }

        split.addView(left, LinearLayout.LayoutParams(0, 0, 0.60f))
        split.addView(right, LinearLayout.LayoutParams(0, 0, 0.40f))
        root.addView(split, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(sizeInlineSection())

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        actions.addView(actionButton("START", Color.rgb(0, 177, 103)) { startBot() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        actions.addView(actionButton("ПАУЗА", Color.rgb(220, 150, 28)) {
            if (BotRuntime.supervisor.status().contains("PAUSED")) { BotRuntime.supervisor.resume(); toast("Продолжено") }
            else { BotRuntime.supervisor.pause(); toast("Пауза") }
        }, LinearLayout.LayoutParams(0, dp(46), 1f))
        actions.addView(actionButton("STOP", Color.rgb(205, 57, 76)) { BotRuntime.supervisor.stop(); stopSelf() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        root.addView(actions)

        search.addTextChangedListener(simpleWatcher { text ->
            brawlerSearch = text
            brawlerScrollY = 0
            rebuildPanel()
        })
        return root
    }

    private fun brawlerCell(entry: BrawlerCatalog.Entry): View {
        val isSelected = selected.contains(entry.id)
        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(1), dp(1), dp(1), dp(1))
            background = rounded(if (isSelected) Color.rgb(27, 91, 135) else Color.rgb(12, 43, 77), dp(7f))
            contentDescription = if (isSelected) "${entry.name}, выбран" else "${entry.name}, нажмите для выбора"
        }
        val avatarFrame = FrameLayout(this).apply {
            background = if (isSelected) ringedAvatar(Color.TRANSPARENT) else circle(Color.TRANSPARENT, dp(18f))
            layoutParams = LinearLayout.LayoutParams(dp(43), dp(43))
        }
        val avatarBitmap = loadAvatar(entry.id)
        if (avatarBitmap != null) {
            avatarFrame.addView(ImageView(this).apply {
                setImageBitmap(avatarBitmap); scaleType = ImageView.ScaleType.CENTER_CROP
                contentDescription = "Аватар ${entry.name}"
                layoutParams = FrameLayout.LayoutParams(dp(41), dp(41), Gravity.CENTER)
            })
        } else {
            avatarFrame.addView(TextView(this).apply {
                text = initials(entry.name); textSize = 8f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE); gravity = Gravity.CENTER
                background = circle(avatarColor(entry.id), dp(18f)); layoutParams = FrameLayout.LayoutParams(dp(41), dp(41), Gravity.CENTER)
            })
        }
        cell.addView(avatarFrame)
        cell.addView(TextView(this).apply {
            text = entry.name; textSize = 7f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(-1, dp(16)))
        cell.setOnClickListener {
            if (selected.contains(entry.id)) {
                // A brawler can exist only once in the queue. Removal is done with the X
                // button in the queue row, so tapping an already queued avatar must not
                // silently remove it.
                lastSelectedId = entry.id
                toast("${entry.name} уже в очереди")
                return@setOnClickListener
            }

            selected.add(entry.id)
            draft.putIfAbsent(entry.id, 500 to 700)
            lastSelectedId = entry.id
            saveDraft()
            toast("Добавлен в очередь: ${entry.name}")
            rebuildPanel()
        }
        return cell
    }

    private fun queueRow(id: String, number: Int): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(6), dp(5), dp(5), dp(5)); background = rounded(Color.rgb(13, 47, 88), dp(10f))
            layoutParams = LinearLayout.LayoutParams(-1, dp(112)).apply { setMargins(0, dp(3), 0, dp(3)) }
        }
        val title = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        loadAvatar(id)?.let { bmp -> title.addView(ImageView(this).apply { setImageBitmap(bmp); scaleType = ImageView.ScaleType.CENTER_CROP; layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)).apply { setMargins(0,0,dp(6),0) } }) }
        title.addView(TextView(this).apply { text = "$number. ${BrawlerCatalog.name(id)}"; textSize = 11f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD) })
        row.addView(title)
        val inputs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val cur = numberInput(draft[id]?.first ?: 500)
        val target = numberInput(draft[id]?.second ?: 700)
        cur.addTextChangedListener(simpleWatcher { text -> val old = draft[id] ?: (500 to 700); draft[id] = (text.toIntOrNull() ?: old.first) to old.second; saveDraft() })
        target.addTextChangedListener(simpleWatcher { text -> val old = draft[id] ?: (500 to 700); draft[id] = old.first to (text.toIntOrNull() ?: old.second); saveDraft() })
        inputs.addView(labeledInput("сейчас", cur), LinearLayout.LayoutParams(0, dp(64), 1f))
        inputs.addView(TextView(this).apply { text = "→"; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(dp(20), dp(64)) })
        inputs.addView(labeledInput("цель", target), LinearLayout.LayoutParams(0, dp(64), 1f))
        inputs.addView(Button(this).apply {
            text = "×"; textSize = 16f; setTextColor(Color.WHITE); background = rounded(Color.rgb(220, 64, 94), dp(9f))
            layoutParams = LinearLayout.LayoutParams(dp(38), dp(44)).apply { setMargins(dp(4), dp(9), 0, 0) }
            setOnClickListener { selected.remove(id); draft.remove(id); saveDraft(); rebuildPanel() }
        })
        row.addView(inputs)
        return row
    }

    private fun sizeInlineSection(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            background = rounded(Color.rgb(12, 43, 77), dp(10f))
            layoutParams = LinearLayout.LayoutParams(-1, dp(92)).apply { setMargins(0, dp(5), 0, dp(5)) }
        }
        box.addView(TextView(this).apply {
            text = "РАЗМЕР ПАНЕЛИ"
            textSize = 10f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(160, 194, 222))
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val width = numberInput(widthPct)
        val height = numberInput(heightPct)
        row.addView(labeledInput("ширина %", width), LinearLayout.LayoutParams(0, dp(58), 1f))
        row.addView(labeledInput("высота %", height), LinearLayout.LayoutParams(0, dp(58), 1f))
        row.addView(Button(this).apply {
            text = "OK"
            textSize = 11f
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(38, 122, 178), dp(8f))
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(42)).apply { setMargins(dp(6), dp(8), 0, 0) }
            setOnClickListener {
                widthPct = (width.text.toString().toIntOrNull() ?: widthPct).coerceIn(45, 96)
                heightPct = (height.text.toString().toIntOrNull() ?: heightPct).coerceIn(45, 94)
                saveSize()
                if (expanded) {
                    try { panel?.let { wm.updateViewLayout(it, panelParams()) } } catch (_: Throwable) {}
                }
                toast("Размер: $widthPct% × $heightPct%")
            }
        })
        box.addView(row)
        return box
    }

    private fun rebuildPanel() {
        if (!expanded) return
        val old = panel
        try { old?.let(wm::removeView) } catch (_: Throwable) {}
        panel = buildPanel()
        try { wm.addView(panel, panelParams()) } catch (_: Throwable) { panel = null; expanded = false; showBubble() }
    }

    private fun startBot() {
        if (BotAccessibilityService.instance == null) {
            toast("Включи Accessibility перед START")
            return
        }
        if (!BotRuntime.captureActive) {
            toast("Сначала включи захват экрана в разделе РАЗРЕШЕНИЯ")
            return
        }
        val items = selected.map { id ->
            val v = draft[id] ?: (500 to 700)
            QueueItem(id, v.first, v.second)
        }.filter { it.currentCups < it.targetCups }
        if (items.isEmpty()) { toast("Выбери бойцов и поставь цель выше текущих кубков"); return }
        BotRuntime.queue.replace(items)
        saveDraft()
        BotRuntime.supervisor.start()
        toast("START — очередь запущена")
        collapse()
    }

    private fun loadDraft() {
        val sp = getSharedPreferences("v30", MODE_PRIVATE)
        sp.getString("queue", "")?.takeIf { it.isNotBlank() }?.split(';')?.forEach { item ->
            val p = item.split(':')
            if (p.size == 3) {
                val c = p[1].toIntOrNull(); val t = p[2].toIntOrNull()
                if (c != null && t != null && BrawlerCatalog.all.any { it.id == p[0] }) { selected.add(p[0]); draft[p[0]] = c to t }
            }
        }
    }

    private fun saveDraft() {
        getSharedPreferences("v30", MODE_PRIVATE).edit().putString("queue", selected.joinToString(";") { id -> val v = draft[id] ?: (500 to 700); "$id:${v.first}:${v.second}" }).apply()
    }

    private fun loadSize() {
        val sp = getSharedPreferences("v30", MODE_PRIVATE)
        widthPct = sp.getInt("width_pct", 88).coerceIn(45, 96)
        heightPct = sp.getInt("height_pct", 76).coerceIn(45, 94)
    }

    private fun saveSize() { getSharedPreferences("v30", MODE_PRIVATE).edit().putInt("width_pct", widthPct).putInt("height_pct", heightPct).apply() }

    private fun numberInput(value: Int) = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER; setText(value.toString()); setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER; setSingleLine(true)
        background = rounded(Color.rgb(24, 65, 108), dp(8f))
    }

    private fun labeledInput(label: String, edit: EditText): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(2), 0, dp(2), 0)
        addView(TextView(this@OverlayService).apply { text = label; textSize = 7f; setTextColor(Color.rgb(142, 173, 204)); gravity = Gravity.CENTER })
        addView(edit, LinearLayout.LayoutParams(-1, dp(38)))
    }

    private fun loadAvatar(id: String): android.graphics.Bitmap? {
        return try { assets.open("brawler_icons/$id.png").use { BitmapFactory.decodeStream(it) } } catch (_: Throwable) { null }
    }

    private fun simpleWatcher(after: (String) -> Unit) = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, afterCount: Int) = Unit
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { after(s?.toString() ?: "") }
        override fun afterTextChanged(s: Editable?) = Unit
    }

    private fun verticalBox() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(2), dp(2), dp(2), dp(5)) }

    private fun sectionTitle(text: String) = TextView(this).apply { this.text = text; textSize = 14f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE); setPadding(dp(5), dp(8), dp(5), dp(7)) }
    private fun info(label: String, value: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)); background = rounded(Color.rgb(14, 48, 88), dp(10f))
        layoutParams = LinearLayout.LayoutParams(-1, dp(62)).apply { setMargins(0, dp(3), 0, dp(3)) }
        addView(TextView(this@OverlayService).apply { text = label; textSize = 9f; setTextColor(Color.rgb(145, 178, 208)) })
        addView(TextView(this@OverlayService).apply { text = value; textSize = 13f; setTextColor(Color.WHITE); maxLines = 2 })
    }

    private fun actionButton(text: String, color: Int, click: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 10f; setTextColor(Color.WHITE); background = rounded(color, dp(10f)); setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(3), dp(6), dp(3), dp(5)) }
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun dp(v: Float): Int = (v * resources.displayMetrics.density).roundToInt()
    private fun circle(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply { shape = android.graphics.drawable.GradientDrawable.OVAL; setColor(color) }
    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }
    private fun ringedAvatar(color: Int) = android.graphics.drawable.GradientDrawable().apply { shape = android.graphics.drawable.GradientDrawable.OVAL; setColor(color); setStroke(dp(3), Color.rgb(42, 193, 255)) }
    private fun avatarColor(id: String): Int { var h = id.hashCode(); h = h xor (h ushr 16); return Color.rgb(45 + (h and 0x7F), 65 + ((h ushr 8) and 0x7F), 90 + ((h ushr 16) and 0x7F)) }
    private fun initials(name: String): String = name.replace("-", " ").split(' ').filter { it.isNotBlank() }.take(2).joinToString("") { it.first().toString() }

    override fun onBind(intent: Intent?): IBinder? = null

    private var dragging = false
    private inner class DragTouchListener(private val moved: (Int, Int) -> Unit) : View.OnTouchListener {
        private var downX = 0f; private var downY = 0f; private var startX = 0; private var startY = 0
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dragging = false; downX=e.rawX; downY=e.rawY; startX=bubbleX; startY=bubbleY; return true }
                MotionEvent.ACTION_MOVE -> { val nx=startX+(e.rawX-downX).roundToInt(); val ny=startY+(e.rawY-downY).roundToInt(); if (kotlin.math.abs(e.rawX-downX)>8 || kotlin.math.abs(e.rawY-downY)>8) dragging=true; if(dragging) moved(nx.coerceAtLeast(0),ny.coerceAtLeast(0)); return true }
                MotionEvent.ACTION_UP -> { if(!dragging) v.performClick(); return true }
            }
            return false
        }
    }
}
