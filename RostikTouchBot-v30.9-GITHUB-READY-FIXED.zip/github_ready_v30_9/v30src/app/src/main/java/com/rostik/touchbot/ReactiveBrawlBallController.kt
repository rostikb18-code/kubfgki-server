package com.rostik.touchbot

import kotlin.math.hypot
import kotlin.math.max

/**
 * Conservative reactive controller.
 *
 * Important rule: ATTACK IS NEVER A DEFAULT ACTION.
 * A shot is generated only when a currently visible, high-confidence enemy is
 * close enough to the player. If no enemy is visible/near, the controller does
 * not tap the attack button at all. Movement and firing are intentionally
 * separated into different control frames to reduce gesture contention/lag.
 */
class ReactiveBrawlBallController {
    private var lastSuperAt = 0L
    private var lastDodgeAt = 0L

    fun next(scene: MatchScene, now: Long, matchElapsedMs: Long): ControlFrame {
        val p = scene.player ?: return ControlFrame()

        // Only use an enemy from THIS frame. No stale enemy position is allowed
        // to trigger a shot after the opponent disappears behind an effect/wall.
        val enemy = scene.enemies
            .asSequence()
            .filter { it.kind == "ENEMY" }
            .filter { it.confidence >= ENEMY_CONFIDENCE }
            .minByOrNull { distance(it.point, p.point) }

        val enemyDistance = enemy?.let { distance(it.point, p.point) } ?: Float.POSITIVE_INFINITY
        val enemyNear = enemy != null && enemyDistance <= ENEMY_NEAR_DISTANCE
        val attackAvailable = scene.rightJoystick != null && scene.attackConfidence >= ATTACK_CONTROL_CONFIDENCE
        val canFire = enemyNear && attackAvailable

        // If an opponent is close, fire ONLY. Do not add a movement stroke to
        // the same gesture; this avoids fighting with the attack tap and makes
        // the input path much more stable on slower devices.
        if (canFire) {
            val useSuper = shouldSuper(scene, enemyDistance <= SUPER_ENEMY_DISTANCE, now, matchElapsedMs)
            return if (useSuper) {
                // Super gets its own tap. The normal attack is not sent in the
                // same gesture, avoiding two competing right-side actions.
                ControlFrame(
                    moveX = 0f, moveY = 0f, aimX = 0f, aimY = 0f,
                    fire = false, useSuper = true, superPoint = scene.superPoint
                )
            } else {
                ControlFrame(
                    moveX = 0f, moveY = 0f, aimX = 0f, aimY = 0f,
                    fire = true, useSuper = false, superPoint = scene.superPoint
                )
            }
        }

        // If no enemy is close, NEVER fire. The controller may still move toward
        // the ball or hold a sensible position, but attack remains false.
        val ball = scene.ball
        val attackGoal = Point(.50f, .08f)
        val ownGoal = Point(.50f, .92f)
        val ballDistance = ball?.let { distance(it.point, p.point) } ?: Float.POSITIVE_INFINITY

        val moveTarget = when {
            ball != null && ballDistance < .22f -> attackGoal
            ball != null -> ball.point
            else -> ownGoal
        }

        // Short sidestep is movement-only. It never causes a shot by itself.
        if (enemy != null && enemyDistance < .18f && now - lastDodgeAt > 700L) {
            lastDodgeAt = now
            val ex = enemy.point.x - p.point.x
            val ey = enemy.point.y - p.point.y
            val sideX = -ey
            val sideY = ex
            val mag = max(.001f, hypot(sideX.toDouble(), sideY.toDouble()).toFloat())
            val sign = if (p.point.x < .5f) 1f else -1f
            return ControlFrame(
                moveX = (sideX / mag * sign).coerceIn(-1f, 1f),
                moveY = (sideY / mag * sign).coerceIn(-1f, 1f),
                fire = false,
                useSuper = false
            )
        }

        val moveX = (moveTarget.x - p.point.x).coerceIn(-1f, 1f)
        val moveY = (moveTarget.y - p.point.y).coerceIn(-1f, 1f)

        return ControlFrame(
            moveX = moveX,
            moveY = moveY,
            aimX = 0f,
            aimY = 0f,
            fire = false,
            useSuper = false
        )
    }

    private fun shouldSuper(scene: MatchScene, enemyNear: Boolean, now: Long, elapsed: Long): Boolean {
        if (!scene.superReady) return false
        if (scene.superPoint == null || scene.superConfidence < SUPER_CONTROL_CONFIDENCE) return false
        if (!enemyNear) return false
        if (elapsed < 8_000L) return false
        if (now - lastSuperAt < 2_800L) return false
        lastSuperAt = now
        return true
    }

    private fun distance(a: Point, b: Point): Float =
        hypot((a.x - b.x).toDouble(), (a.y - b.y).toDouble()).toFloat()

    companion object {
        // "Nearby" is deliberately conservative. This is normalized to the
        // gameplay frame, not Android pixels.
        private const val ENEMY_NEAR_DISTANCE = .34f
        private const val SUPER_ENEMY_DISTANCE = .27f
        private const val ENEMY_CONFIDENCE = .72f
        private const val ATTACK_CONTROL_CONFIDENCE = .55f
        private const val SUPER_CONTROL_CONFIDENCE = .55f
    }
}
