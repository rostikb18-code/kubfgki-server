package com.rostik.touchbot

import android.content.Context
import android.graphics.Bitmap

/** Process-local bridge shared by MainActivity, capture and floating overlay. */
object BotRuntime {
    private lateinit var app: Context
    val queue: QueueEngine = QueueEngine()
    val supervisor: MatchSupervisor by lazy { MatchSupervisor(queue, app.assets) }

    @Volatile var captureActive: Boolean = false
        private set

    fun init(context: Context) {
        app = context.applicationContext
        StatsStore.init(app)
    }

    fun submitFrame(bitmap: Bitmap) {
        // Ownership is transferred to MatchSupervisor. Do not keep another reference
        // here because the supervisor recycles each consumed frame.
        supervisor.submitLatestFrame(bitmap)
    }

    fun setCaptureActive(active: Boolean) { captureActive = active }
}
