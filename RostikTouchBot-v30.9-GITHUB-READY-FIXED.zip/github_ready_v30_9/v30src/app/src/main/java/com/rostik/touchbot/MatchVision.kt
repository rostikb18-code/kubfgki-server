package com.rostik.touchbot

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Adaptive marker detector.
 *
 * It deliberately supports both the green/cyan marker seen in some layouts
 * and blue/cyan team markers. The player's identity is not inferred from
 * color alone: spatial prior + indicator above + temporal continuity are used.
 */
class MatchVision {
    private val controls = ControlDetector()
    private var lastPlayer: Point? = null
    private var lastEnemy: Point? = null
    private var lastBall: Point? = null
    private var lastPlayerAt = 0L
    private var lastEnemyAt = 0L
    private var lastBallAt = 0L
    private var lastVelocity = Point(0f, 0f)

    fun detect(src: Bitmap, now: Long): MatchScene {
        val w = 360
        val h = 202
        val bmp = Bitmap.createScaledBitmap(src, w, h, true)
        val pixels = IntArray(w * h)
        bmp.getPixels(pixels, 0, w, 0, 0, w, h)

        val candidates = mutableListOf<Detection>()
        for (y in 25 until 180 step 2) {
            for (x in 8 until w - 8 step 2) {
                val c = pixels[y * w + x]
                val r = Color.red(c)
                val g = Color.green(c)
                val b = Color.blue(c)

                // Team marker: accept green/cyan/blue variants.
                val team = ((g > 150 && g > r * 1.28f && b > r * 1.10f) ||
                        (b > 160 && g > 125 && b > r * 1.35f && g > r * 1.18f))
                if (team) {
                    val p = Point(x / w.toFloat(), y / h.toFloat())
                    val score = markerScore(p, pixels, w, h, true)
                    if (score > 0.52f) candidates += Detection(p, score, "TEAM")
                }
            }
        }

        val grouped = cluster(candidates)
        val own = choosePlayer(grouped, pixels, w, h, now)
        val allies = grouped.filter { d -> own == null || distance(d.point, own.point) > .075f }
            .filter { it.confidence > .55f }
            .take(3)

        val enemies = findEnemies(pixels, w, h, now, own)
        val ball = findBall(pixels, w, h, now, own?.point)

        // Combat controls are detected from the current frame instead of being
        // trusted at one fixed pixel. The detector searches broad HUD zones and
        // tracks the last confirmed center through temporary effects.
        val control = controls.detect(src, now)
        val leftJoy = control.move
        val rightJoy = control.attack
        val superPoint = control.superButton
        val hudConfidence = control.confidence
        val confParts = listOfNotNull(own?.confidence, ball?.confidence, enemies.maxOfOrNull { it.confidence })
        val conf = if (confParts.isEmpty()) 0f else confParts.average().toFloat().coerceIn(0f, .98f)

        if (bmp !== src) try { bmp.recycle() } catch (_: Throwable) {}

        return MatchScene(
            player = own,
            enemies = enemies,
            allies = allies,
            ball = ball,
            superPoint = superPoint?.point,
            superReady = control.superReady,
            superConfidence = superPoint?.confidence ?: 0f,
            leftJoystick = leftJoy.point,
            rightJoystick = rightJoy.point,
            attackConfidence = rightJoy.confidence,
            hudConfidence = hudConfidence,
            confidence = conf,
            timestamp = now
        )
    }

    private fun choosePlayer(
        list: List<Detection>, pixels: IntArray, w: Int, h: Int, now: Long
    ): Detection? {
        if (list.isEmpty()) {
            if (lastPlayer != null && now - lastPlayerAt < 180L) {
                val p = Point(
                    (lastPlayer!!.x + lastVelocity.x * .08f).coerceIn(.04f, .96f),
                    (lastPlayer!!.y + lastVelocity.y * .08f).coerceIn(.12f, .92f)
                )
                return Detection(p, .52f, "PREDICTED_PLAYER")
            }
            return null
        }
        val scored = list.map { d ->
            val indicator = hasIndicatorAbove(d.point, pixels, w, h)
            val bottomPrior = 1f - (d.point.y - .55f).coerceAtLeast(0f) * 1.5f
            val temporal = lastPlayer?.let { (1f - distance(it, d.point) / .16f).coerceIn(0f, 1f) } ?: 0f
            d.copy(confidence = (d.confidence * .45f + indicator * .30f + bottomPrior.coerceIn(0f,1f)*.15f + temporal*.10f).coerceIn(0f,.99f))
        }.maxByOrNull { it.confidence }
        scored?.let {
            lastPlayer?.let { old ->
                val dt = ((now - lastPlayerAt).coerceAtLeast(1L)) / 1000f
                lastVelocity = Point(
                    ((it.point.x - old.x) / dt).coerceIn(-2f,2f),
                    ((it.point.y - old.y) / dt).coerceIn(-2f,2f)
                )
            }
            lastPlayer = it.point
            lastPlayerAt = now
        }
        return scored?.takeIf { it.confidence >= .52f }
    }

    private fun findEnemies(pix: IntArray, w: Int, h: Int, now: Long, own: Detection?): List<Detection> {
        val out = mutableListOf<Detection>()
        for (y in 28 until 155 step 2) for (x in 8 until w-8 step 2) {
            val c = pix[y*w+x]
            val r=Color.red(c); val g=Color.green(c); val b=Color.blue(c)
            val red = r > 155 && r > g*1.35f && r > b*1.25f && r-g > 55
            if (!red) continue
            val p=Point(x/w.toFloat(), y/h.toFloat())
            if (own != null && distance(p, own.point) < .10f) continue
            val temporal = lastEnemy?.let { (1f-distance(it,p)/.18f).coerceIn(0f,1f) } ?: 0f
            val cScore=(.58f + temporal*.22f + geometryScore(p)*.20f).coerceIn(0f,.98f)
            if (cScore > .52f) out += Detection(p,cScore,"ENEMY")
        }
        val grouped=cluster(out)
        val best=grouped.maxByOrNull { it.confidence }
        if (best != null) { lastEnemy=best.point; lastEnemyAt=now }
        return grouped.sortedByDescending { it.confidence }.take(3)
    }

    private fun findBall(pix:IntArray,w:Int,h:Int,now:Long,player:Point?):Detection? {
        var best:Detection?=null
        for(y in 35 until 160 step 2) for(x in 10 until w-10 step 2) {
            val c=pix[y*w+x]; val r=Color.red(c); val g=Color.green(c); val b=Color.blue(c)
            val bright=(r+g+b)/3
            val neutral=abs(r-g)<28 && abs(g-b)<28 && bright>135
            if(!neutral) continue
            val p=Point(x/w.toFloat(),y/h.toFloat())
            if(player!=null && distance(p,player)<.065f) continue
            val darkAround = neighborhoodDark(pix,w,h,x,y)
            val temporal=lastBall?.let{(1f-distance(it,p)/.16f).coerceIn(0f,1f)}?:0f
            val score=(.42f + darkAround*.25f + temporal*.25f + centerPrior(p)*.08f).coerceIn(0f,.98f)
            if(best==null || score>best!!.confidence) best=Detection(p,score,"BALL")
        }
        if(best!=null && best!!.confidence>.55f){ lastBall=best!!.point; lastBallAt=now; return best }
        if(lastBall!=null && now-lastBallAt<180L) return Detection(lastBall!!,.50f,"PREDICTED_BALL")
        return null
    }

    private fun findJoystick(pix:IntArray, w:Int, h:Int, x0:Int, y0:Int, x1:Int, y1:Int):Detection? {
        var best: Detection? = null
        val step = 4
        for (y in y0 until y1 step step) for (x in x0 until x1 step step) {
            val center = pix[y*w+x]
            val cb = (Color.red(center)+Color.green(center)+Color.blue(center))/3
            if (cb < 45) continue
            var ring = 0f
            var samples = 0
            val radius = 14
            for (a in 0 until 360 step 45) {
                val rad = Math.toRadians(a.toDouble())
                val xx=(x + kotlin.math.cos(rad)*radius).toInt()
                val yy=(y + kotlin.math.sin(rad)*radius).toInt()
                if(xx !in 0 until w || yy !in 0 until h) continue
                val c=pix[yy*w+xx]
                val b=(Color.red(c)+Color.green(c)+Color.blue(c))/3
                val contrast=abs(b-cb)/255f
                ring += contrast
                samples++
            }
            if(samples==0) continue
            val score=(ring/samples).coerceIn(0f,1f)
            if(score>.28f && (best==null || score>best!!.confidence)) {
                best=Detection(Point(x/w.toFloat(),y/h.toFloat()),score,"JOYSTICK")
            }
        }
        return best
    }

    private fun findSuper(pix:IntArray,w:Int,h:Int):Detection? {
        var best:Detection?=null
        for(y in 135 until 192 step 2) for(x in 245 until 355 step 2) {
            val c=pix[y*w+x]; val r=Color.red(c); val g=Color.green(c); val b=Color.blue(c)
            val bright=(r+g+b)/765f
            val colored=(b>120 && r>70 && bright>.45f)
            if(colored){
                val p=Point(x/w.toFloat(),y/h.toFloat())
                val score=(bright*.75f+.25f).coerceIn(0f,.98f)
                if(best==null || score>best!!.confidence) best=Detection(p,score,"SUPER")
            }
        }
        return best
    }

    private fun markerScore(p:Point,pix:IntArray,w:Int,h:Int,own:Boolean):Float {
        val above=hasIndicatorAbove(p,pix,w,h)
        val bottom=(1f-(p.y-.55f).coerceAtLeast(0f)*1.3f).coerceIn(0f,1f)
        return (.50f+above*.25f+bottom*.15f).coerceIn(0f,.95f)
    }

    private fun hasIndicatorAbove(p:Point,pix:IntArray,w:Int,h:Int):Float {
        val x=(p.x*w).toInt(); val y=(p.y*h).toInt()
        var bright=0
        for(dy in -14..-6) for(dx in -7..7){
            val xx=x+dx; val yy=y+dy
            if(xx !in 0 until w || yy !in 0 until h) continue
            val c=pix[yy*w+xx]
            if((Color.red(c)+Color.green(c)+Color.blue(c))/3>195) bright++
        }
        return (bright/80f).coerceIn(0f,1f)
    }

    private fun neighborhoodDark(p:IntArray,w:Int,h:Int,x:Int,y:Int):Float {
        var dark=0
        var n=0
        for(dy in -5..5) for(dx in -5..5){
            val xx=x+dx; val yy=y+dy
            if(xx !in 0 until w || yy !in 0 until h) continue
            n++; val c=p[yy*w+xx]
            if((Color.red(c)+Color.green(c)+Color.blue(c))/3<105) dark++
        }
        return if(n==0) 0f else dark/n.toFloat()
    }

    private fun geometryScore(p:Point)=((1f-abs(p.x-.5f)*1.2f).coerceIn(0f,1f))
    private fun centerPrior(p:Point)=((1f-distance(p,Point(.5f,.55f))/.7f).coerceIn(0f,1f))
    private fun distance(a:Point,b:Point)=hypot((a.x-b.x).toDouble(),(a.y-b.y).toDouble()).toFloat()

    private fun cluster(src:List<Detection>):List<Detection>{
        val out=mutableListOf<Detection>()
        for(d in src){
            val i=out.indexOfFirst{distance(it.point,d.point)<.035f}
            if(i<0) out+=d else if(d.confidence>out[i].confidence) out[i]=d
        }
        return out
    }

    fun close(){ lastPlayer=null; lastEnemy=null; lastBall=null; controls.reset() }
}
