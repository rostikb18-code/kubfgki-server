ROSTIK TOUCH BOT v30.9 — GitHub upload

Upload the CONTENTS of this folder to the root of a GitHub repository.

Required structure:
  .github/workflows/build.yml
  v30src/settings.gradle.kts
  v30src/build.gradle.kts
  v30src/app/...

Then open GitHub -> Actions -> Build Rostik Touch Bot v30.9 -> Run workflow.
The workflow builds debug and release APK artifacts.

Do not rename v30src unless the workflow is changed accordingly.
