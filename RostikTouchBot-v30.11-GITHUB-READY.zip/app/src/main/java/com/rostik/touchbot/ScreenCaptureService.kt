package com.rostik.touchbot

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.hardware.display.VirtualDisplay
import android.os.*
import android.util.Log
import androidx.core.app.ServiceCompat

class ScreenCaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        @Volatile var onBitmap: ((android.graphics.Bitmap) -> Unit)? = null
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var started = false

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Log.i("Capture", "MediaProjection stopped by system/user")
            stopCaptureResources()
            stopSelf()
        }
    }

    override fun onCreate() {
        super.onCreate()
        thread = HandlerThread("rostik-capture").also { it.start() }
        handler = Handler(thread!!.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (started) return START_STICKY
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        } ?: return START_NOT_STICKY

        val pm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = try { pm.getMediaProjection(code, data) } catch (t: Throwable) {
            Log.e("Capture", "getMediaProjection failed", t); null
        }
        if (projection == null) return START_NOT_STICKY

        if (Build.VERSION.SDK_INT >= 29) {
            ServiceCompat.startForeground(this, 29, notification(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(29, notification())
        }

        projection!!.registerCallback(projectionCallback, handler)
        val dm = resources.displayMetrics
        reader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ r ->
            val image = try { r.acquireLatestImage() } catch (t: Throwable) { null } ?: return@setOnImageAvailableListener
            try {
                val plane = image.planes.firstOrNull() ?: return@setOnImageAvailableListener
                val buffer = plane.buffer
                val w = image.width
                val h = image.height
                val rowStride = plane.rowStride
                val pixelStride = plane.pixelStride
                if (pixelStride <= 0 || rowStride < w * pixelStride) return@setOnImageAvailableListener
                val paddedWidth = rowStride / pixelStride
                val source = android.graphics.Bitmap.createBitmap(paddedWidth, h, android.graphics.Bitmap.Config.ARGB_8888)
                buffer.rewind()
                source.copyPixelsFromBuffer(buffer)
                val frame = if (paddedWidth != w) android.graphics.Bitmap.createBitmap(source, 0, 0, w, h) else source
                if (frame !== source) try { source.recycle() } catch (_: Throwable) {}
                val sink = onBitmap
                if (sink != null) sink(frame) else try { frame.recycle() } catch (_: Throwable) {}
            } catch (t: Throwable) {
                Log.w("Capture", "frame failed", t)
            } finally {
                try { image.close() } catch (_: Throwable) {}
            }
        }, handler)

        virtualDisplay = projection!!.createVirtualDisplay(
            "RostikCapture", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, handler
        )
        started = virtualDisplay != null
        BotRuntime.setCaptureActive(started)
        return if (started) START_STICKY else START_NOT_STICKY
    }

    private fun notification(): Notification {
        val ch = NotificationChannel("capture", "Rostik Capture", NotificationManager.IMPORTANCE_LOW)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        return Notification.Builder(this, "capture")
            .setContentTitle("Rostik Touch Bot v30.11")
            .setContentText("Screen capture active")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    private fun stopCaptureResources() {
        started = false
        BotRuntime.setCaptureActive(false)
        try { virtualDisplay?.release() } catch (_: Throwable) {}
        virtualDisplay = null
        try { reader?.setOnImageAvailableListener(null, null) } catch (_: Throwable) {}
        try { reader?.close() } catch (_: Throwable) {}
        reader = null
        try { projection?.unregisterCallback(projectionCallback) } catch (_: Throwable) {}
        try { projection?.stop() } catch (_: Throwable) {}
        projection = null
        onBitmap = null
    }

    override fun onDestroy() {
        stopCaptureResources()
        try { thread?.quitSafely() } catch (_: Throwable) {}
        thread = null
        handler = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
