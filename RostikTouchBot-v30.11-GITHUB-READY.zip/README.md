# Rostik Touch Bot v30.11

Android/Kotlin vision controller project. The repository is organized as a normal GitHub Android project: the repository root is the Gradle project and `.github/workflows/build.yml` builds both debug and release APKs.

## What was hardened in v30.11

- Current Brawl Stars Brawler Collection is treated as a **horizontal** list first. The selector searches the visible cards before every swipe and walks the collection horizontally in both directions.
- The selector uses OCR + bundled avatar references and verifies the selected brawler on the next screen before continuing.
- The old vertical brawler scroll remains only as a compatibility fallback after horizontal traversal.
- The supplied gameplay recording was used to calibrate the Brawl Ball control zones and to add full-resolution reference frames under `app/src/main/assets/reference/video/`.
- Match entry requires freshly detected combat controls rather than accepting stale/fallback joystick coordinates as proof that a match has started.
- During a match, movement continues while the player marker is temporarily lost during effects/respawn.
- A gameplay input watchdog sends a short movement recovery pulse only when the combat HUD has been freshly confirmed and the previous gesture was not delivered.
- Result handling keeps the `GAME HIGHLIGHT -> PLAY AGAIN / PROCEED -> result verification` chain conservative.
- Capture resources, conflated frame recycling, foreground services and version metadata remain wired for Android 35.

## Important limitation

This is a classical computer-vision/OCR controller, not a trained neural gameplay policy. Detection is designed to fail safely when the live screen is ambiguous. Real-device testing is still required because Brawl Stars can change UI, fonts, animations, maps and control placement.

Automated interaction with Brawl Stars may also conflict with the game's rules or create account-risk; use the project only where you are authorized to automate the device.

## Build on GitHub

1. Create a new GitHub repository.
2. Copy the contents of this project to the repository root.
3. Push to `main`.
4. Open **Actions → Build Rostik Touch Bot v30.11**.
5. Download the generated APK artifact.

No fake brawler reference images are generated for missing visual assets. The UI can still list all catalog entries using its existing fallback, while visual verification uses only real bundled references.
