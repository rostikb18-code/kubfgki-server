package com.rostik.touchbot

/** Reads explicit match-result words and Showdown placement from OCR. */
object ResultReader {
    private val winWords = listOf("победа", "победили", "victory", "win", "won")
    private val lossWords = listOf("поражение", "поражени", "defeat", "loss", "lost")

    data class Parsed(val outcome: MatchOutcome, val pythonResult: String)

    fun parse(lines: List<OcrLine>): Parsed? {
        val text = lines.joinToString(" ") { normalize(it.text) }
        when {
            containsAny(text, "1st", "1место", "1 место", "1stplace") -> return Parsed(MatchOutcome.WIN, "trio_showdown_0")
            containsAny(text, "2nd", "2место", "2 место", "2ndplace") -> return Parsed(MatchOutcome.WIN, "trio_showdown_1")
            containsAny(text, "3rd", "3место", "3 место", "3rdplace") -> return Parsed(MatchOutcome.DRAW, "trio_showdown_2")
            containsAny(text, "4th", "4место", "4 место", "4thplace") -> return Parsed(MatchOutcome.LOSS, "trio_showdown_3")
        }
        return when {
            winWords.any(text::contains) -> Parsed(MatchOutcome.WIN, "victory")
            lossWords.any(text::contains) -> Parsed(MatchOutcome.LOSS, "defeat")
            text.contains("draw") || text.contains("ничья") -> Parsed(MatchOutcome.DRAW, "draw")
            else -> null
        }
    }

    fun read(lines: List<OcrLine>): MatchOutcome? = parse(lines)?.outcome

    private fun containsAny(text: String, vararg words: String) = words.any { text.contains(normalize(it)) }
    private fun normalize(value: String) = value.lowercase().replace('ё', 'е').replace(Regex("[^a-zа-я0-9]"), "")
}
