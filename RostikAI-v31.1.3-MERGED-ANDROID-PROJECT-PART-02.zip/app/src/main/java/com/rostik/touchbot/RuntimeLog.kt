package com.rostik.touchbot

import android.util.Log
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/** Categorized runtime logging with Python-compatible verbosity semantics. */
object RuntimeLog {
    const val ERROR=0; const val WARN=1; const val INFO=2; const val DEBUG=3; const val TRACE=4
    private val once = ConcurrentHashMap<String, AtomicLong>()
    @Volatile private var minLevel = INFO
    @Volatile private var movementTrace = false
    @Volatile private var wallDebug = false

    fun configure(level: String = "normal", movement: Boolean = false, wall: Boolean = false, superDebug: Boolean = false) {
        minLevel = when(level.lowercase()) { "quiet" -> WARN; "verbose" -> DEBUG; "debug" -> TRACE; else -> INFO }.let { if (superDebug) maxOf(it, DEBUG) else it }
        movementTrace = movement; wallDebug = wall
    }
    fun movementTraceEnabled() = movementTrace || minLevel >= TRACE
    fun wallStuckDebugEnabled() = wallDebug
    fun log(level:Int, category:String, message:String) {
        if (level > minLevel && !(level == DEBUG && category == "movement" && wallDebug)) return
        val label = category.replaceFirstChar { it.uppercase() }
        when(level) { ERROR -> Log.e("RostikAI.$label", message); WARN -> Log.w("RostikAI.$label", message); else -> Log.i("RostikAI.$label", message) }
    }
    fun error(c:String,m:String)=log(ERROR,c,m)
    fun warn(c:String,m:String)=log(WARN,c,m)
    fun info(c:String,m:String)=log(INFO,c,m)
    fun debug(c:String,m:String)=log(DEBUG,c,m)
    fun trace(c:String,m:String,key:String=m,intervalMs:Long=2000) {
        if (TRACE > minLevel || !movementTraceEnabled()) return
        val now=System.currentTimeMillis(); val last=once[key]?.get() ?: 0L
        if(now-last<intervalMs)return
        once.computeIfAbsent(key){AtomicLong()}.set(now); log(TRACE,c,m)
    }
    fun once(key:String, intervalMs:Long, level:Int, category:String, message:String) {
        val now=System.currentTimeMillis(); val last=once[key]?.get() ?: 0L
        if(now-last>=intervalMs){once.computeIfAbsent(key){AtomicLong()}.set(now);log(level,category,message)}
    }
}
