package com.rostik.touchbot

/** Android equivalent of the desktop capture profiles. scrcpy-specific fields are intentionally replaced by processing limits. */
data class PerformanceProfile(val name:String,val description:String,val maxProcessFps:Int,val visionScale:Float,val ocrEveryMs:Long,val duplicateFrameReplay:Boolean)
object PerformanceProfiles {
    val all = listOf(
        PerformanceProfile("balanced","Default stable processing",30,1f,700,true),
        PerformanceProfile("low_end","Lower CPU/heat",20,.78f,900,true),
        PerformanceProfile("quality","Sharper processing",45,1f,550,true),
        PerformanceProfile("quality_fullres","Maximum source resolution with bounded processing",60,1f,450,true),
        PerformanceProfile("high_ips","Maximum throughput with fewer expensive OCR passes",60,.78f,1000,false)
    )
    fun byName(name:String)=all.firstOrNull{it.name==name.lowercase()}?:all.first()
}
